/* FitLife servis çalışanı — bildirim gösterimi ve tıklama yönetimi */
self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((list) => {
      for (const client of list) {
        if ("focus" in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow("./");
      return undefined;
    })
  );
});

self.addEventListener("message", (event) => {
  const data = event.data || {};
  if (data.type === "FITLIFE_NOTIFY" && self.registration.showNotification) {
    self.registration.showNotification(data.title || "FitLife", {
      body: data.body || "",
      tag: data.tag || "fitlife",
      icon: data.icon,
      badge: data.icon,
      vibrate: [180, 90, 180],
      data: { url: "./" },
    });
  }
});
