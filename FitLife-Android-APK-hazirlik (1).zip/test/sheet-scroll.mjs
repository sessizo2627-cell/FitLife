import { chromium } from "playwright";
const BASE = "http://localhost:4173/";
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: "tr-TR" });
const page = await ctx.newPage();
const k = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const t = k(new Date());
const seed = { version: 2,
  profile: { name: "Deniz Kaya", age: 31, height: 176, weight: 82, targetWeight: 76, gender: "erkek", level: "orta", goalId: "kilo-verme", durationDays: 60, customDuration: false, startDate: new Date().toISOString(), notifications: true, reminders: true, soundEffects: true, weeklyTarget: 4, stepGoal: 9000, waterGoal: 12 },
  days: { [t]: { date: t, exercises: {}, workoutDone: false, water: 3, steps: 1200, meals: [], activeSeconds: 0, note: "" } },
  measurements: [{ id: "a", date: t, weight: 82 }],
  reminders: [{ id: "r1", kind: "antrenman", title: "Antrenman zamanı", time: "18:30", days: [0,1,2,3,4,5,6], enabled: true, sound: true }],
  session: null };
await page.goto(BASE);
await page.evaluate((s) => localStorage.setItem("fitlife_state_v2", JSON.stringify(s)), seed);
await page.reload({ waitUntil: "networkidle" });
await page.waitForTimeout(2200);

// Gerçek kullanıcı gibi: önce aşağı kaydır, sonra o noktadaki düğmeye bas (otomatik kaydırma YOK)
async function openAndMeasure(tabLabel, buttonName, sheetTitle) {
  await page.getByRole("navigation").getByLabel(tabLabel).click();
  await page.waitForTimeout(800);
  await page.evaluate(() => { const m = document.querySelector("main"); m.scrollTop = m.scrollHeight; });
  await page.waitForTimeout(300);
  const scrolled = await page.evaluate(() => document.querySelector("main").scrollTop);
  await page.getByRole("button", { name: buttonName }).first().evaluate((el) => el.click());
  await page.waitForTimeout(900);
  const box = await page.evaluate((title) => {
    const h = [...document.querySelectorAll("h3")].find((x) => x.textContent?.trim() === title);
    if (!h) return null;
    const r = h.getBoundingClientRect();
    return { top: Math.round(r.top), bottom: Math.round(r.bottom), vh: window.innerHeight };
  }, sheetTitle);
  const inView = !!box && box.top >= 0 && box.bottom <= box.vh;
  console.log(`${tabLabel} › "${sheetTitle}" | kaydırma: ${scrolled}px | konum:`, JSON.stringify(box), "| ekranda:", inView);
  // Gerçek isabet testi: panelin içindeki "Kapat" düğmesinin merkezinde hangi öğe var?
  const hit = await page.evaluate((title) => {
    const h = [...document.querySelectorAll("h3")].find((x) => x.textContent?.trim() === title);
    const btn = h?.parentElement?.parentElement?.querySelector('button[aria-label="Kapat"]');
    if (!btn) return { ok: false, why: "düğme yok" };
    const r = btn.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const top = document.elementFromPoint(cx, cy);
    return { ok: !!top && btn.contains(top), cx, cy };
  }, sheetTitle);
  console.log("   isabet testi (tıklama panele ulaşıyor mu):", hit.ok);
  if (!hit.ok) { await page.screenshot({ path: `test/shots/sheet-hitfail-${tabLabel}.png` }); }
  await page.screenshot({ path: `test/shots/sheet-${tabLabel}.png` });
  // Gerçek fare tıklamasıyla kapat
  if (hit.ok) { await page.mouse.click(hit.cx, hit.cy); await page.waitForTimeout(700); }
  const closed = await page.evaluate((title) => ![...document.querySelectorAll("h3")].some((x) => x.textContent?.trim() === title), sheetTitle);
  console.log("   gerçek tıklamayla kapandı:", closed);
  if (!closed) { await page.keyboard.press("Escape"); await page.waitForTimeout(600); }
  return inView && hit.ok && closed;
}

const r1 = await openAndMeasure("Profil", /Hatırlatıcılar & Alarm/, "Hatırlatıcılar & Alarm");
const r2 = await openAndMeasure("Profil", /Verileri Sıfırla/, "Verileri Sıfırla?");
const r3 = await openAndMeasure("İlerleme", /^Ölçüm$/, "Yeni Ölçüm");
console.log("SONUÇ:", r1 && r2 && r3 ? "TÜM PANELLER GÖRÜNÜR" : "EN AZ BİR PANEL EKRAN DIŞINDA AÇILIYOR");
await browser.close();
