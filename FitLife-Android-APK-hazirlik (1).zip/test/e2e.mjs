import { chromium } from "playwright";

const BASE = "http://localhost:4173/";
const errors = [];
const log = (...a) => console.log(...a);

const browser = await chromium.launch();
const ctx = await browser.newContext({
  viewport: { width: 390, height: 844 },
  deviceScaleFactor: 2,
  isMobile: true,
  hasTouch: true,
  permissions: [],
  locale: "tr-TR",
});
const page = await ctx.newPage();
page.on("console", (m) => { if (m.type() === "error") errors.push("CONSOLE: " + m.text()); });
page.on("pageerror", (e) => errors.push("PAGEERROR: " + e.message));

await page.goto(BASE, { waitUntil: "networkidle" });
await page.waitForTimeout(2000);

// --- ONBOARDING ---
await page.getByRole("button", { name: /Hemen Başla/i }).click();
await page.waitForTimeout(500);
log("1) hedef adımı:", await page.getByText("HEDEFİN").first().isVisible());
await page.getByRole("button", { name: /Kilo Verme/ }).first().click();
await page.getByRole("button", { name: /Devam Et/ }).click();
await page.waitForTimeout(500);

// özel süre
await page.getByRole("button", { name: /^\+ Özel$/ }).click();
await page.waitForTimeout(300);
const customInput = page.locator('input[type="number"]').first();
await customInput.fill("45");
await page.getByRole("button", { name: /Devam Et/ }).click();
await page.waitForTimeout(500);
log("2) süre adımı geçildi, profil adımı:", await page.getByText("TANIYALIM", { exact: true }).isVisible());

// boş ad ile devam engellenmeli
await page.getByRole("button", { name: /Devam Et/ }).click();
await page.waitForTimeout(300);
const blocked = await page.getByText("Devam etmek için işaretli alanları düzelt.").isVisible();
log("3) boş form engellendi:", blocked);

await page.getByPlaceholder("örn. Emre").fill("Emre Yılmaz");
const nums = page.locator('input[type="number"]');
await nums.nth(0).fill("29");
await nums.nth(1).fill("180");
await nums.nth(2).fill("86");
await nums.nth(3).fill("78");
await page.getByRole("button", { name: /Devam Et/ }).click();
await page.waitForTimeout(500);
await page.getByRole("button", { name: /Programı Başlat/ }).click();
await page.waitForTimeout(900);

const stored1 = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")));
log("4) profil kaydı:", stored1.profile.name, stored1.profile.goalId, stored1.profile.durationDays, "gün | ölçüm:", stored1.measurements.length);

// --- ANA EKRAN: SU ---
await page.getByRole("button", { name: /Su Ekle/ }).click();
await page.waitForTimeout(400);
await page.getByLabel("Su ekle", { exact: true }).click();
await page.getByLabel("Su ekle", { exact: true }).click();
await page.getByRole("button", { name: "Tamam", exact: true }).click();
await page.waitForTimeout(400);
let st = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")));
log("5) su kaydı:", Object.values(st.days)[0].water);

// --- ÖĞÜN ---
await page.getByRole("button", { name: /Öğün Ekle/ }).click();
await page.waitForTimeout(400);
await page.getByRole("button", { name: "Tavuk & Pilav" }).click();
await page.getByRole("button", { name: /Öğünü Kaydet/ }).click();
await page.waitForTimeout(400);
log("6) öğün eklendi:", await page.getByText("Tavuk & Pilav").first().isVisible());
await page.locator("div.z-40").first().click({ position: { x: 8, y: 8 } });
await page.waitForTimeout(400);

// --- ADIM ---
await page.getByText(/\/ 8.000 adım/).click();
await page.waitForTimeout(400);
await page.getByRole("button", { name: "+5.000" }).click();
await page.getByRole("button", { name: "Kaydet", exact: true }).click();
await page.waitForTimeout(500);
st = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")));
log("7) adım kaydı:", Object.values(st.days)[0].steps, "| öğün:", Object.values(st.days)[0].meals.length);

// --- PROGRAM: canlı oturum ---
await page.getByRole("navigation").getByLabel("Programım").click();
await page.waitForTimeout(700);
await page.getByRole("button", { name: /^Başlat$/ }).click();
await page.waitForTimeout(900);
log("8) oturum açıldı:", await page.getByText("Canlı Antrenman", { exact: true }).isVisible());
await page.getByRole("button", { name: /Seti Tamamla/ }).click();
await page.waitForTimeout(600);
log("9) dinlenme sayacı:", await page.getByText("Dinlenme", { exact: true }).first().isVisible());
await page.getByRole("button", { name: /Duraklat/ }).click();
await page.waitForTimeout(400);
await page.getByRole("button", { name: /Devam Et/ }).last().click();
await page.waitForTimeout(400);
await page.getByRole("button", { name: /Antrenmanı Bitir/ }).click();
await page.waitForTimeout(900);
log("10) tamamlanma ekranı:", await page.getByText("TAMAMLANDI", { exact: true }).isVisible());
await page.getByRole("button", { name: /Harika, Devam/ }).click();
await page.waitForTimeout(700);

st = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")));
const dayLog = Object.values(st.days)[0];
log("11) workoutDone:", dayLog.workoutDone, "| işaretli egzersiz:", Object.values(dayLog.exercises).filter(Boolean).length, "| süre(sn):", dayLog.activeSeconds, "| session:", st.session);

// --- İLERLEME: ölçüm ---
await page.getByRole("navigation").getByLabel("İlerleme").click();
await page.waitForTimeout(700);
await page.getByRole("button", { name: /^Ölçüm$/ }).click();
await page.waitForTimeout(500);
const mInputs = page.locator('input[inputmode="decimal"]');
await mInputs.nth(0).fill("85.2"); // kilo
await mInputs.nth(2).fill("94");   // bel
await mInputs.nth(4).fill("38");   // kol
await page.getByRole("button", { name: /Ölçümü Kaydet/ }).click();
await page.waitForTimeout(700);
st = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")));
log("12) ölçüm sayısı:", st.measurements.length, "| son:", JSON.stringify(st.measurements[st.measurements.length - 1]));

// metrik değiştir
await page.getByRole("button", { name: "Bel", exact: true }).click();
await page.waitForTimeout(600);
log("13) bel grafiği:", await page.getByText(/Bel • son/).isVisible());

// sil + geri al
const delButtons = page.locator('button[aria-label="Sil"]');
await delButtons.first().click();
await page.waitForTimeout(500);
const afterDel = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")).measurements.length);
await page.getByRole("button", { name: "Geri Al", exact: true }).click();
await page.waitForTimeout(500);
const afterUndo = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")).measurements.length);
log("14) silme/geri alma:", afterDel, "->", afterUndo);

// --- PROFİL ---
await page.getByRole("navigation").getByLabel("Profil").click();
await page.waitForTimeout(700);
await page.getByRole("button", { name: "Profili düzenle" }).click();
await page.waitForTimeout(500);
await page.locator('input[type="text"]').fill("Emre Y.");
await page.getByRole("button", { name: "Kaydet", exact: true }).click();
await page.waitForTimeout(600);
st = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")));
log("15) profil güncellendi:", st.profile.name);

// süre değiştir
await page.getByRole("button", { name: "Düzenle", exact: true }).first().click();
await page.waitForTimeout(500);
await page.getByRole("button", { name: /^180 Gün$/ }).click();
await page.waitForTimeout(500);
st = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")));
log("16) süre değişti:", st.profile.durationDays);

// hatırlatıcılar
await page.getByRole("button", { name: /Hatırlatıcılar & Alarm/ }).click();
await page.waitForTimeout(600);
log("17) hatırlatıcı paneli:", await page.getByText("Hatırlatıcılar & Alarm").first().isVisible(), "| izin kartı:", await page.getByText(/Bildirim izni|Cihaz bildirim|desteklenmiyor/).first().isVisible());
await page.getByRole("button", { name: /Şimdi Dene/ }).first().click();
await page.waitForTimeout(900);
const alarmVisible = await page.getByText("FitLife Hatırlatma", { exact: true }).isVisible().catch(() => false);
log("18) alarm/test tetiklendi:", alarmVisible);
if (alarmVisible) { await page.getByRole("button", { name: "Tamam", exact: true }).click(); await page.waitForTimeout(400); }
await page.getByRole("button", { name: /Yeni Hatırlatıcı/ }).click();
await page.waitForTimeout(500);
await page.locator('input[type="time"]').fill("07:15");
await page.getByRole("button", { name: "Her gün" }).click();
await page.getByRole("button", { name: "Kaydet", exact: true }).last().click();
await page.waitForTimeout(600);
st = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")));
log("19) hatırlatıcı sayısı:", st.reminders.length, "| son:", st.reminders[st.reminders.length - 1].time);

// iç içe paneller: Escape yalnızca en üsttekini kapatmalı
await page.getByRole("button", { name: /Yeni Hatırlatıcı/ }).click();
await page.waitForTimeout(500);
await page.keyboard.press("Escape");
await page.waitForTimeout(600);
const formClosed = !(await page.locator('input[type="time"]').isVisible().catch(() => false));
const listStillOpen = await page.getByText("Hatırlatıcılar & Alarm", { exact: true }).first().isVisible();
log("19b) Escape sadece üst paneli kapattı:", formClosed && listStillOpen);
await page.keyboard.press("Escape");
await page.waitForTimeout(700);

// --- KALICILIK: reload ---
await page.reload({ waitUntil: "networkidle" });
await page.waitForTimeout(2200);
const persisted = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")));
const onHome = await page.getByText(/Günaydın|İyi günler|İyi akşamlar|İyi geceler/).first().isVisible();
log("20) yeniden açılış ana ekran:", onHome, "| profil:", persisted.profile.name, "| ölçüm:", persisted.measurements.length, "| hatırlatıcı:", persisted.reminders.length);

// taşma kontrolü (mobil)
const overflow = await page.evaluate(() => ({
  docW: document.documentElement.scrollWidth,
  winW: window.innerWidth,
  bodyH: document.body.scrollHeight,
  winH: window.innerHeight,
}));
log("21) mobil taşma:", JSON.stringify(overflow));

// masaüstü
await page.setViewportSize({ width: 1440, height: 900 });
await page.waitForTimeout(800);
const deskOverflow = await page.evaluate(() => ({ docW: document.documentElement.scrollWidth, winW: window.innerWidth }));
log("22) masaüstü taşma:", JSON.stringify(deskOverflow));
await page.screenshot({ path: "/tmp/fitlife-desktop.png" });
await page.setViewportSize({ width: 390, height: 844 });
await page.waitForTimeout(600);
await page.screenshot({ path: "/tmp/fitlife-home.png", fullPage: false });

log("\nHATALAR:", errors.length ? errors.join("\n") : "yok");
await browser.close();
