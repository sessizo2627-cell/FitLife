import { chromium } from "playwright";
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: "tr-TR" });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
const k = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const t = k(new Date());
const seed = { version: 2,
  profile: { name: "Deniz", age: 31, height: 176, weight: 82, targetWeight: 76, gender: "erkek", level: "orta", goalId: "kas-gelistirme", durationDays: 60, customDuration: false, startDate: new Date().toISOString(), notifications: false, reminders: true, soundEffects: true, weeklyTarget: 4, stepGoal: 9000, waterGoal: 12 },
  days: {}, measurements: [{ id: "a", date: t, weight: 82 }],
  reminders: [{ id: "r1", kind: "antrenman", title: "Antrenman zamanı", time: "03:03", days: [0,1,2,3,4,5,6], enabled: true, sound: false }],
  session: null };
await page.goto("http://localhost:4173/");
await page.evaluate((s) => localStorage.setItem("fitlife_state_v2", JSON.stringify(s)), seed);
await page.reload({ waitUntil: "networkidle" });
await page.waitForTimeout(2000);

// 1) Program > egzersiz detayı
await page.getByRole("navigation").getByLabel("Programım").click();
await page.waitForTimeout(800);
const infoBtn = page.getByText("Nasıl yapılır · Animasyon").first();
await infoBtn.click();
await page.waitForTimeout(900);
const sheetTitle = await page.locator("h3").filter({ hasText: /Squat|Şınav|Bench|Omuz|Plank|Dumbbell|Romanya|Lunge|Burpee|Kettlebell|Goblet/ }).first().innerText().catch(() => "?");
const anim = await page.locator(".ex-anim").first().getAttribute("data-m");
const steps = await page.locator("ol li").count();
console.log("1) detay açıldı, başlık:", sheetTitle, "| animasyon tipi:", anim, "| adım sayısı:", steps);
await page.screenshot({ path: "test/shots/exercise-detail.png" });

// tüm hareket tipleri render oluyor mu (kütüphane kontrolü)
await page.keyboard.press("Escape");
await page.waitForTimeout(500);

// 2) Erteleme: alarm -> ertele -> kapanır -> 10 dk sonra tekrar (zamanlayıcı yerine kısa süre ile doğrula: 10 dk beklemeden toast + alarm yok)
await page.getByRole("navigation").getByLabel("Profil").click();
await page.waitForTimeout(700);
await page.getByRole("button", { name: /Hatırlatıcılar & Alarm/ }).click();
await page.waitForTimeout(700);
await page.getByRole("button", { name: /Şimdi Dene/ }).first().click();
await page.waitForTimeout(900);
const alarmUp = await page.getByText("FitLife Hatırlatma", { exact: true }).isVisible();
await page.getByRole("button", { name: /Ertele · 10 dk/ }).click();
await page.waitForTimeout(700);
const closedNow = !(await page.getByText("FitLife Hatırlatma", { exact: true }).isVisible().catch(() => false));
const toastMsg = await page.getByText("10 dakika sonra tekrar hatırlatılacak").isVisible();
console.log("2) alarm çaldı:", alarmUp, "| ertelemede kapandı:", closedNow, "| bilgi mesajı:", toastMsg);
await page.screenshot({ path: "test/shots/alarm-light.png" });

// ertelemenin zamanlayıcısını doğrula: sayfa içinde setTimeout ile 10 dk'lık işi hızlandır (fake timers yok; sadece bekleyen zamanlayıcının varlığını test ediyoruz dolaylı olarak)
// 3) Snooze gerçekten tetikleniyor mu: kısa süre için gerçek testte 10 dk beklemek yerine zamanlayıcı hedefi kontrolü
console.log("HATALAR:", errors.length ? errors.join(";") : "yok");
await browser.close();
