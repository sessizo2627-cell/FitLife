import { chromium } from "playwright";
import fs from "node:fs";

const BASE = "http://localhost:4173/";
const errors = [];
const log = (...a) => console.log(...a);

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: "tr-TR", acceptDownloads: true });
await ctx.grantPermissions(["notifications"], { origin: BASE });
const page = await ctx.newPage();
page.on("console", (m) => { if (m.type() === "error") errors.push("CONSOLE: " + m.text()); });
page.on("pageerror", (e) => errors.push("PAGEERROR: " + e.message));

const today = new Date();
const key = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const todayKey = key(today);
const past = (n) => key(new Date(Date.now() - n * 86400000));
const mondayIdx = (today.getDay() + 6) % 7;

const seed = {
  version: 2,
  profile: {
    name: "Deniz Kaya", age: 31, height: 176, weight: 82, targetWeight: 76, gender: "erkek", level: "orta",
    goalId: "kilo-verme", durationDays: 60, customDuration: false, startDate: new Date(Date.now() - 6 * 86400000).toISOString(),
    notifications: true, reminders: true, soundEffects: true, weeklyTarget: 4, stepGoal: 9000, waterGoal: 12,
  },
  days: {
    [past(3)]: { date: past(3), exercises: {}, workoutDone: true, water: 10, steps: 8000, meals: [], activeSeconds: 2700, note: "" },
    [past(2)]: { date: past(2), exercises: {}, workoutDone: true, water: 12, steps: 9500, meals: [], activeSeconds: 3000, note: "" },
    [past(1)]: { date: past(1), exercises: {}, workoutDone: true, water: 9, steps: 7000, meals: [{ id: "m1", name: "Omlet", kcal: 320, protein: 22, time: "08:30" }], activeSeconds: 2400, note: "" },
    [todayKey]: { date: todayKey, exercises: {}, workoutDone: false, water: 3, steps: 1200, meals: [], activeSeconds: 0, note: "" },
  },
  measurements: [
    { id: "a1", date: past(6), weight: 84, waist: 96, arm: 36 },
    { id: "a2", date: past(3), weight: 83.1, waist: 95 },
    { id: "a3", date: todayKey, weight: 82, waist: 94, arm: 37 },
  ],
  reminders: [],
  session: null,
};

await page.goto(BASE);
await page.evaluate((s) => localStorage.setItem("fitlife_state_v2", JSON.stringify(s)), seed);
await page.reload({ waitUntil: "networkidle" });
await page.waitForTimeout(2200);

// A) seri gerçek kayıtlardan hesaplanıyor mu (3 gün)
const streakText = await page.locator("header").innerText();
log("A) header seri (3 bekleniyor):", /3/.test(streakText));

// B) canlı oturum + reload kalıcılığı
await page.getByRole("navigation").getByLabel("Programım").click();
await page.waitForTimeout(700);
await page.getByRole("button", { name: /^Başlat$/ }).click();
await page.waitForTimeout(1200);
await page.getByRole("button", { name: /Seti Tamamla/ }).click();
await page.waitForTimeout(2500);
const beforeReload = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")).session);
await page.reload({ waitUntil: "networkidle" });
await page.waitForTimeout(2400);
const sessionReopened = await page.getByText("Canlı Antrenman", { exact: true }).isVisible().catch(() => false);
const afterReload = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")).session);
log("B) oturum reload sonrası açık:", sessionReopened, "| set korundu:", JSON.stringify(afterReload?.sets), "| çalışıyor:", afterReload?.running);

// duraklat -> süre donmalı
await page.getByRole("button", { name: /Duraklat/ }).click();
await page.waitForTimeout(300);
const t1 = await page.locator("p.tabular-nums").first().innerText();
await page.waitForTimeout(1600);
const t2 = await page.locator("p.tabular-nums").first().innerText();
log("C) duraklatınca süre donuyor:", t1 === t2, `(${t1} / ${t2})`);
await page.getByRole("button", { name: /Antrenmanı Bitir/ }).click();
await page.waitForTimeout(900);
await page.getByRole("button", { name: /Harika, Devam/ }).click();
await page.waitForTimeout(700);

// D) gelecek gün kilidi (yenilemeden sonra sekme Ana Sayfa'ya döner)
await page.getByRole("navigation").getByLabel("Programım").click();
await page.waitForTimeout(800);
const futureIdx = (mondayIdx + 1) % 7;
const dayButtons = page.locator("div.grid.grid-cols-7 > button");
if (futureIdx > mondayIdx) {
  await dayButtons.nth(futureIdx).click();
  await page.waitForTimeout(600);
  const lockNote = await page.getByText(/Bu gün henüz gelmedi/).isVisible();
  const exBefore = await page.evaluate((k) => JSON.parse(localStorage.getItem("fitlife_state_v2")).days[k]?.exercises ?? {}, todayKey);
  await page.locator("button").filter({ hasText: /Dinlenme/ }).first().click().catch(() => {});
  await page.waitForTimeout(400);
  const exAfter = await page.evaluate((k) => JSON.parse(localStorage.getItem("fitlife_state_v2")).days[k]?.exercises ?? {}, todayKey);
  log("D) gelecek gün kilitli:", lockNote, "| bugün etkilenmedi:", JSON.stringify(exBefore) === JSON.stringify(exAfter));
} else {
  log("D) haftanın son günü — gelecek gün testi atlandı");
}

// E) ölçüm düzenleme
await page.getByRole("navigation").getByLabel("İlerleme").click();
await page.waitForTimeout(800);
await page.locator('button[aria-label="Düzenle"]').first().click();
await page.waitForTimeout(600);
const waistInput = page.locator('input[inputmode="decimal"]').nth(2);
await waistInput.fill("91.5");
await page.getByRole("button", { name: /Değişiklikleri Kaydet/ }).click();
await page.waitForTimeout(700);
const edited = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")).measurements.find((m) => m.waist === 91.5));
log("E) ölçüm düzenlendi:", !!edited, edited ? `bel=${edited.waist}` : "");

// geçersiz değer reddedilmeli
await page.locator('button[aria-label="Düzenle"]').first().click();
await page.waitForTimeout(600);
await page.locator('input[inputmode="decimal"]').nth(0).fill("999");
await page.getByRole("button", { name: /Değişiklikleri Kaydet/ }).click();
await page.waitForTimeout(500);
const validationShown = await page.getByText("20–400 arası olmalı").isVisible();
log("F) geçersiz ölçü reddedildi:", validationShown);
await page.locator("div.z-40").first().click({ position: { x: 6, y: 6 } });
await page.waitForTimeout(600);

// G) yedek dışa aktar
await page.getByRole("navigation").getByLabel("Profil").click();
await page.waitForTimeout(800);
const [download] = await Promise.all([
  page.waitForEvent("download"),
  page.getByRole("button", { name: /Verileri Dışa Aktar/ }).click(),
]);
const path = "/tmp/fitlife-backup.json";
await download.saveAs(path);
const backup = JSON.parse(fs.readFileSync(path, "utf8"));
log("G) yedek indirildi:", download.suggestedFilename(), "| ölçüm:", backup.measurements.length, "| gün:", Object.keys(backup.days).length);

// H) sıfırla + geri al
await page.getByRole("button", { name: /Verileri Sıfırla/ }).click();
await page.waitForTimeout(600);
await page.getByRole("button", { name: /Evet, Sıfırla/ }).click();
await page.waitForTimeout(1200);
const cleared = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")).profile);
const onboardingBack = await page.getByText("HEDEFİN", { exact: false }).first().isVisible().catch(() => false);
log("H) sıfırlandı:", cleared === null, "| kurulum ekranı:", onboardingBack);
await page.getByRole("button", { name: "Geri Al", exact: true }).click();
await page.waitForTimeout(1000);
const restored = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")).profile);
log("I) geri alma çalıştı:", restored?.name === "Deniz Kaya");

// I) yedeği içe aktar (farklı veri)
backup.profile.name = "Yedekten Gelen";
fs.writeFileSync("/tmp/fitlife-import.json", JSON.stringify(backup));
await page.getByRole("navigation").getByLabel("Profil").click();
await page.waitForTimeout(700);
await page.locator('input[type="file"]').setInputFiles("/tmp/fitlife-import.json");
await page.waitForTimeout(1200);
const imported = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")).profile.name);
log("J) yedek geri yüklendi:", imported);

// J) gerçek zamanlı hatırlatıcı (bir sonraki dakikaya kur)
const target = new Date(Date.now() + 65000);
const hhmm = `${String(target.getHours()).padStart(2, "0")}:${String(target.getMinutes()).padStart(2, "0")}`;
await page.evaluate(({ hhmm }) => {
  const s = JSON.parse(localStorage.getItem("fitlife_state_v2"));
  s.reminders = [{ id: "live-test", kind: "su", title: "Canlı alarm testi", time: hhmm, days: [0,1,2,3,4,5,6], enabled: true, sound: true }];
  s.profile.reminders = true;
  s.profile.notifications = false; // uygulama içi alarm yolu
  localStorage.setItem("fitlife_state_v2", JSON.stringify(s));
}, { hhmm });
await page.reload({ waitUntil: "networkidle" });
await page.waitForTimeout(2000);
log("K) hatırlatıcı kuruldu:", hhmm, "— tetiklenmesi bekleniyor...");
let fired = false;
for (let i = 0; i < 34; i++) {
  await page.waitForTimeout(2500);
  if (await page.getByText("FitLife Hatırlatma", { exact: true }).isVisible().catch(() => false)) { fired = true; break; }
}
const firedState = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")).reminders[0]?.lastFired);
log("L) zamanı gelince alarm çaldı:", fired, "| lastFired:", firedState);
if (fired) {
  await page.screenshot({ path: "/tmp/fitlife-alarm.png" });
  await page.getByRole("button", { name: "Tamam", exact: true }).click();
  await page.waitForTimeout(500);
}

// K) tekrar tetiklenmemeli (aynı dakika içinde)
await page.waitForTimeout(16000);
const again = await page.getByText("FitLife Hatırlatma", { exact: true }).isVisible().catch(() => false);
log("M) aynı dakikada tekrar çalmadı:", !again);

await page.screenshot({ path: "/tmp/fitlife-final-mobile.png" });
await page.setViewportSize({ width: 1440, height: 900 });
await page.waitForTimeout(700);
await page.screenshot({ path: "/tmp/fitlife-final-desktop.png" });

log("\nHATALAR:", errors.length ? errors.join("\n") : "yok");
await browser.close();
