import { chromium } from "playwright";
import fs from "node:fs";
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: "tr-TR" });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
const k = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const t = k(new Date());
const seed = { version: 2,
  profile: { name: "Deniz", age: 31, height: 176, weight: 82, targetWeight: 76, gender: "erkek", level: "orta", goalId: "kilo-verme", durationDays: 60, customDuration: false, startDate: new Date().toISOString(), notifications: false, reminders: true, soundEffects: true, weeklyTarget: 4, stepGoal: 9000, waterGoal: 12, theme: "light", healthSource: "manual" },
  days: {}, measurements: [{ id: "a", date: t, weight: 82 }], reminders: [], session: null, health: {} };
await page.goto("http://localhost:4173/");
await page.evaluate((s) => localStorage.setItem("fitlife_state_v2", JSON.stringify(s)), seed);
await page.reload({ waitUntil: "networkidle" });
await page.waitForTimeout(2000);
const log = (...a) => console.log(...a);

// 1) Tema: açık -> koyu -> kalıcılık
const bgLight = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
await page.getByRole("navigation").getByLabel("Profil").click();
await page.waitForTimeout(700);
await page.getByRole("button", { name: "Koyu", exact: true }).click();
await page.waitForTimeout(500);
const isDark = await page.evaluate(() => document.documentElement.classList.contains("dark"));
const bgDark = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
await page.reload({ waitUntil: "networkidle" }); await page.waitForTimeout(2000);
const stillDark = await page.evaluate(() => document.documentElement.classList.contains("dark"));
log("1) tema: açık bg", bgLight, "→ koyu bg", bgDark, "| dark sınıfı:", isDark, "| yenilemede korundu:", stillDark);
await page.screenshot({ path: "test/shots/v3-dark-home.png" });

// 2) Keşfet sekmesi + filtre + detay + animasyon gerçekten hareket ediyor mu
await page.getByRole("navigation").getByLabel("Keşfet").click();
await page.waitForTimeout(800);
const count1 = await page.locator("div.grid.grid-cols-2 > button").count();
await page.getByRole("button", { name: "Ekipmansız", exact: true }).click();
await page.waitForTimeout(400);
const count2 = await page.locator("div.grid.grid-cols-2 > button").count();
log("2) keşfet sonuç:", count1, "→ ekipmansız filtresi:", count2, "| azaldı:", count2 < count1 && count2 > 0);
await page.locator("div.grid.grid-cols-2 > button").first().click();
await page.waitForTimeout(600);
const title = await page.locator("h3").last().innerText();
const subTitle = await page.locator("h3").last().locator("xpath=following-sibling::p").innerText().catch(() => "?");
const stepCount = await page.locator("ol li").count();
log("3a) keşfet detayı çözüldü:", !subTitle.includes("Genel") && stepCount >= 3, "|", subTitle, "| adım:", stepCount);
// animasyon: aynı parçanın transform'u zamanla değişiyor mu
const a1 = await page.evaluate(() => { const el = document.querySelector(".ex-anim .tor, .ex-anim .root"); return el ? getComputedStyle(el).transform : null; });
await page.waitForTimeout(700);
const a2 = await page.evaluate(() => { const el = document.querySelector(".ex-anim .tor, .ex-anim .root"); return el ? getComputedStyle(el).transform : null; });
const anyAnim = await page.evaluate(() => [...document.querySelectorAll(".ex-anim *")].some((el) => getComputedStyle(el).animationName !== "none"));
log("3) detay:", title, "| animasyon aktif:", anyAnim, "| transform değişti:", a1 !== a2);
await page.screenshot({ path: "test/shots/v3-exercise-human.png" });
await page.keyboard.press("Escape"); await page.waitForTimeout(500);

// 3) Hızlı rutin başlat -> canlı oturum açılmalı
await page.locator("button").filter({ hasText: /Dakika/ }).first().click();
await page.waitForTimeout(600);
await page.getByRole("button", { name: /Rutini Başlat/ }).click();
await page.waitForTimeout(1000);
const live = await page.getByText("Canlı Antrenman", { exact: true }).isVisible();
const sess = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")).session);
log("4) hızlı rutin oturumu:", live, "| özel rutin:", sess?.custom?.title, "| hareket:", sess?.custom?.exercises?.length);
await page.locator('button[aria-label="Oturumu kapat"]').click(); await page.waitForTimeout(400);
await page.getByRole("button", { name: /Oturumu İptal Et/ }).click(); await page.waitForTimeout(600);

// 4) Beslenme: sekmeler + günlüğe ekle
await page.getByRole("navigation").getByLabel("Keşfet").click(); await page.waitForTimeout(600);
await page.getByRole("button", { name: /Beslenme Önerileri/ }).click(); await page.waitForTimeout(700);
const kcalTxt = await page.locator("text=/\\d[\\d.]* \\/ \\d[\\d.]* kcal/").first().innerText();
await page.getByRole("button", { name: "Haftalık", exact: true }).click(); await page.waitForTimeout(300);
const weekly = await page.locator("ol, div").filter({ hasText: /Haftalık ilkeler/ }).first().isVisible();
await page.getByRole("button", { name: "Aylık", exact: true }).click(); await page.waitForTimeout(300);
const monthly = await page.getByText(/4 haftalık ilerleme planı/).isVisible();
await page.getByRole("button", { name: "Günlük", exact: true }).click(); await page.waitForTimeout(300);
await page.getByRole("button", { name: /Yedim, günlüğe ekle/ }).first().click(); await page.waitForTimeout(500);
const meals = await page.evaluate((d) => JSON.parse(localStorage.getItem("fitlife_state_v2")).days[d]?.meals?.length ?? 0, t);
log("5) beslenme:", kcalTxt, "| haftalık:", weekly, "| aylık:", monthly, "| günlüğe eklendi:", meals === 1);
await page.screenshot({ path: "test/shots/v3-nutrition.png" });
await page.keyboard.press("Escape"); await page.waitForTimeout(500);

// 5) Samsung Health CSV içe aktar
const y = (n) => k(new Date(Date.now() - n*86400000));
fs.writeFileSync("/tmp/com.samsung.shealth.tracker.pedometer_day_summary.csv",
`com.samsung.shealth.tracker.pedometer_day_summary,5,1
create_time,count,day_time,distance
${y(2)} 23:59:00.000,8421,${y(2)} 00:00:00.000,6100
${y(1)} 23:59:00.000,10230,${y(1)} 00:00:00.000,7400
${t} 12:00:00.000,4312,${t} 00:00:00.000,3100
`);
fs.writeFileSync("/tmp/com.samsung.shealth.tracker.heart_rate.csv",
`com.samsung.shealth.tracker.heart_rate,6,1
start_time,heart_rate,heart_rate_min,heart_rate_max,end_time
${y(1)} 08:00:00.000,62,58,70,${y(1)} 08:10:00.000
${y(1)} 18:00:00.000,118,95,142,${y(1)} 18:30:00.000
${t} 09:00:00.000,66,60,74,${t} 09:10:00.000
`);
fs.writeFileSync("/tmp/com.samsung.shealth.sleep.csv",
`com.samsung.shealth.sleep,4,1
start_time,end_time,sleep_duration
${y(1)} 23:30:00.000,${t} 06:50:00.000,440
`);
await page.getByRole("navigation").getByLabel("Profil").click(); await page.waitForTimeout(700);
await page.getByRole("button", { name: /Samsung Health/ }).click(); await page.waitForTimeout(700);
const bridgeNote = await page.getByText(/Doğrudan bağlantı yalnızca Android/).isVisible();
await page.locator('input[type="file"][accept*="csv"]').setInputFiles(["/tmp/com.samsung.shealth.tracker.pedometer_day_summary.csv","/tmp/com.samsung.shealth.tracker.heart_rate.csv","/tmp/com.samsung.shealth.sleep.csv"]);
await page.waitForTimeout(1200);
const st = await page.evaluate(() => JSON.parse(localStorage.getItem("fitlife_state_v2")));
const hToday = st.health[t]; const hY = st.health[y(1)];
log("6) sağlık: tarayıcı notu:", bridgeNote, "| gün:", Object.keys(st.health).length, "| bugün adım:", hToday?.steps, "nabız:", hToday?.heartRateAvg, "| dün nabız ort/min/max:", hY?.heartRateAvg, hY?.heartRateMin, hY?.heartRateMax, "| dün uyku dk:", hY?.sleepMinutes, "| kaynak:", st.profile.healthSource);
log("   adım günlüğe yansıdı:", st.days[t]?.steps === 4312);
await page.screenshot({ path: "test/shots/v3-health.png" });
await page.keyboard.press("Escape"); await page.waitForTimeout(500);
await page.getByRole("navigation").getByLabel("Ana Sayfa").click(); await page.waitForTimeout(800);
const hrCard = await page.getByText(/Samsung Health • bugün/).isVisible();
log("7) ana ekranda nabız kartı:", hrCard);
await page.screenshot({ path: "test/shots/v3-home-health.png" });

// 6) Açık temaya dön, taşma kontrolü
await page.getByRole("navigation").getByLabel("Profil").click(); await page.waitForTimeout(600);
await page.getByRole("button", { name: "Açık", exact: true }).click(); await page.waitForTimeout(400);
const ov = await page.evaluate(() => ({ docW: document.documentElement.scrollWidth, winW: innerWidth }));
log("8) taşma:", JSON.stringify(ov));
log("HATALAR:", errors.length ? errors.join(" | ") : "yok");
await browser.close();
