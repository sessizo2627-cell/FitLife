export type GoalId = "kilo-verme" | "kilo-alma" | "kas-gelistirme" | "form-koruma";

export interface Goal {
  id: GoalId;
  title: string;
  short: string;
  desc: string;
  detail: string;
  icon: string;
  tag: string;
  weeklyFocus: string[];
  calories: string;
  protein: string;
  cardioNote: string;
  image: string;
}

export interface UserProfile {
  name: string;
  age: number;
  height: number;
  weight: number;
  targetWeight: number;
  gender: "erkek" | "kadin";
  level: "baslangic" | "orta" | "ileri";
  goalId: GoalId;
  durationDays: number;
  customDuration: boolean;
  startDate: string;
  notifications: boolean;
  reminders: boolean;
  soundEffects: boolean;
  weeklyTarget: number;
  stepGoal: number;
  waterGoal: number;
  theme: "light" | "dark" | "system";
  healthSource: "manual" | "samsung";
}

/** Samsung Health / Health Connect'ten alınan günlük sağlık özeti */
export interface HealthSample {
  date: string;
  steps?: number;
  heartRateAvg?: number;
  heartRateMin?: number;
  heartRateMax?: number;
  restingHeartRate?: number;
  caloriesBurned?: number;
  distanceKm?: number;
  sleepMinutes?: number;
  spo2?: number;
  source: "samsung" | "manual";
  importedAt: string;
}

export interface Meal {
  id: string;
  name: string;
  kcal: number;
  protein: number;
  time: string;
}

export interface DayLog {
  date: string;
  /** egzersiz anahtarı -> tamamlandı */
  exercises: Record<string, boolean>;
  workoutDone: boolean;
  water: number;
  steps: number;
  meals: Meal[];
  activeSeconds: number;
  note: string;
}

export interface Measurement {
  id: string;
  date: string; // yyyy-mm-dd
  weight?: number;
  chest?: number;
  waist?: number;
  hips?: number;
  arm?: number;
  thigh?: number;
  neck?: number;
  bodyFat?: number;
}

export type ReminderKind = "antrenman" | "su" | "olcum" | "ogun" | "ozel";

export interface Reminder {
  id: string;
  kind: ReminderKind;
  title: string;
  time: string; // HH:mm
  days: number[]; // 0=Pzt ... 6=Paz
  enabled: boolean;
  sound: boolean;
  lastFired?: string; // yyyy-mm-ddTHH:mm
}

export interface ActiveSession {
  date: string;
  dayIndex: number;
  goalId: GoalId;
  startedAt: number;
  accumulated: number; // ms, duraklatmaya kadar
  running: boolean;
  currentIndex: number;
  sets: Record<number, number>;
  restUntil: number | null;
  restTotal: number;
  /** Keşfet rutini: planın dışından egzersiz listesi */
  custom?: { title: string; exercises: { name: string; sets: string; rest: string }[] };
}

export interface FitLifeState {
  version: number;
  profile: UserProfile | null;
  days: Record<string, DayLog>;
  measurements: Measurement[];
  reminders: Reminder[];
  session: ActiveSession | null;
  health: Record<string, HealthSample>;
}

export type TabId = "home" | "program" | "discover" | "progress" | "profile";
