import { useMemo, useState } from "react";
import { Compass, Search, Clock, Flame, Play, Sparkles, ChevronRight, Utensils } from "lucide-react";
import type { GoalId } from "../types";
import { useStore } from "../store/store";
import { useFeedback } from "./Feedback";
import { WEEKLY_PLAN, getGoal } from "../data/fitness";
import { DISCOVER_TAGS, QUICK_ROUTINES, discover, type QuickRoutine } from "../data/discover";
import { getExercise } from "../data/exercises";
import ExerciseAnimation, { ExerciseSheet } from "./ExerciseAnimation";
import { Card, Chip, EmptyState, NeonButton, SectionTitle, Sheet } from "./ui";
import NutritionPanel from "./NutritionPanel";
import { cn } from "../utils/cn";

const LEVELS: { id: "baslangic" | "orta" | "ileri"; label: string }[] = [
  { id: "baslangic", label: "Başlangıç" },
  { id: "orta", label: "Orta" },
  { id: "ileri", label: "İleri" },
];

export default function DiscoverScreen({ onStartRoutine }: { onStartRoutine: (r: QuickRoutine) => void }) {
  const { state } = useStore();
  const { toast } = useFeedback();
  const profile = state.profile!;
  const goal = getGoal(profile.goalId);

  const [query, setQuery] = useState("");
  const [tag, setTag] = useState<string | undefined>();
  const [level, setLevel] = useState<"baslangic" | "orta" | "ileri" | undefined>(profile.level);
  const [onlyGoal, setOnlyGoal] = useState(true);
  const [detail, setDetail] = useState<string | null>(null);
  const [routine, setRoutine] = useState<QuickRoutine | null>(null);
  const [nutritionOpen, setNutritionOpen] = useState(false);

  const inPlan = useMemo(() => new Set(WEEKLY_PLAN[profile.goalId].flatMap((d) => d.exercises.map((e) => e.name))), [profile.goalId]);
  const results = useMemo(
    () => discover({ goal: onlyGoal ? (profile.goalId as GoalId) : undefined, level, tag, query }, inPlan),
    [onlyGoal, profile.goalId, level, tag, query, inPlan]
  );
  const routines = QUICK_ROUTINES.filter((r) => r.goals.includes(profile.goalId));

  return (
    <div className="space-y-5 px-4 pb-6 pt-4">
      <div className="px-1">
        <div className="flex items-center gap-2 text-[var(--c-acc)]">
          <Compass size={16} />
          <span className="text-[11px] font-bold uppercase tracking-[0.2em]">Keşfet</span>
        </div>
        <h2 className="font-display mt-1 text-[26px] text-[var(--c-text)]">EKSTRA <span className="text-[var(--c-acc)]">HAREKETLER</span></h2>
        <p className="mt-1 text-[12.5px] text-[var(--c-sub)]">{goal.title} hedefine uygun, programında olmayan egzersizler ve hızlı rutinler.</p>
      </div>

      {/* beslenme kısayolu */}
      <button onClick={() => setNutritionOpen(true)} className="flex w-full items-center gap-3 rounded-2xl border border-[var(--c-accline)] bg-[var(--c-tint)] p-4 text-left active:scale-[0.99]">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--c-acc)] text-white dark:text-[#04110a]"><Utensils size={20} /></span>
        <span className="min-w-0 flex-1">
          <span className="block text-[14px] font-extrabold text-[var(--c-text)]">Beslenme Önerileri</span>
          <span className="block truncate text-[12px] text-[var(--c-sub)]">Hedefine göre günlük, haftalık ve aylık plan</span>
        </span>
        <ChevronRight size={18} className="text-[var(--c-mute)]" />
      </button>

      {/* hızlı rutinler */}
      <div>
        <SectionTitle title="Hızlı Rutinler" subtitle="Tek dokunuşla başlat" />
        <div className="no-scrollbar -mx-4 flex gap-2.5 overflow-x-auto px-4 pb-1">
          {routines.map((r) => (
            <button key={r.id} onClick={() => setRoutine(r)} className="w-[230px] shrink-0 text-left active:scale-[0.99]">
              <Card className="h-full overflow-hidden">
                <div className="flex items-center justify-between bg-gradient-to-br from-[var(--c-tint)] to-[var(--c-bg1)] p-3.5">
                  <ExerciseAnimation motion={getExercise(r.exercises[0].name).motion} label={r.title} size={64} />
                  <span className="grid h-9 w-9 place-items-center rounded-full bg-[var(--c-acc)] text-white dark:text-[#04110a]"><Play size={15} fill="currentColor" /></span>
                </div>
                <div className="p-3.5">
                  <p className="text-[13.5px] font-extrabold leading-snug text-[var(--c-text)]">{r.title}</p>
                  <p className="mt-0.5 text-[11.5px] text-[var(--c-sub)]">{r.desc}</p>
                  <div className="mt-2 flex gap-1.5">
                    <Chip active><Clock size={10} /> {r.minutes} dk</Chip>
                    <Chip>{LEVELS.find((l) => l.id === r.level)?.label}</Chip>
                  </div>
                </div>
              </Card>
            </button>
          ))}
        </div>
      </div>

      {/* filtreler */}
      <div>
        <SectionTitle title="Egzersiz Kütüphanesi" subtitle={`${results.length} öneri`} />
        <div className="mb-2 flex items-center gap-2 rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg1)] px-3.5">
          <Search size={16} className="text-[var(--c-mute)]" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Hareket, kas grubu veya etiket ara" className="w-full bg-transparent py-3 text-[13.5px] font-semibold text-[var(--c-text)] outline-none placeholder:font-medium placeholder:text-[var(--c-mute2)]" />
          {query && <button onClick={() => setQuery("")} className="text-[12px] font-bold text-[var(--c-mute)]">Temizle</button>}
        </div>
        <div className="no-scrollbar -mx-4 flex gap-1.5 overflow-x-auto px-4 pb-1">
          <button onClick={() => setOnlyGoal((v) => !v)} className={cn("shrink-0 rounded-full border px-3 py-1.5 text-[12px] font-bold active:scale-95", onlyGoal ? "border-[var(--c-acc)] bg-[var(--c-acc)] text-white dark:text-[#04110a]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-text2)]")}>
            <Sparkles size={11} className="mr-1 inline" /> Hedefime uygun
          </button>
          {LEVELS.map((l) => (
            <button key={l.id} onClick={() => setLevel(level === l.id ? undefined : l.id)} className={cn("shrink-0 rounded-full border px-3 py-1.5 text-[12px] font-bold active:scale-95", level === l.id ? "border-[var(--c-acc)] bg-[var(--c-tint)] text-[var(--c-acc)]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-text2)]")}>
              {l.label}
            </button>
          ))}
        </div>
        <div className="no-scrollbar -mx-4 mt-1.5 flex gap-1.5 overflow-x-auto px-4 pb-1">
          {DISCOVER_TAGS.map((t) => (
            <button key={t.id} onClick={() => setTag(tag === t.id ? undefined : t.id)} className={cn("shrink-0 rounded-full border px-3 py-1.5 text-[12px] font-bold active:scale-95", tag === t.id ? "border-[var(--c-acc)] bg-[var(--c-tint)] text-[var(--c-acc)]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-text2)]")}>
              {t.label}
            </button>
          ))}
        </div>

        {results.length === 0 ? (
          <div className="mt-3">
            <EmptyState icon={<Compass size={20} />} title="Eşleşen hareket yok" desc="Filtreleri gevşet ya da 'Hedefime uygun' seçeneğini kapat." action={<NeonButton variant="ghost" onClick={() => { setTag(undefined); setLevel(undefined); setOnlyGoal(false); setQuery(""); }}>Filtreleri Temizle</NeonButton>} />
          </div>
        ) : (
          <div className="mt-3 grid grid-cols-2 gap-2.5">
            {results.map((e) => (
              <button key={e.name} onClick={() => setDetail(e.name)} className="text-left active:scale-[0.99]">
                <Card className="h-full overflow-hidden">
                  <ExerciseAnimation motion={e.motion} label={e.name} size={9999} className="!h-[118px] !w-full rounded-none" />
                  <div className="p-3">
                    <p className="line-clamp-2 text-[13px] font-extrabold leading-snug text-[var(--c-text)]">{e.name}</p>
                    <p className="mt-0.5 text-[11px] text-[var(--c-sub)]">{e.group}</p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      <Chip><Clock size={10} /> {e.minutes} dk</Chip>
                      <Chip><Flame size={10} /> {e.kcal} kcal</Chip>
                    </div>
                  </div>
                </Card>
              </button>
            ))}
          </div>
        )}
      </div>

      <ExerciseSheet name={detail} onClose={() => setDetail(null)} />

      <Sheet open={!!routine} onClose={() => setRoutine(null)} title={routine?.title ?? ""} subtitle={routine ? `${routine.minutes} dk • ${routine.exercises.length} hareket • ${LEVELS.find((l) => l.id === routine.level)?.label}` : undefined}>
        {routine && (
          <div className="space-y-2">
            {routine.exercises.map((x, i) => (
              <button key={i} onClick={() => setDetail(x.name)} className="flex w-full items-center gap-3 rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] p-3 text-left active:scale-[0.99]">
                <ExerciseAnimation motion={getExercise(x.name).motion} label={x.name} size={52} />
                <span className="min-w-0 flex-1">
                  <span className="block text-[13.5px] font-bold text-[var(--c-text)]">{x.name}</span>
                  <span className="block text-[11.5px] text-[var(--c-sub)]">{x.sets}{x.rest !== "-" ? ` • Dinlenme ${x.rest}` : ""}</span>
                </span>
                <ChevronRight size={16} className="text-[var(--c-mute)]" />
              </button>
            ))}
            <NeonButton
              onClick={() => {
                onStartRoutine(routine);
                setRoutine(null);
                toast(`${routine.title} başlatıldı`);
              }}
              className="mt-2 flex w-full items-center justify-center gap-2"
            >
              <Play size={16} fill="currentColor" /> Rutini Başlat
            </NeonButton>
          </div>
        )}
      </Sheet>

      <NutritionPanel open={nutritionOpen} onClose={() => setNutritionOpen(false)} />
    </div>
  );
}
