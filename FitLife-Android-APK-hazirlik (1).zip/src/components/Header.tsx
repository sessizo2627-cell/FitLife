import { Bell, Flame, Dumbbell, Volume2, VolumeX, AlarmClock, Droplets, CheckCircle2, TrendingUp } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { Reminder, TabId } from "../types";
import { useFeedback } from "./Feedback";
import { unlockAudio } from "../lib/notify";
import { cn } from "../utils/cn";

export default function Header({
  name,
  streak,
  water,
  waterGoal,
  progress,
  workoutDone,
  upcoming,
  remindersEnabled,
  onNavigate,
}: {
  name: string;
  streak: number;
  water: number;
  waterGoal: number;
  progress: number;
  workoutDone: boolean;
  upcoming: { reminder: Reminder; at: Date } | null;
  remindersEnabled: boolean;
  onNavigate: (t: TabId) => void;
}) {
  const [open, setOpen] = useState(false);
  const { muted, setMuted, toast } = useFeedback();
  const initial = (name?.trim()?.[0] ?? "F").toLocaleUpperCase("tr-TR");

  const items = [
    workoutDone
      ? { icon: CheckCircle2, color: "#00e676", title: "Bugünkü antrenman tamam", desc: "Harika iş! Yarının planı hazır.", tab: "program" as TabId }
      : { icon: Dumbbell, color: "#00e676", title: "Antrenman bekliyor", desc: `Günlük hedefinin %${progress} tamamlandı.`, tab: "program" as TabId },
    water < waterGoal
      ? { icon: Droplets, color: "#38bdf8", title: "Su hedefi tamamlanmadı", desc: `${water}/${waterGoal} bardak içtin.`, tab: "home" as TabId }
      : { icon: Droplets, color: "#38bdf8", title: "Su hedefi tamam", desc: `${water} bardak — hidrasyon süper.`, tab: "home" as TabId },
    upcoming && remindersEnabled
      ? {
          icon: AlarmClock,
          color: "#ffb020",
          title: `Sıradaki: ${upcoming.reminder.title}`,
          desc: upcoming.at.toLocaleString("tr-TR", { weekday: "long", hour: "2-digit", minute: "2-digit" }),
          tab: "profile" as TabId,
        }
      : { icon: AlarmClock, color: "var(--c-mute)", title: remindersEnabled ? "Aktif hatırlatıcı yok" : "Hatırlatıcılar kapalı", desc: "Profil › Hatırlatıcılar bölümünden kur.", tab: "profile" as TabId },
    { icon: TrendingUp, color: "#a78bfa", title: `${streak} günlük seri`, desc: "Ölçüm girerek gelişimini grafiğe işle.", tab: "progress" as TabId },
  ];

  return (
    <header className="relative z-30 border-b border-[var(--c-line)] bg-[var(--c-bg0)]/95 backdrop-blur-xl">
      <div className="flex items-center justify-between gap-2 px-3.5 py-3">
        <button onClick={() => onNavigate("home")} className="flex items-center gap-2.5 active:scale-95">
          <div className="glow-green grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-b from-[#00e676] to-[#00b248]">
            <Dumbbell size={20} strokeWidth={2.6} className="text-[#04110a]" />
          </div>
          <div className="text-left leading-tight">
            <p className="font-display whitespace-nowrap text-[18px] tracking-wide text-[var(--c-text)]">
              FIT<span className="text-[var(--c-acc)]">LIFE</span>
            </p>
            <p className="whitespace-nowrap text-[8.5px] font-semibold uppercase tracking-[0.14em] text-[var(--c-mute)]">Gücünü İnşa Et</p>
          </div>
        </button>

        <div className="flex shrink-0 items-center gap-1.5">
          <div className="flex items-center gap-1 rounded-full border border-[#00e676]/25 bg-[#00e676]/10 px-2 py-1.5">
            <Flame size={15} className="text-[var(--c-acc)]" fill="#00e676" />
            <span className="text-[13px] font-extrabold text-[var(--c-acc)]">{streak}</span>
          </div>
          <button
            onClick={() => {
              const next = !muted;
              setMuted(next);
              if (!next) unlockAudio();
              toast(next ? "Tüm sesler kapatıldı" : "Sesler açıldı", { tone: "info" });
            }}
            className={cn(
              "grid h-10 w-10 place-items-center rounded-full border active:scale-95",
              muted ? "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-mute)]" : "border-[#00e676]/30 bg-[#00e676]/10 text-[var(--c-acc)]"
            )}
            aria-label={muted ? "Sesleri aç" : "Sesleri kapat"}
          >
            {muted ? <VolumeX size={17} /> : <Volume2 size={17} />}
          </button>
          <button
            onClick={() => setOpen((v) => !v)}
            className="relative grid h-9 w-9 place-items-center rounded-full border border-[var(--c-line2)] bg-[var(--c-bg1)] text-[var(--c-text2)] active:scale-95"
            aria-label="Bildirimler"
          >
            <Bell size={18} />
            {!workoutDone && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[#00e676] shadow-[0_0_8px_#00e676]" />}
          </button>
          <button onClick={() => onNavigate("profile")} className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-[var(--c-tint2)] to-[var(--c-bg1)] text-[14px] font-extrabold text-[var(--c-acc)] ring-1 ring-[#00e676]/40 active:scale-95" aria-label="Profil">
            {initial}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-[-1]" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: -8, height: 0 }}
              animate={{ opacity: 1, y: 0, height: "auto" }}
              exit={{ opacity: 0, y: -8, height: 0 }}
              className="overflow-hidden"
            >
              <div className="mx-4 mb-3 overflow-hidden rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)]">
                <div className="flex items-center justify-between border-b border-[var(--c-line)] px-4 py-2.5">
                  <p className="text-[11px] font-extrabold uppercase tracking-[0.18em] text-[var(--c-mute)]">Bugünün Durumu</p>
                  <button onClick={() => { setOpen(false); onNavigate("profile"); }} className="text-[11.5px] font-bold text-[var(--c-acc)]">
                    Hatırlatıcılar
                  </button>
                </div>
                {items.map((n, i) => (
                  <button
                    key={i}
                    onClick={() => { setOpen(false); onNavigate(n.tab); }}
                    className="flex w-full gap-3 border-b border-[var(--c-line)] px-4 py-3 text-left last:border-0 active:bg-[var(--c-text)]/[0.03]"
                  >
                    <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg" style={{ background: `${n.color}1f`, color: n.color }}>
                      <n.icon size={15} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-[13px] font-bold text-[var(--c-text)]">{n.title}</span>
                      <span className="block text-[12px] text-[var(--c-sub)]">{n.desc}</span>
                    </span>
                  </button>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
