import { useMemo, useRef, useState } from "react";
import { HeartPulse, Footprints, Moon, Flame, Smartphone, Upload, Trash2, RefreshCw, Info, Activity, Wind, MapPin, ExternalLink } from "lucide-react";
import type { HealthSample } from "../types";
import { useStore } from "../store/store";
import { useFeedback } from "./Feedback";
import { nativeBridge, parseSamsungCSV, readFromBridge, heartZone } from "../lib/health";
import { dateKey, longDate, shortDate } from "../lib/date";
import { Sheet, Card, EmptyState, NeonButton } from "./ui";
import { cn } from "../utils/cn";

const KIND_LABEL: Record<string, string> = { steps: "adım", heart: "nabız", sleep: "uyku", spo2: "oksijen", exercise: "egzersiz", unknown: "tanınmayan" };

export default function HealthPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { state, dispatch, snapshot, undo } = useStore();
  const { toast } = useFeedback();
  const profile = state.profile!;
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const bridge = nativeBridge();

  const samples = useMemo(() => Object.values(state.health).sort((a, b) => b.date.localeCompare(a.date)), [state.health]);
  const today = state.health[dateKey()];
  const latest = samples[0];
  const last7 = samples.slice(0, 7);
  const avg = (k: keyof HealthSample) => {
    const vals = last7.map((s) => s[k]).filter((v): v is number => typeof v === "number");
    return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : undefined;
  };

  const syncNative = async () => {
    setBusy(true);
    try {
      const rows = await readFromBridge(30);
      dispatch({ type: "UPSERT_HEALTH", samples: rows });
      dispatch({ type: "PATCH_PROFILE", patch: { healthSource: "samsung" } });
      toast(`${rows.length} günlük Samsung Health verisi alındı`);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Senkronizasyon başarısız", { tone: "danger" });
    } finally {
      setBusy(false);
    }
  };

  const importFiles = async (files: FileList) => {
    setBusy(true);
    let total = 0;
    const kinds: string[] = [];
    try {
      for (const f of Array.from(files)) {
        const text = await f.text();
        const { kind, samples: rows } = parseSamsungCSV(f.name, text);
        if (kind === "unknown" || rows.length === 0) {
          toast(`${f.name}: tanınan veri bulunamadı`, { tone: "danger" });
          continue;
        }
        dispatch({ type: "UPSERT_HEALTH", samples: rows });
        total += rows.length;
        kinds.push(KIND_LABEL[kind]);
      }
      if (total) {
        dispatch({ type: "PATCH_PROFILE", patch: { healthSource: "samsung" } });
        toast(`${total} günlük kayıt içe aktarıldı (${[...new Set(kinds)].join(", ")})`);
      }
    } finally {
      setBusy(false);
    }
  };

  const clearAll = () => {
    snapshot();
    dispatch({ type: "CLEAR_HEALTH" });
    dispatch({ type: "PATCH_PROFILE", patch: { healthSource: "manual" } });
    toast("Sağlık verileri silindi", { tone: "danger", actionLabel: "Geri Al", onAction: () => undo() });
  };

  const zone = (today?.heartRateAvg ?? latest?.heartRateAvg) ? heartZone((today?.heartRateAvg ?? latest!.heartRateAvg)!, profile.age) : null;

  return (
    <Sheet open={open} onClose={onClose} title="Samsung Health" subtitle="Adım, nabız, uyku ve diğer sağlık verilerini FitLife'a aktar.">
      {/* bağlantı durumu */}
      <div className={cn("rounded-2xl border p-3.5", bridge ? "border-[var(--c-accline)] bg-[var(--c-tint)]" : "border-[var(--c-line3)] bg-[var(--c-bg2)]")}>
        <div className="flex items-start gap-3">
          <span className={cn("grid h-10 w-10 shrink-0 place-items-center rounded-xl", bridge ? "bg-[var(--c-acc)] text-white dark:text-[#04110a]" : "bg-[var(--c-bg1)] text-[var(--c-sub)]")}>
            <Smartphone size={18} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[13.5px] font-extrabold text-[var(--c-text)]">
              {bridge ? "Health Connect köprüsü hazır" : "Doğrudan bağlantı yalnızca Android uygulamasında"}
            </p>
            <p className="mt-0.5 text-[12px] leading-relaxed text-[var(--c-sub)]">
              {bridge
                ? "Uygulama Samsung Health verilerini Health Connect üzerinden okuyabilir."
                : "Tarayıcılar Samsung Health'e erişemez. APK sürümünde Health Connect ile otomatik okunur; şimdilik Samsung Health'ten dışa aktardığın dosyaları yükleyebilirsin."}
            </p>
            {bridge ? (
              <button onClick={syncNative} disabled={busy} className="mt-2 flex items-center gap-1.5 rounded-lg bg-[var(--c-acc)] px-3 py-2 text-[12px] font-extrabold text-white active:scale-95 disabled:opacity-60 dark:text-[#04110a]">
                <RefreshCw size={13} className={busy ? "animate-spin" : ""} /> Şimdi Senkronize Et
              </button>
            ) : null}
          </div>
        </div>
      </div>

      {/* dosya içe aktarma */}
      <div className="mt-3 rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] p-3.5">
        <p className="flex items-center gap-1.5 text-[12px] font-bold uppercase tracking-wider text-[var(--c-sub)]"><Upload size={13} /> Dosyadan içe aktar</p>
        <ol className="mt-2 space-y-1 text-[12.5px] leading-relaxed text-[var(--c-text2)]">
          <li>1. Samsung Health › Ayarlar › <b>Kişisel verileri indir</b></li>
          <li>2. İndirilen klasördeki <b>step_count</b>, <b>heart_rate</b>, <b>sleep</b>, <b>oxygen_saturation</b> CSV dosyalarını seç</li>
          <li>3. Veriler günlere göre birleştirilir; adımlar günlük kayda da işlenir</li>
        </ol>
        <input ref={fileRef} type="file" accept=".csv,text/csv" multiple className="hidden" onChange={(e) => { if (e.target.files?.length) void importFiles(e.target.files); e.target.value = ""; }} />
        <NeonButton onClick={() => fileRef.current?.click()} className="mt-3 flex w-full items-center justify-center gap-2">
          <Upload size={15} /> CSV Dosyalarını Seç
        </NeonButton>
        <a href="https://www.samsung.com/tr/support/apps-services/samsung-health-verilerini-indirme/" target="_blank" rel="noreferrer" className="mt-2 flex items-center justify-center gap-1 text-[11.5px] font-semibold text-[var(--c-acc)]">
          Samsung'un dışa aktarma kılavuzu <ExternalLink size={11} />
        </a>
      </div>

      {/* özet */}
      {samples.length === 0 ? (
        <div className="mt-4">
          <EmptyState icon={<HeartPulse size={20} />} title="Henüz sağlık verisi yok" desc="Senkronize et ya da CSV yükle; adım, nabız ve uyku burada görünür." />
        </div>
      ) : (
        <>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <Card className="p-3.5">
              <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[var(--c-sub)]"><HeartPulse size={13} className="text-[var(--c-red)]" /> Nabız</p>
              <p className="mt-1 text-[22px] font-extrabold leading-none text-[var(--c-text)]">{today?.heartRateAvg ?? latest?.heartRateAvg ?? "—"} <span className="text-[11px] font-semibold text-[var(--c-mute)]">bpm ort.</span></p>
              {zone && <p className="mt-1 text-[11px] font-bold" style={{ color: zone.color }}>{zone.label} bölgesi</p>}
              {(today?.heartRateMin || latest?.heartRateMin) && <p className="text-[10.5px] text-[var(--c-mute)]">min {today?.heartRateMin ?? latest?.heartRateMin} • maks {today?.heartRateMax ?? latest?.heartRateMax}</p>}
            </Card>
            <Card className="p-3.5">
              <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[var(--c-sub)]"><Footprints size={13} className="text-[var(--c-violet)]" /> Adım</p>
              <p className="mt-1 text-[22px] font-extrabold leading-none text-[var(--c-text)]">{(today?.steps ?? latest?.steps)?.toLocaleString("tr-TR") ?? "—"}</p>
              <p className="mt-1 text-[10.5px] text-[var(--c-mute)]">7 gün ort. {avg("steps")?.toLocaleString("tr-TR") ?? "—"}</p>
            </Card>
            <Card className="p-3.5">
              <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[var(--c-sub)]"><Moon size={13} className="text-[var(--c-blue)]" /> Uyku</p>
              <p className="mt-1 text-[22px] font-extrabold leading-none text-[var(--c-text)]">{(today?.sleepMinutes ?? latest?.sleepMinutes) ? `${Math.floor((today?.sleepMinutes ?? latest!.sleepMinutes!) / 60)}s ${(today?.sleepMinutes ?? latest!.sleepMinutes!) % 60}dk` : "—"}</p>
              <p className="mt-1 text-[10.5px] text-[var(--c-mute)]">7 gün ort. {avg("sleepMinutes") ? `${Math.round(avg("sleepMinutes")! / 60 * 10) / 10} saat` : "—"}</p>
            </Card>
            <Card className="p-3.5">
              <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[var(--c-sub)]"><Flame size={13} className="text-[var(--c-amber)]" /> Yakılan</p>
              <p className="mt-1 text-[22px] font-extrabold leading-none text-[var(--c-text)]">{(today?.caloriesBurned ?? latest?.caloriesBurned)?.toLocaleString("tr-TR") ?? "—"} <span className="text-[11px] font-semibold text-[var(--c-mute)]">kcal</span></p>
              <p className="mt-1 flex items-center gap-1 text-[10.5px] text-[var(--c-mute)]"><Wind size={10} /> SpO₂ {today?.spo2 ?? latest?.spo2 ?? "—"}% <MapPin size={10} className="ml-1" /> {today?.distanceKm ?? latest?.distanceKm ?? "—"} km</p>
            </Card>
          </div>

          {/* son 7 gün */}
          <p className="mb-2 mt-4 px-1 text-[12px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Son kayıtlar</p>
          <Card className="divide-y divide-[var(--c-line)]">
            {samples.slice(0, 10).map((s) => (
              <div key={s.date} className="flex items-center gap-3 px-3.5 py-2.5">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[var(--c-tint)] text-[var(--c-acc)]"><Activity size={15} /></span>
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-bold text-[var(--c-text)]">{longDate(s.date)}</p>
                  <p className="truncate text-[11px] text-[var(--c-sub)]">
                    {[s.steps !== undefined && `${s.steps.toLocaleString("tr-TR")} adım`, s.heartRateAvg !== undefined && `${s.heartRateAvg} bpm`, s.sleepMinutes !== undefined && `${Math.round(s.sleepMinutes / 60 * 10) / 10} sa uyku`, s.caloriesBurned !== undefined && `${s.caloriesBurned} kcal`].filter(Boolean).join(" • ")}
                  </p>
                </div>
                <span className="text-[10px] font-semibold text-[var(--c-mute)]">{shortDate(s.date)}</span>
              </div>
            ))}
          </Card>

          <button onClick={clearAll} className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-2xl border border-[var(--c-red)]/30 bg-[var(--c-red)]/[0.06] py-3 text-[13px] font-bold text-[var(--c-red)] active:scale-[0.99]">
            <Trash2 size={14} /> Sağlık verilerini sil
          </button>
        </>
      )}

      <p className="mt-4 flex gap-2 rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg2)] p-3 text-[11.5px] leading-relaxed text-[var(--c-mute)]">
        <Info size={26} className="shrink-0 text-[var(--c-blue)]" />
        Veriler yalnızca bu cihazda saklanır, hiçbir sunucuya gönderilmez. Samsung hesabı veya şifre istenmez.
      </p>
    </Sheet>
  );
}
