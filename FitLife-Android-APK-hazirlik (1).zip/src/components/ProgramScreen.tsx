import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Clock, Flame, Dumbbell, Play, Check, Lock, RotateCcw, NotebookPen, CalendarCheck, Timer } from "lucide-react";
import { useStore } from "../store/store";
import { useFeedback } from "./Feedback";
import { getGoal, WEEKLY_PLAN } from "../data/fitness";
import { dayProgress, exKey, getDay, isDayComplete } from "../lib/calc";
import { DAY_SHORT, currentWeekDates, dateKey, longDate, mondayIndex, programDay, shortDate } from "../lib/date";
import { Card, Chip, ProgressBar, NeonButton, Sheet, SectionTitle } from "./ui";
import { ExerciseSheet } from "./ExerciseAnimation";
import { Info } from "lucide-react";
import { useStartSession } from "./WorkoutSession";
import { cn } from "../utils/cn";

function phases(total: number) {
  if (total <= 7) return [{ name: "Yoğun Hafta", range: `1 – ${total}. gün`, desc: "Tek haftalık odaklı yüklenme.", start: 1, end: total }];
  if (total <= 30)
    return [
      { name: "Adaptasyon", range: "1 – 10. gün", desc: "Teknik ve hafif-orta yük.", start: 1, end: 10 },
      { name: "Yüklenme", range: "11 – 20. gün", desc: "Kademeli ağırlık artışı.", start: 11, end: 20 },
      { name: "Zirve", range: "21 – 30. gün", desc: "Yoğunluk zirvesi + ölçüm.", start: 21, end: 30 },
    ];
  const p1 = Math.round(total * 0.3);
  const p2 = Math.round(total * 0.65);
  return [
    { name: "1. Faz — Temel", range: `1 – ${p1}. gün`, desc: "Temel oluşturma ve alışkanlık.", start: 1, end: p1 },
    { name: "2. Faz — Gelişim", range: `${p1 + 1} – ${p2}. gün`, desc: "Progresif yüklenme dönemi.", start: p1 + 1, end: p2 },
    { name: "3. Faz — Zirve", range: `${p2 + 1} – ${total}. gün`, desc: "Maksimum performans.", start: p2 + 1, end: total },
  ];
}

export default function ProgramScreen({ onOpenSession }: { onOpenSession: () => void }) {
  const { state, dispatch, snapshot, undo } = useStore();
  const { toast } = useFeedback();
  const startSession = useStartSession();
  const profile = state.profile!;
  const goal = getGoal(profile.goalId);
  const plan = WEEKLY_PLAN[profile.goalId];
  const todayIdx = mondayIndex();
  const today = dateKey();
  const weekKeys = useMemo(() => currentWeekDates(), []);

  const [selected, setSelected] = useState(todayIdx);
  const [noteOpen, setNoteOpen] = useState(false);
  const [detail, setDetail] = useState<string | null>(null);
  const [noteDraft, setNoteDraft] = useState("");

  const selectedDate = weekKeys[selected];
  const isFuture = selectedDate > today;
  const day = plan[selected];
  const log = getDay(state, selectedDate);
  const prog = dayProgress(state, selectedDate);
  const currentDay = Math.min(Math.max(1, programDay(profile.startDate)), profile.durationDays);
  const phaseList = phases(profile.durationDays);
  const activePhase = phaseList.findIndex((p) => currentDay >= p.start && currentDay <= p.end);
  const sessionForDay = state.session && state.session.date === selectedDate && state.session.dayIndex === selected;

  const toggle = (i: number) => {
    if (isFuture) {
      toast("Gelecek günler o gün geldiğinde işaretlenebilir.", { tone: "info" });
      return;
    }
    const key = exKey(profile.goalId, selected, i);
    const nextValue = !log.exercises[key];
    dispatch({ type: "TOGGLE_EXERCISE", date: selectedDate, key, value: nextValue });
    const total = day.exercises.length;
    const done = day.exercises.reduce((s, _e, j) => s + ((j === i ? nextValue : !!log.exercises[exKey(profile.goalId, selected, j)]) ? 1 : 0), 0);
    dispatch({ type: "PATCH_DAY", date: selectedDate, patch: { workoutDone: done >= total } });
    if (done >= total) toast(`${day.title} tamamlandı! 🔥`);
  };

  const resetDay = () => {
    snapshot();
    const cleared: Record<string, boolean> = {};
    day.exercises.forEach((_e, i) => (cleared[exKey(profile.goalId, selected, i)] = false));
    dispatch({ type: "PATCH_DAY", date: selectedDate, patch: { exercises: { ...log.exercises, ...cleared }, workoutDone: false } });
    toast("Gün sıfırlandı", { tone: "danger", actionLabel: "Geri Al", onAction: () => undo() });
  };

  const saveNote = () => {
    dispatch({ type: "PATCH_DAY", date: selectedDate, patch: { note: noteDraft } });
    setNoteOpen(false);
    toast("Antrenman notu kaydedildi");
  };

  return (
    <div className="space-y-5 px-4 pb-6 pt-4">
      {/* başlık */}
      <div className="relative overflow-hidden rounded-3xl border border-[var(--c-line2)]">
        <img src={goal.image} alt={goal.title} className="h-44 w-full object-cover" loading="lazy" />
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--c-bg0)] via-[var(--c-bg0)]/55 to-[var(--c-bg0)]/10" />
        <div className="absolute inset-x-0 bottom-0 p-4">
          <div className="flex flex-wrap items-center gap-1.5">
            <Chip active>{goal.tag}</Chip>
            <Chip>{profile.durationDays} Gün</Chip>
            <Chip>{currentDay}. gün</Chip>
          </div>
          <h2 className="font-display mt-2 text-[26px] leading-none text-[var(--c-text)]">{goal.title.toLocaleUpperCase("tr-TR")} PROGRAMI</h2>
          <p className="mt-1 text-[12px] text-[var(--c-acc2)]/80">{goal.weeklyFocus.join(" • ")}</p>
        </div>
      </div>

      {/* fazlar */}
      <div>
        <SectionTitle title="Program Fazları" subtitle={`${profile.durationDays} günlük yol haritası`} />
        <div className="grid grid-cols-3 gap-2">
          {phaseList.map((p, i) => (
            <Card key={i} className={cn("p-3", i === activePhase && "border-[#00e676]/50 bg-[#00e676]/[0.06]")}>
              <p className={cn("font-display text-[13px] leading-tight", i === activePhase ? "text-[var(--c-acc)]" : "text-[var(--c-text)]")}>{p.name}</p>
              <p className="mt-1 text-[10.5px] font-bold text-[var(--c-sub)]">{p.range}</p>
              <p className="mt-1 text-[10.5px] leading-snug text-[var(--c-mute)]">{p.desc}</p>
              {i === activePhase && <p className="mt-1.5 text-[10px] font-extrabold uppercase tracking-wide text-[var(--c-acc)]">● Şu an buradasın</p>}
            </Card>
          ))}
        </div>
      </div>

      {/* gün seçici */}
      <div>
        <div className="mb-3 flex items-center justify-between px-1">
          <h3 className="font-condensed text-[15px] font-semibold uppercase tracking-[0.14em] text-[var(--c-text)]">Haftalık Plan</h3>
          <button onClick={() => setSelected(todayIdx)} className="flex items-center gap-1 text-[12px] font-bold text-[var(--c-acc)]">
            <RotateCcw size={13} /> Bugüne Dön
          </button>
        </div>
        <div className="grid grid-cols-7 gap-1.5">
          {plan.map((d, i) => {
            const active = i === selected;
            const key = weekKeys[i];
            const complete = isDayComplete(state, key);
            const future = key > today;
            return (
              <button
                key={d.day}
                onClick={() => setSelected(i)}
                className={cn(
                  "relative flex flex-col items-center rounded-xl border py-2.5 active:scale-95",
                  active ? "border-[#00e676] bg-[#00e676] text-[#04110a]" : complete ? "border-[#00e676]/40 bg-[#00e676]/10 text-[var(--c-acc)]" : "border-[var(--c-line2)] bg-[var(--c-bg1)] text-[var(--c-text)]"
                )}
              >
                {i === todayIdx && !active && <span className="absolute -top-1 h-2 w-2 rounded-full bg-[#00e676] shadow-[0_0_8px_#00e676]" />}
                <span className={cn("text-[10.5px] font-extrabold uppercase", active ? "text-[#04110a]/70" : "text-[var(--c-mute)]")}>{DAY_SHORT[i]}</span>
                <span className="mt-0.5 grid h-7 w-7 place-items-center">
                  {complete ? <Check size={15} strokeWidth={3} /> : future ? <Lock size={13} className="opacity-50" /> : d.restDay ? <span className="text-[13px]">💤</span> : <Dumbbell size={15} />}
                </span>
                <span className={cn("text-[9px] font-bold", active ? "text-[#04110a]/70" : "text-[var(--c-mute2)]")}>{shortDate(key).split(" ")[0]}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* seçili gün */}
      <AnimatePresence mode="wait">
        <motion.div key={selected} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.22 }}>
          <Card className="overflow-hidden">
            <div className="flex items-start justify-between border-b border-[var(--c-line)] p-4">
              <div className="min-w-0">
                <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[var(--c-acc)]">
                  {day.day} • {longDate(selectedDate)}
                </p>
                <h4 className="font-condensed mt-1 text-[21px] font-semibold uppercase text-[var(--c-text)]">{day.title}</h4>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <Chip><Clock size={11} /> {day.duration}</Chip>
                  <Chip><Flame size={11} /> {day.level}</Chip>
                  {log.activeSeconds > 0 && <Chip active><Timer size={11} /> {Math.round(log.activeSeconds / 60)} dk yapıldı</Chip>}
                </div>
              </div>
              <div className="shrink-0 text-right">
                <p className="font-display text-2xl text-[var(--c-text)]">%{Math.round(prog.exerciseRatio * 100)}</p>
                <p className="text-[10px] font-semibold text-[var(--c-mute)]">{prog.exerciseDone}/{prog.exerciseTotal} hareket</p>
              </div>
            </div>

            <div className="px-4 pt-3">
              <ProgressBar value={prog.exerciseRatio * 100} />
            </div>

            {isFuture && (
              <p className="mx-3 mt-3 flex items-center gap-2 rounded-xl border border-[#38bdf8]/25 bg-[#38bdf8]/[0.07] px-3 py-2.5 text-[12px] font-semibold text-[var(--c-blue2)]">
                <Lock size={13} /> Bu gün henüz gelmedi — plan önizlemesi. İşaretleme {shortDate(selectedDate)} tarihinde açılır.
              </p>
            )}

            <div className="space-y-2 p-3">
              {day.exercises.map((e, i) => {
                const key = exKey(profile.goalId, selected, i);
                const done = !!log.exercises[key];
                return (
                  <button
                    key={i}
                    onClick={() => toggle(i)}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-2xl border p-3 text-left transition-all active:scale-[0.99]",
                      done ? "border-[#00e676]/50 bg-[#00e676]/[0.07]" : "border-[var(--c-line)] bg-[var(--c-text)]/[0.02]",
                      isFuture && "opacity-60"
                    )}
                  >
                    <span className={cn("font-display text-lg", done ? "text-[var(--c-acc)]" : "text-[var(--c-mute2)]")}>{String(i + 1).padStart(2, "0")}</span>
                    <span className="min-w-0 flex-1">
                      <span className={cn("block text-[14px] font-bold", done ? "text-[var(--c-sub)] line-through" : "text-[var(--c-text)]")}>{e.name}</span>
                      <span className="mt-0.5 block text-[12px] text-[var(--c-mute)]">{e.sets} {e.rest !== "-" && `• Dinlenme ${e.rest}`}</span>
                      <span role="button" onClick={(ev) => { ev.stopPropagation(); setDetail(e.name); }} className="mt-1.5 inline-flex items-center gap-1 rounded-full border border-[var(--c-accline)] bg-[var(--c-tint)] px-2.5 py-1 text-[11px] font-bold text-[var(--c-acc)]"><Info size={12} /> Nasıl yapılır · Animasyon</span>
                    </span>
                    <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-full border", done ? "border-[#00e676] bg-[#00e676] text-[#04110a]" : "border-[var(--c-line4)] text-transparent")}>
                      <Check size={16} strokeWidth={3} />
                    </span>
                  </button>
                );
              })}
            </div>

            {log.note && (
              <div className="mx-3 mb-3 rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg1)] p-3">
                <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[var(--c-mute)]"><NotebookPen size={12} /> Notun</p>
                <p className="mt-1 whitespace-pre-wrap text-[13px] leading-relaxed text-[var(--c-text2)]">{log.note}</p>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2 p-3 pt-0">
              <NeonButton
                variant="ghost"
                onClick={() => { setNoteDraft(log.note); setNoteOpen(true); }}
                className="flex items-center justify-center gap-1.5"
              >
                <NotebookPen size={15} /> {log.note ? "Notu Düzenle" : "Not Ekle"}
              </NeonButton>
              <NeonButton
                onClick={() => {
                  if (isFuture) {
                    toast("Antrenman ancak günü geldiğinde başlatılabilir.", { tone: "info" });
                    return;
                  }
                  if (sessionForDay) onOpenSession();
                  else if (state.session) {
                    toast("Başka bir antrenman açık. Önce onu tamamla.", { tone: "info" });
                    onOpenSession();
                  } else {
                    startSession(selected, selectedDate);
                    onOpenSession();
                  }
                }}
                className="flex items-center justify-center gap-2"
              >
                <Play size={16} fill="currentColor" /> {sessionForDay ? "Devam Et" : "Başlat"}
              </NeonButton>
            </div>
            {prog.exerciseDone > 0 && !isFuture && (
              <button onClick={resetDay} className="flex w-full items-center justify-center gap-1.5 border-t border-[var(--c-line)] py-3 text-[12.5px] font-bold text-[var(--c-red)] active:scale-[0.99]">
                <RotateCcw size={13} /> Bu günün işaretlerini temizle
              </button>
            )}
          </Card>
        </motion.div>
      </AnimatePresence>

      {/* haftalık özet */}
      <Card className="border-[#00e676]/20 bg-gradient-to-br from-[var(--c-tint)] to-[var(--c-bg1)] p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-[var(--c-acc)]"><CalendarCheck size={12} /> Bu Hafta</p>
            <p className="mt-1 text-[14px] font-extrabold text-[var(--c-text)]">
              {weekKeys.filter((k) => isDayComplete(state, k)).length} / {profile.weeklyTarget} antrenman tamamlandı
            </p>
            <p className="mt-0.5 text-[12px] text-[var(--c-sub)]">
              Toplam {Math.round(weekKeys.reduce((s, k) => s + (state.days[k]?.activeSeconds ?? 0), 0) / 60)} dakika aktif antrenman
            </p>
          </div>
        </div>
        <ProgressBar value={(weekKeys.filter((k) => isDayComplete(state, k)).length / profile.weeklyTarget) * 100} className="mt-3" />
      </Card>

      <ExerciseSheet name={detail} onClose={() => setDetail(null)} />

      <Sheet open={noteOpen} onClose={() => setNoteOpen(false)} title="Antrenman Notu" subtitle={`${day.title} • ${longDate(selectedDate)}`}>
        <textarea
          value={noteDraft}
          onChange={(e) => setNoteDraft(e.target.value)}
          rows={5}
          placeholder="Ağırlıklar, tekrar sayıları, nasıl hissettin?"
          className="w-full rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg0)] p-4 text-[14px] leading-relaxed text-[var(--c-text)] outline-none placeholder:text-[var(--c-mute2)] focus:border-[#00e676]"
        />
        <div className="mt-3 grid grid-cols-2 gap-2">
          <NeonButton variant="ghost" onClick={() => setNoteOpen(false)}>Vazgeç</NeonButton>
          <NeonButton onClick={saveNote}>Kaydet</NeonButton>
        </div>
      </Sheet>
    </div>
  );
}
