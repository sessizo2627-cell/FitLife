import { useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Pencil, Target, CalendarRange, Bell, Smartphone, ChevronRight, Flame, Dumbbell, TrendingUp, ShieldCheck,
  Check, Trash2, Info, Share2, Ruler, Cake, Scale, Activity, AlarmClock, Download, Upload, RotateCcw, Footprints, Droplets,
} from "lucide-react";
import type { FitLifeState, GoalId, UserProfile } from "../types";
import { useStore, clearLegacyKeys } from "../store/store";
import { useFeedback } from "./Feedback";
import { GOALS, DURATIONS } from "../data/fitness";
import { bmi, bmiInfo, calorieGoal, currentStreak, latestValue, proteinGoal, totalActiveMinutes, totalWorkouts } from "../lib/calc";
import { dateKey, longDate, programDay } from "../lib/date";
import { Card, Sheet, NeonButton, ProgressBar, Field, Stepper } from "./ui";
import RemindersPanel from "./RemindersPanel";
import HealthPanel from "./HealthPanel";
import NutritionPanel from "./NutritionPanel";
import { Sun, Moon, MonitorSmartphone, HeartPulse, Utensils } from "lucide-react";
import { cn } from "../utils/cn";

const GOAL_ICONS: Record<string, typeof Flame> = {
  flame: Flame,
  "trending-up": TrendingUp,
  dumbbell: Dumbbell,
  shield: ShieldCheck,
};

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={cn("relative h-7 w-12 shrink-0 rounded-full transition-colors", on ? "bg-[#00e676]" : "bg-[var(--c-line3)]")} aria-label="Aç/Kapat">
      <motion.span className={cn("absolute top-1 h-5 w-5 rounded-full bg-white", on ? "right-1" : "left-1")} layout transition={{ type: "spring", stiffness: 500, damping: 30 }} />
    </button>
  );
}

export default function ProfileScreen({ onRestart }: { onRestart: () => void }) {
  const { state, dispatch, snapshot, undo } = useStore();
  const { toast, muted, setMuted } = useFeedback();
  const profile = state.profile!;
  const fileRef = useRef<HTMLInputElement>(null);

  const [editOpen, setEditOpen] = useState(false);
  const [goalOpen, setGoalOpen] = useState(false);
  const [durOpen, setDurOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [reminderOpen, setReminderOpen] = useState(false);
  const [healthOpen, setHealthOpen] = useState(false);
  const [nutritionOpen, setNutritionOpen] = useState(false);
  const [customDays, setCustomDays] = useState(String(profile.durationDays));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [form, setForm] = useState({
    name: profile.name,
    age: String(profile.age),
    height: String(profile.height),
    weight: String(profile.weight),
    targetWeight: String(profile.targetWeight),
    level: profile.level,
    gender: profile.gender,
  });

  const goal = GOALS.find((g) => g.id === profile.goalId)!;
  const GoalIcon = GOAL_ICONS[goal.icon];
  const currentWeight = latestValue(state.measurements, "weight") ?? profile.weight;
  const day = Math.min(Math.max(1, programDay(profile.startDate)), profile.durationDays);
  const streak = currentStreak(state);
  const bmiValue = bmi(currentWeight, profile.height);
  const bmiMeta = bmiInfo(bmiValue);
  const endDate = new Date(new Date(profile.startDate).getTime() + (profile.durationDays - 1) * 86400000);

  const openEdit = () => {
    setForm({
      name: profile.name,
      age: String(profile.age),
      height: String(profile.height),
      weight: String(currentWeight),
      targetWeight: String(profile.targetWeight),
      level: profile.level,
      gender: profile.gender,
    });
    setErrors({});
    setEditOpen(true);
  };

  const saveEdit = () => {
    const e: Record<string, string> = {};
    const age = Number(form.age);
    const height = Number(form.height);
    const weight = Number(form.weight.replace(",", "."));
    const target = Number(form.targetWeight.replace(",", "."));
    if (form.name.trim().length < 2) e.name = "En az 2 karakter gir.";
    if (!age || age < 12 || age > 100) e.age = "12 – 100 arası";
    if (!height || height < 100 || height > 250) e.height = "100 – 250 cm";
    if (!weight || weight < 30 || weight > 300) e.weight = "30 – 300 kg";
    if (!target || target < 30 || target > 300) e.targetWeight = "30 – 300 kg";
    setErrors(e);
    if (Object.keys(e).length) return;

    dispatch({
      type: "PATCH_PROFILE",
      patch: { name: form.name.trim(), age, height, weight, targetWeight: target, level: form.level, gender: form.gender },
    });
    // bugünün kilosunu ölçüm geçmişine de yaz
    const todayKey = dateKey();
    const existing = state.measurements.find((m) => m.date === todayKey);
    if (existing) {
      dispatch({ type: "UPDATE_MEASUREMENT", measurement: { ...existing, weight } });
    } else {
      dispatch({ type: "ADD_MEASUREMENT", measurement: { id: `${todayKey}-w`, date: todayKey, weight } });
    }
    setEditOpen(false);
    toast("Profil bilgilerin kaydedildi");
  };

  const exportData = () => {
    try {
      const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `fitlife-yedek-${dateKey()}.json`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      toast("Yedek dosyası indirildi");
    } catch {
      toast("Yedek oluşturulamadı", { tone: "danger" });
    }
  };

  const importData = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as FitLifeState;
        if (!parsed || typeof parsed !== "object" || !parsed.profile) throw new Error("geçersiz");
        snapshot();
        dispatch({ type: "IMPORT", state: { ...parsed, version: 2 } });
        toast("Yedek geri yüklendi", { actionLabel: "Geri Al", onAction: () => undo() });
      } catch {
        toast("Dosya okunamadı. Geçerli bir FitLife yedeği seç.", { tone: "danger" });
      }
    };
    reader.readAsText(file);
  };

  const invite = async () => {
    const text = `FitLife ile ${profile.durationDays} günlük ${goal.title} programındayım! Sen de dene.`;
    try {
      if (navigator.share) {
        await navigator.share({ title: "FitLife", text, url: location.href });
        toast("Davet paylaşıldı");
        return;
      }
      await navigator.clipboard.writeText(`${text} ${location.href}`);
      toast("Davet bağlantısı panoya kopyalandı");
    } catch {
      toast("Paylaşım iptal edildi", { tone: "info" });
    }
  };

  const resetAll = () => {
    snapshot();
    clearLegacyKeys();
    dispatch({ type: "RESET" });
    setResetOpen(false);
    toast("Tüm veriler silindi", { tone: "danger", actionLabel: "Geri Al", onAction: () => undo() });
  };

  return (
    <div className="space-y-5 px-4 pb-6 pt-4">
      {/* profil kartı */}
      <Card className="card-sheen relative overflow-hidden p-5">
        <div className="pointer-events-none absolute -left-16 -top-16 h-48 w-48 rounded-full bg-[#00e676]/12 blur-[60px]" />
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-[var(--c-tint2)] to-[var(--c-bg1)] text-3xl font-extrabold text-[var(--c-acc)] ring-2 ring-[#00e676]/40">
              {profile.name.trim()[0]?.toLocaleUpperCase("tr-TR") ?? "F"}
            </div>
            <span className="absolute -bottom-1 -right-1 grid h-7 w-7 place-items-center rounded-full bg-[#00e676] text-[#04110a] ring-4 ring-[var(--c-bg1)]">
              <Flame size={14} fill="currentColor" />
            </span>
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="truncate text-[20px] font-extrabold text-[var(--c-text)]">{profile.name}</h2>
            <p className="mt-0.5 text-[12px] font-semibold text-[var(--c-sub)]">
              {profile.level === "baslangic" ? "Başlangıç" : profile.level === "orta" ? "Orta Seviye" : "İleri Seviye"} • {profile.gender === "erkek" ? "Erkek" : "Kadın"}
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <span className="flex items-center gap-1 rounded-full bg-[#00e676]/10 px-2.5 py-1 text-[11px] font-bold text-[var(--c-acc)]">
                <Flame size={11} fill="currentColor" /> {streak} gün seri
              </span>
              <span className="rounded-full bg-[var(--c-text)]/5 px-2.5 py-1 text-[11px] font-bold text-[var(--c-sub)]">{totalWorkouts(state)} antrenman</span>
            </div>
          </div>
          <button onClick={openEdit} className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-[var(--c-line3)] bg-[var(--c-bg2)] text-[var(--c-text)] active:scale-95" aria-label="Profili düzenle">
            <Pencil size={16} />
          </button>
        </div>

        <div className="mt-4 grid grid-cols-4 gap-2">
          {[
            { icon: Cake, v: `${profile.age}`, l: "Yaş" },
            { icon: Ruler, v: `${profile.height}`, l: "Boy (cm)" },
            { icon: Scale, v: `${currentWeight}`, l: "Kilo (kg)" },
            { icon: Activity, v: bmiValue.toFixed(1), l: "VKİ" },
          ].map((s, i) => (
            <div key={i} className="rounded-2xl bg-[var(--c-text)]/[0.04] px-2 py-3 text-center">
              <s.icon size={15} className="mx-auto text-[var(--c-acc)]" />
              <p className="mt-1 text-[15px] font-extrabold text-[var(--c-text)]">{s.v}</p>
              <p className="text-[10px] font-semibold text-[var(--c-mute)]">{s.l}</p>
            </div>
          ))}
        </div>

        <div className="mt-3 rounded-2xl bg-[var(--c-text)]/[0.04] p-3.5">
          <div className="flex items-center justify-between">
            <span className="text-[12px] font-semibold text-[var(--c-sub)]">Vücut Kitle İndeksi</span>
            <span className="text-[12px] font-extrabold" style={{ color: bmiMeta.color }}>{bmiMeta.label}</span>
          </div>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-[var(--c-line2)]">
            <motion.div className="h-full rounded-full" style={{ background: bmiMeta.color, boxShadow: `0 0 10px ${bmiMeta.color}` }} initial={{ width: 0 }} animate={{ width: `${Math.min(100, (bmiValue / 35) * 100)}%` }} />
          </div>
          <p className="mt-1.5 text-[11px] text-[var(--c-mute)]">
            Hedef: <b className="text-[var(--c-text)]">{profile.targetWeight} kg</b> • Kalan: <b className="text-[var(--c-text)]">{Math.abs(+(profile.targetWeight - currentWeight).toFixed(1))} kg</b> • Günlük hedef: <b className="text-[var(--c-text)]">{calorieGoal(profile, currentWeight)} kcal</b> / {proteinGoal(profile, currentWeight)} g protein
          </p>
        </div>
      </Card>

      {/* hedef & süre */}
      <div>
        <h3 className="font-condensed mb-3 px-1 text-[15px] font-semibold uppercase tracking-[0.14em] text-[var(--c-text)]">Hedef & Program</h3>
        <div className="space-y-2.5">
          <button onClick={() => setGoalOpen(true)} className="flex w-full items-center gap-3.5 rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] p-4 text-left active:scale-[0.99]">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#00e676] text-[#04110a]"><GoalIcon size={22} strokeWidth={2.2} /></span>
            <span className="min-w-0 flex-1">
              <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[var(--c-acc)]"><Target size={11} /> Aktif Hedef</span>
              <span className="mt-0.5 block text-[16px] font-extrabold text-[var(--c-text)]">{goal.title}</span>
              <span className="block truncate text-[12px] text-[var(--c-mute)]">{goal.tag} • Değiştirmek için dokun</span>
            </span>
            <ChevronRight size={19} className="shrink-0 text-[var(--c-mute)]" />
          </button>

          <Card className="p-4">
            <div className="flex items-center gap-3.5">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#00e676]/12 text-[var(--c-acc)]"><CalendarRange size={22} /></span>
              <div className="min-w-0 flex-1">
                <p className="text-[11px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Program Süresi</p>
                <p className="mt-0.5 text-[16px] font-extrabold text-[var(--c-text)]">
                  {profile.durationDays} Gün{" "}
                  {profile.customDuration && <span className="ml-1 rounded-full bg-[#00e676]/10 px-2 py-0.5 align-middle text-[10px] font-bold text-[var(--c-acc)]">ÖZEL</span>}
                </p>
              </div>
              <button onClick={() => { setCustomDays(String(profile.durationDays)); setDurOpen(true); }} className="shrink-0 rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg2)] px-3.5 py-2 text-[12px] font-bold text-[var(--c-text)] active:scale-95">
                Düzenle
              </button>
            </div>
            <div className="mt-3">
              <div className="mb-1.5 flex justify-between text-[12px]">
                <span className="text-[var(--c-sub)]">{day}. gündesin</span>
                <span className="font-bold text-[var(--c-text)]">%{Math.round((day / profile.durationDays) * 100)}</span>
              </div>
              <ProgressBar value={(day / profile.durationDays) * 100} />
              <p className="mt-1.5 text-[11px] text-[var(--c-mute)]">
                Başlangıç: {longDate(dateKey(profile.startDate))} • Bitiş: {longDate(dateKey(endDate))}
              </p>
            </div>
            <button
              onClick={() => {
                snapshot();
                dispatch({ type: "PATCH_PROFILE", patch: { startDate: new Date().toISOString() } });
                toast("Program başlangıcı bugüne alındı", { actionLabel: "Geri Al", onAction: () => undo() });
              }}
              className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg2)] py-2.5 text-[12.5px] font-bold text-[var(--c-text2)] active:scale-95"
            >
              <RotateCcw size={13} /> Programı bugünden yeniden başlat
            </button>
          </Card>
        </div>
      </div>

      {/* günlük hedefler */}
      <div>
        <h3 className="font-condensed mb-3 px-1 text-[15px] font-semibold uppercase tracking-[0.14em] text-[var(--c-text)]">Günlük Hedefler</h3>
        <Card className="space-y-4 p-4">
          <div>
            <p className="mb-2 flex items-center gap-2 text-[13px] font-extrabold text-[var(--c-text)]"><Dumbbell size={15} className="text-[var(--c-acc)]" /> Haftalık antrenman</p>
            <Stepper value={profile.weeklyTarget} min={1} max={7} suffix="gün" onChange={(v) => dispatch({ type: "PATCH_PROFILE", patch: { weeklyTarget: v } })} />
          </div>
          <div>
            <p className="mb-2 flex items-center gap-2 text-[13px] font-extrabold text-[var(--c-text)]"><Footprints size={15} className="text-[var(--c-violet)]" /> Günlük adım</p>
            <Stepper value={profile.stepGoal} step={500} min={1000} max={50000} suffix="adım" onChange={(v) => dispatch({ type: "PATCH_PROFILE", patch: { stepGoal: v } })} />
          </div>
          <div>
            <p className="mb-2 flex items-center gap-2 text-[13px] font-extrabold text-[var(--c-text)]"><Droplets size={15} className="text-[var(--c-blue)]" /> Günlük su</p>
            <Stepper value={profile.waterGoal} min={4} max={20} suffix="bardak" onChange={(v) => dispatch({ type: "PATCH_PROFILE", patch: { waterGoal: v } })} />
          </div>
          <p className="rounded-xl bg-[var(--c-text)]/[0.04] px-3 py-2.5 text-[11.5px] leading-relaxed text-[var(--c-mute)]">
            Kalori ve protein hedefi boy, kilo, yaş ve hedefine göre otomatik hesaplanır:{" "}
            <b className="text-[var(--c-text)]">{calorieGoal(profile, currentWeight)} kcal</b> • <b className="text-[var(--c-text)]">{proteinGoal(profile, currentWeight)} g protein</b>
          </p>
        </Card>
      </div>

      {/* ayarlar */}
      <div>
        <h3 className="font-condensed mb-3 px-1 text-[15px] font-semibold uppercase tracking-[0.14em] text-[var(--c-text)]">Ayarlar</h3>
        <Card className="mb-2.5 p-4">
          <p className="text-[14px] font-extrabold text-[var(--c-text)]">Görünüm</p>
          <p className="mt-0.5 text-[12px] text-[var(--c-mute)]">Açık, koyu veya cihaz ayarını takip et</p>
          <div className="mt-3 grid grid-cols-3 gap-1.5 rounded-2xl bg-[var(--c-bg2)] p-1">
            {([["light", "Açık", Sun], ["dark", "Koyu", Moon], ["system", "Sistem", MonitorSmartphone]] as const).map(([id, label, Icon]) => (
              <button
                key={id}
                onClick={() => { dispatch({ type: "PATCH_PROFILE", patch: { theme: id } }); toast(`${label} tema seçildi`, { tone: "info" }); }}
                className={cn("flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[12.5px] font-bold transition-colors", profile.theme === id ? "bg-[var(--c-bg1)] text-[var(--c-acc)] shadow-sm" : "text-[var(--c-sub)]")}
              >
                <Icon size={14} /> {label}
              </button>
            ))}
          </div>
        </Card>
        <Card className="divide-y divide-[var(--c-line)]">
          <button onClick={() => setHealthOpen(true)} className="flex w-full items-center gap-3 px-4 py-3.5 text-left">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-red)]/10 text-[var(--c-red)]"><HeartPulse size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">Samsung Health</span>
              <span className="block text-[12px] text-[var(--c-mute)]">{Object.keys(state.health).length ? `${Object.keys(state.health).length} gün veri • adım, nabız, uyku` : "Adım, nabız ve uyku verilerini bağla"}</span>
            </span>
            <span className={cn("rounded-full px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wide", profile.healthSource === "samsung" ? "bg-[var(--c-tint)] text-[var(--c-acc)]" : "bg-[var(--c-bg2)] text-[var(--c-mute)]")}>{profile.healthSource === "samsung" ? "Bağlı" : "Kapalı"}</span>
          </button>
          <button onClick={() => setNutritionOpen(true)} className="flex w-full items-center gap-3 px-4 py-3.5 text-left">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-amber)]/10 text-[var(--c-amber)]"><Utensils size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">Beslenme Önerileri</span>
              <span className="block text-[12px] text-[var(--c-mute)]">Günlük, haftalık ve aylık plan</span>
            </span>
            <ChevronRight size={18} className="text-[var(--c-mute)]" />
          </button>
          <button onClick={() => setReminderOpen(true)} className="flex w-full items-center gap-3 px-4 py-3.5 text-left">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#00e676]/10 text-[var(--c-acc)]"><AlarmClock size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">Hatırlatıcılar & Alarm</span>
              <span className="block text-[12px] text-[var(--c-mute)]">{state.reminders.filter((r) => r.enabled).length} aktif hatırlatıcı</span>
            </span>
            <ChevronRight size={18} className="text-[var(--c-mute)]" />
          </button>

          <div className="flex items-center gap-3 px-4 py-3.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-text)]/[0.05] text-[var(--c-text2)]"><Bell size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">Cihaz bildirimleri</span>
              <span className="block text-[12px] text-[var(--c-mute)]">İzin verildiyse bildirim paneline gönderilir</span>
            </span>
            <Toggle on={profile.notifications} onClick={() => dispatch({ type: "PATCH_PROFILE", patch: { notifications: !profile.notifications } })} />
          </div>

          <div className="flex items-center gap-3 px-4 py-3.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-text)]/[0.05] text-[var(--c-text2)]"><AlarmClock size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">Hatırlatıcı motoru</span>
              <span className="block text-[12px] text-[var(--c-mute)]">Uygulama açıkken zamanı kontrol eder</span>
            </span>
            <Toggle on={profile.reminders} onClick={() => dispatch({ type: "PATCH_PROFILE", patch: { reminders: !profile.reminders } })} />
          </div>

          <div className="flex items-center gap-3 px-4 py-3.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-text)]/[0.05] text-[var(--c-text2)]"><Activity size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">Alarm ve sayaç sesleri</span>
              <span className="block text-[12px] text-[var(--c-mute)]">{muted ? "Tüm sesler kapalı" : "Set, dinlenme ve alarm sesleri açık"}</span>
            </span>
            <Toggle on={!muted} onClick={() => setMuted(!muted)} />
          </div>

          <button onClick={invite} className="flex w-full items-center gap-3 px-4 py-3.5 text-left">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-text)]/[0.05] text-[var(--c-text2)]"><Share2 size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">Arkadaşını Davet Et</span>
              <span className="block text-[12px] text-[var(--c-mute)]">Bağlantıyı paylaş veya kopyala</span>
            </span>
            <ChevronRight size={18} className="text-[var(--c-mute)]" />
          </button>

          <button onClick={exportData} className="flex w-full items-center gap-3 px-4 py-3.5 text-left">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-text)]/[0.05] text-[var(--c-text2)]"><Download size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">Verileri Dışa Aktar</span>
              <span className="block text-[12px] text-[var(--c-mute)]">JSON yedeği indir ({state.measurements.length} ölçüm, {Object.keys(state.days).length} gün)</span>
            </span>
            <ChevronRight size={18} className="text-[var(--c-mute)]" />
          </button>

          <button onClick={() => fileRef.current?.click()} className="flex w-full items-center gap-3 px-4 py-3.5 text-left">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-text)]/[0.05] text-[var(--c-text2)]"><Upload size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">Yedeği Geri Yükle</span>
              <span className="block text-[12px] text-[var(--c-mute)]">Daha önce indirdiğin JSON dosyası</span>
            </span>
            <ChevronRight size={18} className="text-[var(--c-mute)]" />
          </button>
          <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) importData(f); e.target.value = ""; }} />

          <div className="flex items-center gap-3 px-4 py-3.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-text)]/[0.05] text-[var(--c-text2)]"><Smartphone size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">Çevrimdışı & APK</span>
              <span className="block text-[12px] text-[var(--c-mute)]">Veriler cihazda; internet gerekmez</span>
            </span>
            <span className="rounded-full bg-[#00e676]/10 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wide text-[var(--c-acc)]">Hazır</span>
          </div>

          <div className="flex items-center gap-3 px-4 py-3.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-text)]/[0.05] text-[var(--c-text2)]"><Info size={18} /></span>
            <span className="flex-1">
              <span className="block text-[14px] font-bold text-[var(--c-text)]">FitLife v2.0</span>
              <span className="block text-[12px] text-[var(--c-mute)]">Toplam {totalActiveMinutes(state)} dk antrenman • Türkçe</span>
            </span>
          </div>
        </Card>
      </div>

      {/* tehlikeli bölge */}
      <div className="space-y-2">
        <button onClick={() => setResetOpen(true)} className="flex w-full items-center justify-center gap-2 rounded-2xl border border-[#f87171]/30 bg-[#f87171]/[0.06] py-3.5 text-[14px] font-bold text-[var(--c-red)] active:scale-[0.99]">
          <Trash2 size={16} /> Verileri Sıfırla
        </button>
        <button onClick={onRestart} className="flex w-full items-center justify-center gap-2 rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg1)] py-3.5 text-[14px] font-bold text-[var(--c-sub)] active:scale-[0.99]">
          <RotateCcw size={16} /> Kurulumu Yeniden Yap
        </button>
        <p className="pt-1 text-center text-[11px] text-[var(--c-mute2)]">Tüm veriler yalnızca bu cihazda saklanır.</p>
      </div>

      {/* profil düzenleme */}
      <Sheet open={editOpen} onClose={() => setEditOpen(false)} title="Profili Düzenle" subtitle="Bilgilerini güncelle; hedefler yeniden hesaplansın.">
        <div className="space-y-3">
          <Field label="Adın" type="text" value={form.name} onChange={(v) => setForm({ ...form, name: v })} error={errors.name} />
          <div>
            <p className="mb-1.5 text-[11.5px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Cinsiyet</p>
            <div className="grid grid-cols-2 gap-2">
              {(["erkek", "kadin"] as const).map((g) => (
                <button key={g} onClick={() => setForm({ ...form, gender: g })} className={cn("rounded-xl border py-2.5 text-[13px] font-bold", form.gender === g ? "border-[#00e676] bg-[#00e676]/10 text-[var(--c-acc)]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-sub)]")}>
                  {g === "erkek" ? "Erkek" : "Kadın"}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <Field label="Yaş" value={form.age} onChange={(v) => setForm({ ...form, age: v })} error={errors.age} inputMode="numeric" />
            <Field label="Boy" value={form.height} onChange={(v) => setForm({ ...form, height: v })} suffix="cm" error={errors.height} inputMode="numeric" />
            <Field label="Kilo" value={form.weight} onChange={(v) => setForm({ ...form, weight: v })} suffix="kg" error={errors.weight} />
          </div>
          <Field label="Hedef Kilo" value={form.targetWeight} onChange={(v) => setForm({ ...form, targetWeight: v })} suffix="kg" error={errors.targetWeight} />
          <div>
            <p className="mb-1.5 text-[11.5px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Seviye</p>
            <div className="grid grid-cols-3 gap-2">
              {(["baslangic", "orta", "ileri"] as const).map((l) => (
                <button key={l} onClick={() => setForm({ ...form, level: l })} className={cn("rounded-xl border py-2.5 text-[13px] font-bold", form.level === l ? "border-[#00e676] bg-[#00e676]/10 text-[var(--c-acc)]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-sub)]")}>
                  {l === "baslangic" ? "Başlangıç" : l === "orta" ? "Orta" : "İleri"}
                </button>
              ))}
            </div>
          </div>
          <NeonButton onClick={saveEdit} className="w-full">Kaydet</NeonButton>
          <p className="text-center text-[11px] text-[var(--c-mute)]">Kilo değişikliği bugünün ölçüm geçmişine de işlenir.</p>
        </div>
      </Sheet>

      {/* hedef */}
      <Sheet open={goalOpen} onClose={() => setGoalOpen(false)} title="Hedefini Değiştir" subtitle="Haftalık program yeni hedefine göre güncellenir.">
        <div className="space-y-2.5">
          {GOALS.map((g) => {
            const I = GOAL_ICONS[g.icon];
            const active = g.id === profile.goalId;
            return (
              <button
                key={g.id}
                onClick={() => {
                  dispatch({ type: "PATCH_PROFILE", patch: { goalId: g.id as GoalId } });
                  setGoalOpen(false);
                  toast(`Hedef güncellendi: ${g.title}`);
                }}
                className={cn("flex w-full items-center gap-3 rounded-2xl border p-3.5 text-left active:scale-[0.99]", active ? "border-[#00e676] bg-[#00e676]/[0.07]" : "border-[var(--c-line2)] bg-[var(--c-bg1)]")}
              >
                <span className={cn("grid h-11 w-11 shrink-0 place-items-center rounded-xl", active ? "bg-[#00e676] text-[#04110a]" : "bg-[var(--c-line)] text-[var(--c-acc)]")}><I size={20} /></span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[14px] font-extrabold text-[var(--c-text)]">{g.title}</span>
                  <span className="block text-[12px] text-[var(--c-mute)]">{g.desc}</span>
                </span>
                {active && <Check size={18} className="shrink-0 text-[var(--c-acc)]" strokeWidth={3} />}
              </button>
            );
          })}
        </div>
      </Sheet>

      {/* süre */}
      <Sheet open={durOpen} onClose={() => setDurOpen(false)} title="Antrenman Süresi" subtitle="Hazır planlar veya 3 – 365 gün arası özel süre.">
        <div className="grid grid-cols-3 gap-2">
          {DURATIONS.map((d) => (
            <button
              key={d}
              onClick={() => {
                dispatch({ type: "PATCH_PROFILE", patch: { durationDays: d, customDuration: false } });
                setDurOpen(false);
                toast(`Program süresi ${d} gün olarak ayarlandı`);
              }}
              className={cn("rounded-2xl border py-3.5 text-center active:scale-95", profile.durationDays === d && !profile.customDuration ? "border-[#00e676] bg-[#00e676] text-[#04110a]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-text)]")}
            >
              <p className="font-display text-xl">{d}</p>
              <p className="text-[10px] font-bold uppercase tracking-wider opacity-70">Gün</p>
            </button>
          ))}
        </div>
        <div className="mt-3 rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg1)] p-4">
          <Field label="Özel süre" value={customDays} onChange={setCustomDays} suffix="gün" inputMode="numeric" />
          <NeonButton
            onClick={() => {
              const v = Math.round(Number(customDays));
              if (!v || v < 3 || v > 365) {
                toast("Özel süre 3 – 365 gün arasında olmalı", { tone: "danger" });
                return;
              }
              dispatch({ type: "PATCH_PROFILE", patch: { durationDays: v, customDuration: !DURATIONS.includes(v) } });
              setDurOpen(false);
              toast(`Özel süre kaydedildi: ${v} gün`);
            }}
            className="mt-3 w-full"
          >
            Özel Süreyi Uygula
          </NeonButton>
        </div>
      </Sheet>

      {/* sıfırlama */}
      <Sheet open={resetOpen} onClose={() => setResetOpen(false)} title="Verileri Sıfırla?" subtitle="Profil, ölçümler, antrenman kayıtları ve hatırlatıcılar silinir.">
        <div className="rounded-2xl border border-[#f87171]/30 bg-[#f87171]/[0.06] p-3.5">
          <p className="text-[13px] leading-relaxed text-[var(--c-red2)]">
            Silmeden önce <b>Verileri Dışa Aktar</b> ile yedek alabilirsin. Sildikten sonra kısa süreli "Geri Al" seçeneği sunulur.
          </p>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <NeonButton variant="ghost" onClick={() => setResetOpen(false)}>Vazgeç</NeonButton>
          <button onClick={resetAll} className="rounded-xl bg-[#f87171] px-4 py-3 text-[14px] font-extrabold text-[#2a0808] active:scale-[0.98]">Evet, Sıfırla</button>
        </div>
      </Sheet>

      <RemindersPanel open={reminderOpen} onClose={() => setReminderOpen(false)} />
      <HealthPanel open={healthOpen} onClose={() => setHealthOpen(false)} />
      <NutritionPanel open={nutritionOpen} onClose={() => setNutritionOpen(false)} />
    </div>
  );
}

export type { UserProfile };
