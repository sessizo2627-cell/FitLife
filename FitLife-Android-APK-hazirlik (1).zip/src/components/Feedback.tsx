import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import type { ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlarmClock, Check, Info, TriangleAlert, VolumeX, X } from "lucide-react";
import { uid } from "../lib/date";
import { beep, vibrate } from "../lib/notify";

type ToastTone = "success" | "info" | "danger";

interface ToastItem {
  id: string;
  message: string;
  tone: ToastTone;
  actionLabel?: string;
  onAction?: () => void;
}

export interface AlarmItem {
  id: string;
  title: string;
  body: string;
}

interface FeedbackValue {
  toast: (message: string, opts?: { tone?: ToastTone; actionLabel?: string; onAction?: () => void }) => void;
  raiseAlarm: (title: string, body: string) => void;
  alarm: AlarmItem | null;
  dismissAlarm: () => void;
  muted: boolean;
  setMuted: (v: boolean) => void;
  registerOverlay: () => () => void;
  setHost: (el: HTMLDivElement | null) => void;
  /** telefon çerçevesinin sabit katmanı; paneller (Sheet) buraya çizilir */
  host: HTMLDivElement | null;
}

const Ctx = createContext<FeedbackValue | null>(null);

/** Toast ve alarm katmanının bağlanacağı alan — telefon çerçevesinin içine yerleştirilir */
export function FeedbackHost() {
  const { setHost } = useFeedback();
  return <div ref={setHost} className="pointer-events-none absolute inset-0 z-[95]" />;
}

export function FeedbackProvider({ children, initialMuted = false }: { children: ReactNode; initialMuted?: boolean }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [alarm, setAlarm] = useState<AlarmItem | null>(null);
  const [muted, setMuted] = useState(initialMuted);
  const mutedRef = useRef(muted);
  mutedRef.current = muted;
  const [overlays, setOverlays] = useState(0);
  const [host, setHost] = useState<HTMLDivElement | null>(null);
  const timers = useRef<Record<string, number>>({});
  const snoozeTimer = useRef<number | null>(null);

  const registerOverlay = useCallback(() => {
    setOverlays((n) => n + 1);
    return () => setOverlays((n) => Math.max(0, n - 1));
  }, []);

  const remove = useCallback((id: string) => {
    setToasts((t) => t.filter((x) => x.id !== id));
    window.clearTimeout(timers.current[id]);
    delete timers.current[id];
  }, []);

  const toast = useCallback<FeedbackValue["toast"]>(
    (message, opts) => {
      const id = uid();
      setToasts((t) => [...t.slice(-2), { id, message, tone: opts?.tone ?? "success", actionLabel: opts?.actionLabel, onAction: opts?.onAction }]);
      timers.current[id] = window.setTimeout(() => remove(id), opts?.actionLabel ? 6000 : 2600);
    },
    [remove]
  );

  const raiseAlarm = useCallback((title: string, body: string) => setAlarm({ id: uid(), title, body }), []);

  /** Alarmı belirli dakika sonra yeniden çalar */
  const snooze = useCallback(
    (minutes = 10) => {
      setAlarm((current) => {
        if (current) {
          if (snoozeTimer.current) window.clearTimeout(snoozeTimer.current);
          snoozeTimer.current = window.setTimeout(() => {
            snoozeTimer.current = null;
            setAlarm({ id: uid(), title: current.title, body: current.body });
            if (!mutedRef.current) {
              beep(3);
              vibrate();
            }
          }, minutes * 60000);
          toast(`${minutes} dakika sonra tekrar hatırlatılacak`, { tone: "info" });
        }
        return null;
      });
    },
    [toast]
  );

  useEffect(
    () => () => {
      Object.values(timers.current).forEach((t) => window.clearTimeout(t));
      if (snoozeTimer.current) window.clearTimeout(snoozeTimer.current);
    },
    []
  );

  const value = useMemo(
    () => ({ toast, raiseAlarm, alarm, dismissAlarm: () => setAlarm(null), muted, setMuted, registerOverlay, setHost, host }),
    [toast, raiseAlarm, alarm, muted, registerOverlay, host]
  );

  const topOffset = overlays > 0 || alarm ? "top-3" : "top-[76px]";

  const layers = (
    <>
      <AnimatePresence>
        {alarm && (
          <motion.div
            key={alarm.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="pointer-events-auto absolute inset-0 z-[80] grid place-items-center bg-black/80 p-6 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-sm rounded-3xl border border-[#00e676]/40 bg-[var(--c-bg1)] p-6 text-center shadow-[0_0_60px_rgba(0,230,118,0.25)]"
            >
              <div className="relative mx-auto grid h-20 w-20 place-items-center">
                <span className="absolute inset-0 rounded-full bg-[#00e676]/25" style={{ animation: "pulse-ring 1.6s ease-out infinite" }} />
                <span className="glow-green relative grid h-16 w-16 place-items-center rounded-full bg-[#00e676] text-[#04110a]">
                  <AlarmClock size={30} strokeWidth={2.4} />
                </span>
              </div>
              <p lang="en" className="mt-4 text-[11px] font-extrabold uppercase tracking-[0.24em] text-[var(--c-acc)]">FitLife Hatırlatma</p>
              <h3 className="font-display mt-1 text-2xl text-[var(--c-text)]">{alarm.title}</h3>
              <p className="mt-2 text-[13.5px] leading-relaxed text-[var(--c-sub)]">{alarm.body}</p>
              <div className="mt-5 grid grid-cols-2 gap-2">
                <button
                  onClick={() => snooze(10)}
                  className="flex items-center justify-center gap-1.5 rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg2)] py-3 text-[13px] font-bold text-[var(--c-text2)] active:scale-95"
                >
                  <AlarmClock size={15} /> Ertele · 10 dk
                </button>
                <button onClick={() => setAlarm(null)} className="glow-green rounded-xl bg-[#00e676] py-3 text-[13px] font-extrabold text-[#04110a] active:scale-95">
                  Tamam
                </button>
              </div>
              <button
                onClick={() => { setMuted(true); setAlarm(null); }}
                className="mt-2 flex w-full items-center justify-center gap-1.5 py-2 text-[12px] font-semibold text-[var(--c-mute)] active:scale-95"
              >
                <VolumeX size={13} /> Bu alarmın sesini kapat
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className={`pointer-events-none absolute inset-x-0 z-[96] flex flex-col items-center gap-2 px-4 transition-all duration-300 ${topOffset}`}>
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              layout
              initial={{ opacity: 0, y: -14, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.96 }}
              className="pointer-events-auto flex w-full max-w-sm items-center gap-3 rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg1)]/97 px-4 py-3 shadow-[0_10px_40px_rgba(0,0,0,0.65)] backdrop-blur"
            >
              <span
                className={`grid h-8 w-8 shrink-0 place-items-center rounded-full ${
                  t.tone === "danger" ? "bg-[#f87171]/15 text-[var(--c-red)]" : t.tone === "info" ? "bg-[#38bdf8]/15 text-[var(--c-blue)]" : "bg-[#00e676]/15 text-[var(--c-acc)]"
                }`}
              >
                {t.tone === "danger" ? <TriangleAlert size={16} /> : t.tone === "info" ? <Info size={16} /> : <Check size={16} strokeWidth={3} />}
              </span>
              <p className="flex-1 text-[13px] font-semibold leading-snug text-[var(--c-text)]">{t.message}</p>
              {t.actionLabel && (
                <button
                  onClick={() => { t.onAction?.(); remove(t.id); }}
                  className="shrink-0 rounded-lg bg-[#00e676]/15 px-3 py-1.5 text-[12px] font-extrabold uppercase tracking-wide text-[var(--c-acc)] active:scale-95"
                >
                  {t.actionLabel}
                </button>
              )}
              <button onClick={() => remove(t.id)} className="shrink-0 text-[var(--c-mute)]" aria-label="Bildirimi kapat">
                <X size={15} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </>
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      {host ? (
        createPortal(layers, host)
      ) : (
        <div className="pointer-events-none fixed inset-0 z-[95] mx-auto max-w-[430px]">{layers}</div>
      )}
    </Ctx.Provider>
  );
}

export function useFeedback(): FeedbackValue {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useFeedback, FeedbackProvider içinde kullanılmalı");
  return ctx;
}
