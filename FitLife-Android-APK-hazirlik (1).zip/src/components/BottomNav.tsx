import { Home, CalendarDays, Compass, TrendingUp, User } from "lucide-react";
import { motion } from "framer-motion";
import type { TabId } from "../types";
import { cn } from "../utils/cn";

const TABS: { id: TabId; label: string; icon: typeof Home }[] = [
  { id: "home", label: "Ana Sayfa", icon: Home },
  { id: "program", label: "Programım", icon: CalendarDays },
  { id: "discover", label: "Keşfet", icon: Compass },
  { id: "progress", label: "İlerleme", icon: TrendingUp },
  { id: "profile", label: "Profil", icon: User },
];

export default function BottomNav({ active, onChange }: { active: TabId; onChange: (t: TabId) => void }) {
  return (
    <nav className="sticky bottom-0 z-30 border-t border-[var(--c-line)] bg-[var(--c-bg1)]/97 shadow-[0_-14px_28px_rgba(4,6,5,0.9)] pb-[max(0.6rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur-xl">
      <div className="grid grid-cols-5 px-1">
        {TABS.map((t) => {
          const Icon = t.icon;
          const isActive = active === t.id;
          return (
            <button
              key={t.id}
              onClick={() => onChange(t.id)}
              className="relative flex flex-col items-center gap-1 rounded-xl px-2 py-1.5"
              aria-label={t.label}
            >
              {isActive && (
                <motion.span
                  layoutId="nav-glow"
                  className="absolute -top-[9px] h-[3px] w-10 rounded-full bg-[#00e676] shadow-[0_0_12px_#00e676]"
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                />
              )}
              <span
                className={cn(
                  "grid h-9 w-11 place-items-center rounded-xl transition-colors",
                  isActive ? "bg-[#00e676]/15 text-[var(--c-acc)]" : "text-[var(--c-mute)]"
                )}
              >
                <Icon size={21} strokeWidth={isActive ? 2.4 : 1.9} />
              </span>
              <span
                className={cn(
                  "text-[10.5px] font-semibold",
                  isActive ? "text-[var(--c-text)]" : "text-[var(--c-mute)]"
                )}
              >
                {t.label}
              </span>
              {isActive && (
                <motion.span
                  layoutId="nav-dot"
                  className="h-1 w-1 rounded-full bg-[#00e676]"
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
