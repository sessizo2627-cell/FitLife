import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Flame,
  Footprints,
  Timer,
  Play,
  ChevronRight,
  Droplets,
  Zap,
  Target,
  CalendarRange,
  Quote,
  Sparkles,
  Utensils,
  Plus,
  Trash2,
  RefreshCw,
  Dumbbell,
  Check,
  HeartPulse,
  Moon,
} from "lucide-react";
import type { Meal, TabId } from "../types";
import { useStore } from "../store/store";
import { useFeedback } from "./Feedback";
import { getGoal, getTodayWorkout, QUOTES } from "../data/fitness";
import { calorieGoal, dayProgress, exKey, getDay, mealKcal, mealProtein, proteinGoal } from "../lib/calc";
import { DAY_SHORT, currentWeekDates, dateKey, fmtDuration, mondayIndex, programDay, uid, formatDateTR } from "../lib/date";
import { Ring, SectionTitle, Card, ProgressBar, Chip, Sheet, NeonButton, Field, Stepper, EmptyState } from "./ui";
import { useStartSession } from "./WorkoutSession";
import { unlockAudio } from "../lib/notify";
import { heartZone } from "../lib/health";
import { cn } from "../utils/cn";

const QUICK_MEALS = [
  { name: "Yulaf + Muz", kcal: 350, protein: 12 },
  { name: "Tavuk & Pilav", kcal: 620, protein: 45 },
  { name: "Protein Shake", kcal: 180, protein: 30 },
  { name: "Omlet (3 yumurta)", kcal: 300, protein: 21 },
  { name: "Yoğurt + Kuruyemiş", kcal: 280, protein: 15 },
  { name: "Ton Balıklı Salata", kcal: 320, protein: 32 },
];

export default function HomeScreen({
  onNavigate,
  onOpenSession,
}: {
  onNavigate: (t: TabId) => void;
  onOpenSession: () => void;
}) {
  const { state, dispatch, snapshot, undo } = useStore();
  const { toast } = useFeedback();
  const startSession = useStartSession();
  const profile = state.profile!;
  const today = dateKey();
  const log = getDay(state, today);
  const prog = dayProgress(state, today);
  const goal = getGoal(profile.goalId);
  const workout = getTodayWorkout(profile.goalId);
  const dayIdx = mondayIndex();
  const day = Math.min(Math.max(1, programDay(profile.startDate)), profile.durationDays);
  const pct = Math.round((day / profile.durationDays) * 100);

  const kcalTarget = calorieGoal(profile);
  const proteinTarget = proteinGoal(profile);
  const kcal = mealKcal(log);

  const [sheet, setSheet] = useState<null | "water" | "steps" | "meals">(null);
  const [mealName, setMealName] = useState("");
  const [mealKcalInput, setMealKcalInput] = useState("");
  const [mealProteinInput, setMealProteinInput] = useState("");
  const [mealError, setMealError] = useState("");
  const [stepInput, setStepInput] = useState(String(log.steps));
  const [quoteIdx, setQuoteIdx] = useState(() => new Date().getDate() % QUOTES.length);
  const quote = QUOTES[quoteIdx];

  const weekKeys = useMemo(() => currentWeekDates(), []);
  const weekActivity = weekKeys.map((k) => ({ key: k, value: state.days[k] ? dayProgress(state, k).total : 0 }));
  const weekDone = weekKeys.filter((k) => state.days[k]?.workoutDone).length;

  const health = state.health[today] ?? Object.values(state.health).sort((a, b) => b.date.localeCompare(a.date))[0];
  const hr = health?.heartRateAvg;
  const zone = hr ? heartZone(hr, profile.age) : null;
  const hour = new Date().getHours();
  const greeting = hour < 6 ? "İyi geceler" : hour < 12 ? "Günaydın" : hour < 18 ? "İyi günler" : "İyi akşamlar";

  const setWater = (n: number) => dispatch({ type: "PATCH_DAY", date: today, patch: { water: Math.max(0, Math.min(30, n)) } });

  const addMeal = () => {
    const name = mealName.trim();
    const energy = Math.round(Number(mealKcalInput));
    const protein = Math.round(Number(mealProteinInput) || 0);
    if (!name) return setMealError("Öğün adı gerekli.");
    if (!energy || energy <= 0 || energy > 5000) return setMealError("Kalori 1 – 5000 arasında olmalı.");
    const meal: Meal = { id: uid(), name, kcal: energy, protein, time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) };
    dispatch({ type: "ADD_MEAL", date: today, meal });
    setMealName("");
    setMealKcalInput("");
    setMealProteinInput("");
    setMealError("");
    toast(`${name} eklendi • ${energy} kcal`);
  };

  const removeMeal = (m: Meal) => {
    snapshot();
    dispatch({ type: "DELETE_MEAL", date: today, id: m.id });
    toast(`${m.name} silindi`, { tone: "danger", actionLabel: "Geri Al", onAction: () => undo() });
  };

  const saveSteps = () => {
    const v = Math.round(Number(stepInput));
    if (Number.isNaN(v) || v < 0 || v > 100000) {
      toast("Adım sayısı 0 – 100.000 arasında olmalı", { tone: "danger" });
      return;
    }
    dispatch({ type: "PATCH_DAY", date: today, patch: { steps: v } });
    setSheet(null);
    toast(`Adım güncellendi: ${v.toLocaleString("tr-TR")}`);
  };

  const toggleQuickExercise = (i: number) => {
    unlockAudio();
    dispatch({ type: "TOGGLE_EXERCISE", date: today, key: exKey(profile.goalId, dayIdx, i) });
  };

  return (
    <div className="space-y-5 px-4 pb-6 pt-4">
      {/* selamlama + günlük halka */}
      <div className="flex items-center justify-between gap-3 px-1">
        <div className="min-w-0">
          <p className="text-[11.5px] font-semibold uppercase tracking-[0.18em] text-[var(--c-mute)]">{formatDateTR()}</p>
          <h2 className="font-display mt-1 truncate text-[27px] leading-tight text-[var(--c-text)]">
            {greeting}, <span className="text-[var(--c-acc)]">{profile.name.split(" ")[0]}</span>
          </h2>
          <p className="mt-1 text-[12.5px] text-[var(--c-sub)]">
            {prog.total >= 100 ? "Günlük hedeflerin tamam! Muhteşem iş." : `Günlük hedeflerinin %${prog.total} tamamlandı.`}
          </p>
        </div>
        <Ring size={86} stroke={9} progress={prog.total / 100}>
          <div className="text-center">
            <p className="font-display text-[20px] leading-none text-[var(--c-text)]">{prog.total}</p>
            <p className="text-[9px] font-bold uppercase tracking-wider text-[var(--c-mute)]">puan</p>
          </div>
        </Ring>
      </div>

      {/* hedef / program */}
      <Card className="card-sheen relative overflow-hidden border-[#00e676]/25 bg-gradient-to-br from-[var(--c-tint)] via-[var(--c-bg1)] to-[var(--c-bg1)] p-5">
        <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-[#00e676]/15 blur-[60px]" />
        <p className="font-display text-stroke pointer-events-none absolute -top-4 right-2 select-none text-[62px] leading-none opacity-25">
          {String(day).padStart(2, "0")}
        </p>
        <div className="flex flex-wrap items-center gap-2">
          <span className="flex items-center gap-1.5 rounded-full bg-[#00e676] px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wide text-[#04110a]">
            <Target size={12} strokeWidth={2.8} /> {goal.title}
          </span>
          <span className="flex items-center gap-1.5 rounded-full border border-[var(--c-line3)] px-2.5 py-1 text-[11px] font-bold text-[var(--c-sub)]">
            <CalendarRange size={12} /> {profile.durationDays} Günlük Plan
          </span>
        </div>
        <div className="mt-4 flex items-end justify-between">
          <div>
            <p className="text-[12px] font-semibold text-[var(--c-sub)]">Program Günü</p>
            <p className="mt-0.5 text-[15px] font-extrabold text-[var(--c-text)]">
              {day}. gün <span className="font-medium text-[var(--c-mute)]">/ {profile.durationDays}</span>
            </p>
          </div>
          <p className="font-display text-3xl text-[var(--c-acc)]">%{pct}</p>
        </div>
        <ProgressBar value={pct} className="mt-2.5" />
        <div className="mt-3 flex items-center justify-between text-[12px]">
          <span className="text-[var(--c-sub)]">Hedef: <b className="text-[var(--c-text)]">{profile.targetWeight} kg</b></span>
          <button onClick={() => onNavigate("progress")} className="flex items-center gap-1 font-bold text-[var(--c-acc)]">
            İlerlemeyi Gör <ChevronRight size={14} />
          </button>
        </div>
      </Card>

      {/* devam eden oturum */}
      {state.session && (
        <button
          onClick={onOpenSession}
          className="glow-green flex w-full items-center gap-3 rounded-2xl border border-[#00e676] bg-[#00e676]/10 p-4 text-left active:scale-[0.99]"
        >
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#00e676] text-[#04110a]"><Play size={19} fill="currentColor" /></span>
          <span className="flex-1">
            <span className="block text-[14px] font-extrabold text-[var(--c-text)]">Devam eden antrenman</span>
            <span className="block text-[12px] text-[var(--c-acc2)]">Kaldığın yerden devam et • {fmtDuration(state.session.accumulated)}</span>
          </span>
          <ChevronRight size={18} className="text-[var(--c-acc)]" />
        </button>
      )}

      {/* marquee */}
      <div className="overflow-hidden rounded-xl border border-[var(--c-line)] bg-[var(--c-bg1)] py-2">
        <div className="animate-marquee flex w-max items-center gap-6 whitespace-nowrap px-2">
          {[0, 1].map((k) => (
            <div key={k} className="flex items-center gap-6">
              {["DİSİPLİN", "GÜÇ", "ODAK", "İSTİKRAR", "SONUÇ"].map((w) => (
                <span key={w} className="flex items-center gap-6">
                  <span className="font-display text-[13px] tracking-[0.2em] text-[var(--c-mute2)]">{w}</span>
                  <Zap size={12} className="text-[var(--c-acc)]" fill="#00e676" />
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* günlük özet */}
      <div>
        <SectionTitle title="Bugünün Özeti" subtitle="Dokun, güncelle — ilerleme otomatik hesaplanır" />
        <div className="grid grid-cols-2 gap-2.5">
          <button onClick={() => setSheet("meals")} className="text-left active:scale-[0.99]">
            <Card className="flex h-full items-center gap-2.5 p-3">
              <Ring size={56} stroke={7} progress={prog.nutrition} color="#ffb020">
                <Flame size={16} className="text-[var(--c-amber)]" fill="#ffb020" />
              </Ring>
              <div className="min-w-0">
                <p className="text-[18px] font-extrabold leading-none text-[var(--c-text)]">{kcal.toLocaleString("tr-TR")}</p>
                <p className="mt-1 whitespace-nowrap text-[10.5px] font-semibold text-[var(--c-sub)]">/ {kcalTarget.toLocaleString("tr-TR")} kcal</p>
                <p className="mt-1 flex items-center gap-1 whitespace-nowrap text-[10.5px] font-bold text-[var(--c-amber)]"><Plus size={10} /> Öğün Ekle</p>
              </div>
            </Card>
          </button>
          <button onClick={() => setSheet("water")} className="text-left active:scale-[0.99]">
            <Card className="flex h-full items-center gap-2.5 p-3">
              <Ring size={56} stroke={7} progress={prog.water} color="#38bdf8">
                <span className="text-[14px] font-extrabold text-[var(--c-text)]">{log.water}</span>
              </Ring>
              <div className="min-w-0">
                <p className="text-[18px] font-extrabold leading-none text-[var(--c-text)]">{log.water}<span className="text-[11px] text-[var(--c-mute)]">/{profile.waterGoal}</span></p>
                <p className="mt-1 whitespace-nowrap text-[10.5px] font-semibold text-[var(--c-sub)]">bardak su</p>
                <p className="mt-1 flex items-center gap-1 whitespace-nowrap text-[10.5px] font-bold text-[var(--c-blue)]"><Droplets size={10} /> Su Ekle</p>
              </div>
            </Card>
          </button>
          <button onClick={() => { setStepInput(String(log.steps)); setSheet("steps"); }} className="text-left active:scale-[0.99]">
            <Card className="flex h-full items-center gap-3 p-3.5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#a78bfa]/12 text-[var(--c-violet)]"><Footprints size={20} /></span>
              <div className="min-w-0">
                <p className="text-[17px] font-extrabold leading-none text-[var(--c-text)]">{log.steps.toLocaleString("tr-TR")}</p>
                <p className="mt-1 truncate text-[11px] font-semibold text-[var(--c-sub)]">/ {profile.stepGoal.toLocaleString("tr-TR")} adım</p>
              </div>
            </Card>
          </button>
          <Card className="flex h-full items-center gap-3 p-3.5">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#00e676]/10 text-[var(--c-acc)]"><Timer size={20} /></span>
            <div className="min-w-0">
              <p className="text-[17px] font-extrabold leading-none text-[var(--c-text)]">{Math.round(log.activeSeconds / 60)} dk</p>
              <p className="mt-1 truncate text-[11px] font-semibold text-[var(--c-sub)]">aktif antrenman</p>
            </div>
          </Card>
        </div>
      </div>

      {health && (hr || health.sleepMinutes) && (
        <button onClick={() => onNavigate("profile")} className="w-full text-left active:scale-[0.99]">
          <Card className="flex items-center gap-3 border-[var(--c-red)]/20 p-4">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--c-red)]/10 text-[var(--c-red)]"><HeartPulse size={20} /></span>
            <span className="min-w-0 flex-1">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Samsung Health • {health.date === today ? "bugün" : "son kayıt"}</span>
              <span className="mt-0.5 flex flex-wrap items-baseline gap-x-3 text-[14px] font-extrabold text-[var(--c-text)]">
                {hr && <span>{hr} <span className="text-[11px] font-semibold text-[var(--c-mute)]">bpm</span></span>}
                {health.sleepMinutes && <span className="flex items-center gap-1"><Moon size={12} className="text-[var(--c-blue)]" /> {Math.floor(health.sleepMinutes / 60)}s {health.sleepMinutes % 60}dk</span>}
                {health.caloriesBurned && <span>{health.caloriesBurned} <span className="text-[11px] font-semibold text-[var(--c-mute)]">kcal</span></span>}
              </span>
              {zone && <span className="text-[11px] font-bold" style={{ color: zone.color }}>{zone.label} bölgesi</span>}
            </span>
            <ChevronRight size={18} className="text-[var(--c-mute)]" />
          </Card>
        </button>
      )}

      {/* bugünün antrenmanı */}
      <div>
        <SectionTitle
          title="Bugünün Antrenmanı"
          subtitle={`${workout.day} • ${workout.focus}`}
          action={
            <button onClick={() => onNavigate("program")} className="flex items-center gap-0.5 text-[12px] font-bold text-[var(--c-acc)]">
              Tümü <ChevronRight size={15} />
            </button>
          }
        />
        <Card className="card-sheen overflow-hidden">
          <div className="relative h-36">
            <img src={goal.image} alt={workout.title} className="h-full w-full object-cover" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[var(--c-bg1)] via-[var(--c-bg1)]/30 to-transparent" />
            {workout.restDay && (
              <span className="absolute left-3 top-3 rounded-full bg-[var(--c-bg1)]/80 px-2.5 py-1 text-[11px] font-bold text-[var(--c-sub)] backdrop-blur">
                Dinlenme Günü
              </span>
            )}
            <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-4">
              <div>
                <div className="flex gap-1.5">
                  <Chip active>{workout.duration}</Chip>
                  <Chip>{prog.exerciseDone}/{prog.exerciseTotal} hareket</Chip>
                </div>
                <h4 className="font-condensed mt-1.5 text-xl font-semibold uppercase tracking-wide text-[var(--c-text)]">{workout.title}</h4>
              </div>
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => {
                  if (state.session) onOpenSession();
                  else {
                    startSession(dayIdx);
                    onOpenSession();
                  }
                }}
                className="glow-green grid h-13 w-13 shrink-0 place-items-center rounded-full bg-[#00e676] p-3.5 text-[#04110a]"
                aria-label="Antrenmanı başlat"
              >
                <Play size={20} fill="currentColor" />
              </motion.button>
            </div>
          </div>
          <div className="space-y-1 p-2">
            {workout.exercises.slice(0, 3).map((e, i) => {
              const done = !!log.exercises[exKey(profile.goalId, dayIdx, i)];
              return (
                <button key={i} onClick={() => toggleQuickExercise(i)} className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 active:bg-[var(--c-text)]/[0.03]">
                  <span className="flex items-center gap-3">
                    <span className={cn("grid h-6 w-6 place-items-center rounded-full border text-[10px] font-bold", done ? "border-[#00e676] bg-[#00e676] text-[#04110a]" : "border-[var(--c-line4)] text-[var(--c-mute)]")}>
                      {done ? <Check size={13} strokeWidth={3} /> : i + 1}
                    </span>
                    <span className={cn("text-[13.5px] font-semibold", done ? "text-[var(--c-mute)] line-through" : "text-[var(--c-text)]")}>{e.name}</span>
                  </span>
                  <span className="text-[12px] font-bold text-[var(--c-sub)]">{e.sets}</span>
                </button>
              );
            })}
            <button onClick={() => onNavigate("program")} className="flex w-full items-center justify-center gap-1 rounded-xl bg-[var(--c-text)]/[0.04] py-3 text-[13px] font-bold text-[var(--c-acc)]">
              Programın Tamamını Gör <ChevronRight size={15} />
            </button>
          </div>
        </Card>
      </div>

      {/* haftalık aktivite — gerçek kayıtlardan */}
      <div>
        <SectionTitle title="Haftalık Aktivite" subtitle="Bu haftanın günlük tamamlanma puanı" />
        <Card className="p-4">
          <div className="flex h-28 items-end justify-between gap-2">
            {weekActivity.map((a, i) => (
              <div key={a.key} className="flex flex-1 flex-col items-center gap-1.5">
                <span className="text-[9.5px] font-bold text-[var(--c-mute)]">{a.value > 0 ? a.value : ""}</span>
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: `${Math.max(4, a.value)}%` }}
                  transition={{ delay: i * 0.05, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                  className={cn(
                    "w-full rounded-lg",
                    a.key === today
                      ? "bg-gradient-to-t from-[#00b248] to-[#00e676] shadow-[0_0_12px_rgba(0,230,118,0.5)]"
                      : a.value > 0
                        ? "bg-[var(--c-scroll)]"
                        : "bg-[var(--c-line)]"
                  )}
                />
                <span className={cn("text-[10px] font-bold", a.key === today ? "text-[var(--c-acc)]" : "text-[var(--c-mute)]")}>{DAY_SHORT[i]}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-[var(--c-line)] pt-3">
            <span className="text-[12px] text-[var(--c-sub)]">Bu hafta <b className="text-[var(--c-text)]">{weekDone}/{profile.weeklyTarget}</b> antrenman</span>
            <span className="flex items-center gap-1 text-[12px] font-bold text-[var(--c-acc)]">
              <Dumbbell size={13} /> {weekDone >= profile.weeklyTarget ? "Hedef tamam" : `${profile.weeklyTarget - weekDone} antrenman kaldı`}
            </span>
          </div>
        </Card>
      </div>

      {/* motivasyon */}
      <Card className="relative overflow-hidden border-[#00e676]/20 bg-gradient-to-br from-[var(--c-tint)] to-[var(--c-bg1)] p-5">
        <Quote size={44} className="absolute -right-1 -top-1 text-[var(--c-acc)]/10" />
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles size={14} className="text-[var(--c-acc)]" />
            <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-[var(--c-acc)]">Günün Motivasyonu</span>
          </div>
          <button onClick={() => setQuoteIdx((i) => (i + 1) % QUOTES.length)} className="flex items-center gap-1 rounded-full border border-[var(--c-line3)] px-2.5 py-1 text-[11px] font-bold text-[var(--c-sub)] active:scale-95">
            <RefreshCw size={11} /> Yenile
          </button>
        </div>
        <p className="font-condensed mt-2 text-[19px] font-medium italic leading-snug text-[var(--c-text)]">"{quote.text}"</p>
        <p className="mt-1.5 text-[12px] text-[var(--c-mute)]">— {quote.author}</p>
      </Card>

      {/* SU */}
      <Sheet open={sheet === "water"} onClose={() => setSheet(null)} title="Su Takibi" subtitle={`Günlük hedefin ${profile.waterGoal} bardak (≈ ${(profile.waterGoal * 0.25).toFixed(1)} litre).`}>
        <div className="flex items-center justify-center gap-4">
          <button aria-label="Su azalt" onClick={() => setWater(log.water - 1)} className="grid h-12 w-12 place-items-center rounded-full border border-[var(--c-line3)] bg-[var(--c-bg2)] text-2xl font-bold text-[var(--c-text)] active:scale-90">−</button>
          <div className="text-center">
            <p className="font-display text-5xl text-[var(--c-blue)]">{log.water}</p>
            <p className="text-[12px] font-semibold text-[var(--c-sub)]">bardak içildi</p>
          </div>
          <button aria-label="Su ekle" onClick={() => setWater(log.water + 1)} className="grid h-12 w-12 place-items-center rounded-full bg-[#38bdf8] text-2xl font-bold text-[#04121a] shadow-[0_0_20px_rgba(56,189,248,0.4)] active:scale-90">+</button>
        </div>
        <div className="mt-4 grid grid-cols-6 gap-1.5">
          {Array.from({ length: profile.waterGoal }).map((_, i) => (
            <button
              key={i}
              onClick={() => setWater(i + 1 === log.water ? i : i + 1)}
              className={cn("grid h-11 place-items-center rounded-xl border text-[13px]", i < log.water ? "border-[#38bdf8]/50 bg-[#38bdf8]/15 text-[var(--c-blue)]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-mute2)]")}
            >
              <Droplets size={16} />
            </button>
          ))}
        </div>
        <ProgressBar value={prog.water * 100} className="mt-4" />
        <p className="mt-2 text-center text-[12px] text-[var(--c-sub)]">Hedefin %{Math.round(prog.water * 100)} tamamlandı</p>
        <div className="mt-4 flex items-center justify-between rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg1)] p-3">
          <span className="text-[12.5px] font-semibold text-[var(--c-sub)]">Günlük hedef (bardak)</span>
          <div className="w-[168px]">
            <Stepper value={profile.waterGoal} min={4} max={20} onChange={(v) => dispatch({ type: "PATCH_PROFILE", patch: { waterGoal: v } })} />
          </div>
        </div>
        <NeonButton onClick={() => setSheet(null)} className="mt-4 w-full">Tamam</NeonButton>
      </Sheet>

      {/* ADIM */}
      <Sheet open={sheet === "steps"} onClose={() => setSheet(null)} title="Adım Sayısı" subtitle="Telefonunun sağlık uygulamasındaki değeri buraya girebilirsin.">
        <Field label="Bugünkü adım" value={stepInput} onChange={setStepInput} suffix="adım" inputMode="numeric" />
        <div className="mt-3 grid grid-cols-4 gap-2">
          {[1000, 2500, 5000, 10000].map((v) => (
            <button key={v} onClick={() => setStepInput(String((Number(stepInput) || 0) + v))} className="rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg1)] py-2.5 text-[12.5px] font-bold text-[var(--c-text)] active:scale-95">
              +{v.toLocaleString("tr-TR")}
            </button>
          ))}
        </div>
        <div className="mt-4 rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg1)] p-3">
          <p className="mb-2 text-[12.5px] font-semibold text-[var(--c-sub)]">Günlük adım hedefi</p>
          <Stepper value={profile.stepGoal} step={500} min={1000} max={50000} suffix="adım" onChange={(v) => dispatch({ type: "PATCH_PROFILE", patch: { stepGoal: v } })} />
        </div>
        <NeonButton onClick={saveSteps} className="mt-4 w-full">Kaydet</NeonButton>
        <p className="mt-2 text-center text-[11px] text-[var(--c-mute)]">FitLife adım sensörüne doğrudan bağlanmaz; değerleri sen girersin.</p>
      </Sheet>

      {/* ÖĞÜNLER */}
      <Sheet open={sheet === "meals"} onClose={() => setSheet(null)} title="Beslenme Günlüğü" subtitle={`Hedef: ${kcalTarget.toLocaleString("tr-TR")} kcal • ${proteinTarget} g protein`}>
        <div className="grid grid-cols-3 gap-2">
          {[
            { v: kcal.toLocaleString("tr-TR"), l: "Alınan kcal", c: "#ffb020" },
            { v: `${mealProtein(log)} g`, l: "Protein", c: "#00e676" },
            { v: Math.max(0, kcalTarget - kcal).toLocaleString("tr-TR"), l: "Kalan kcal", c: "#38bdf8" },
          ].map((s) => (
            <div key={s.l} className="rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] p-3 text-center">
              <p className="text-[16px] font-extrabold" style={{ color: s.c }}>{s.v}</p>
              <p className="text-[10.5px] font-semibold text-[var(--c-mute)]">{s.l}</p>
            </div>
          ))}
        </div>

        <div className="mt-4 rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg1)] p-3.5">
          <p className="mb-2 flex items-center gap-1.5 text-[12px] font-bold uppercase tracking-wider text-[var(--c-sub)]"><Utensils size={13} /> Öğün Ekle</p>
          <Field label="Öğün adı" type="text" value={mealName} onChange={(v) => { setMealName(v); setMealError(""); }} placeholder="örn. Tavuk & Pilav" />
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Field label="Kalori" value={mealKcalInput} onChange={(v) => { setMealKcalInput(v); setMealError(""); }} suffix="kcal" inputMode="numeric" />
            <Field label="Protein" value={mealProteinInput} onChange={setMealProteinInput} suffix="g" inputMode="numeric" />
          </div>
          {mealError && <p className="mt-2 text-[12px] font-semibold text-[var(--c-red)]">{mealError}</p>}
          <div className="mt-2.5 flex flex-wrap gap-1.5">
            {QUICK_MEALS.map((q) => (
              <button
                key={q.name}
                onClick={() => { setMealName(q.name); setMealKcalInput(String(q.kcal)); setMealProteinInput(String(q.protein)); setMealError(""); }}
                className="rounded-full border border-[var(--c-line3)] bg-[var(--c-bg0)] px-2.5 py-1.5 text-[11px] font-bold text-[var(--c-sub)] active:scale-95"
              >
                {q.name}
              </button>
            ))}
          </div>
          <NeonButton onClick={addMeal} className="mt-3 w-full">Öğünü Kaydet</NeonButton>
        </div>

        <div className="mt-4">
          <p className="mb-2 px-1 text-[12px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Bugünkü öğünler ({log.meals.length})</p>
          {log.meals.length === 0 ? (
            <EmptyState icon={<Utensils size={20} />} title="Henüz öğün yok" desc="İlk öğününü ekle; kalori ve protein hedefin otomatik hesaplansın." />
          ) : (
            <div className="space-y-2">
              {log.meals.map((m) => (
                <div key={m.id} className="flex items-center gap-3 rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] px-3.5 py-3">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[#ffb020]/12 text-[var(--c-amber)]"><Utensils size={16} /></span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-bold text-[var(--c-text)]">{m.name}</p>
                    <p className="text-[11.5px] text-[var(--c-mute)]">{m.time} • {m.kcal} kcal • {m.protein} g protein</p>
                  </div>
                  <button onClick={() => removeMeal(m)} className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-[#f87171]/30 bg-[#f87171]/10 text-[var(--c-red)] active:scale-90" aria-label="Öğünü sil">
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </Sheet>
    </div>
  );
}
