import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Flame,
  TrendingUp,
  Dumbbell,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Check,
  Clock,
  CalendarRange,
  User,
  Sparkles,
} from "lucide-react";
import { GOALS, DURATIONS, HERO_IMAGE } from "../data/fitness";
import type { GoalId, UserProfile } from "../types";
import { cn } from "../utils/cn";
import { NeonButton } from "./ui";

const GOAL_ICONS: Record<string, typeof Flame> = {
  flame: Flame,
  "trending-up": TrendingUp,
  dumbbell: Dumbbell,
  shield: ShieldCheck,
};

const STEPS = ["Hoş Geldin", "Hedefin", "Süren", "Profilin", "Hazırsın"];

export default function Onboarding({
  onComplete,
  initial,
  onCancel,
}: {
  onComplete: (p: UserProfile) => void;
  initial?: UserProfile;
  onCancel?: () => void;
}) {
  const [step, setStep] = useState(initial ? 1 : 0);
  const [goalId, setGoalId] = useState<GoalId>(initial?.goalId ?? "kas-gelistirme");
  const [duration, setDuration] = useState<number>(initial?.durationDays ?? 30);
  const [customOpen, setCustomOpen] = useState(!!initial && !DURATIONS.includes(initial.durationDays));
  const [customDays, setCustomDays] = useState(String(initial?.durationDays ?? 45));
  const [name, setName] = useState(initial?.name ?? "");
  const [age, setAge] = useState(String(initial?.age ?? 25));
  const [height, setHeight] = useState(String(initial?.height ?? 178));
  const [weight, setWeight] = useState(String(initial?.weight ?? 75));
  const [targetWeight, setTargetWeight] = useState(String(initial?.targetWeight ?? 80));
  const [gender, setGender] = useState<"erkek" | "kadin">(initial?.gender ?? "erkek");
  const [level, setLevel] = useState<"baslangic" | "orta" | "ileri">(initial?.level ?? "orta");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const goal = GOALS.find((g) => g.id === goalId)!;
  const finalDuration = duration;

  const validateProfile = () => {
    const e: Record<string, string> = {};
    const a = Number(age);
    const h = Number(height);
    const w = Number(String(weight).replace(",", "."));
    const t = Number(String(targetWeight).replace(",", "."));
    if (name.trim().length < 2) e.name = "Adın en az 2 karakter olmalı.";
    if (!a || a < 12 || a > 100) e.age = "Yaş 12 – 100 arasında olmalı.";
    if (!h || h < 100 || h > 250) e.height = "Boy 100 – 250 cm arasında olmalı.";
    if (!w || w < 30 || w > 300) e.weight = "Kilo 30 – 300 kg arasında olmalı.";
    if (!t || t < 30 || t > 300) e.targetWeight = "Hedef kilo 30 – 300 kg arasında olmalı.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (step === 2 && customOpen) {
      const v = Math.round(Number(customDays));
      if (!v || v < 3 || v > 365) {
        setErrors({ duration: "Özel süre 3 – 365 gün arasında olmalı." });
        return;
      }
      setErrors({});
      setDuration(v);
    }
    if (step === 3 && !validateProfile()) return;
    if (step < 4) setStep(step + 1);
  };
  const back = () => {
    if (step === (initial ? 1 : 0)) {
      onCancel?.();
      return;
    }
    setErrors({});
    if (step > 0) setStep(step - 1);
  };

  const finish = () => {
    onComplete({
      name: name.trim() || "Sporcu",
      age: parseInt(age) || 25,
      height: parseInt(height) || 178,
      weight: parseFloat(weight) || 75,
      targetWeight: parseFloat(targetWeight) || 75,
      gender,
      level,
      goalId,
      durationDays: finalDuration,
      customDuration: !DURATIONS.includes(finalDuration),
      startDate: new Date().toISOString(),
      notifications: initial?.notifications ?? true,
      reminders: initial?.reminders ?? true,
      soundEffects: initial?.soundEffects ?? true,
      weeklyTarget: initial?.weeklyTarget ?? 4,
      stepGoal: initial?.stepGoal ?? 8000,
      waterGoal: initial?.waterGoal ?? 12,
      theme: initial?.theme ?? "light",
      healthSource: initial?.healthSource ?? "manual",
    });
  };

  return (
    <div className="relative flex h-full min-h-[100dvh] flex-col bg-[var(--c-bg0)]">
      {/* progress */}
      {step > 0 && (
        <div className="px-5 pt-5">
          <div className="mb-2 flex items-center justify-between">
            <button onClick={back} className="grid h-9 w-9 place-items-center rounded-full border border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-text)] active:scale-95" aria-label="Geri">
              <ChevronLeft size={18} />
            </button>
            <span className="text-[12px] font-semibold text-[var(--c-mute)]">
              Adım {step} / 4 — {STEPS[step]}
            </span>
            <span className="w-9" />
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-[var(--c-bg2)]">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-[#00b248] to-[#00e676]"
              animate={{ width: `${(step / 4) * 100}%` }}
              transition={{ duration: 0.4 }}
            />
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto no-scrollbar">
        <AnimatePresence mode="wait">
          {/* STEP 0 — Welcome */}
          {step === 0 && (
            <motion.div key="s0" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="relative flex min-h-[100dvh] flex-col">
              <div className="relative h-[52dvh] overflow-hidden">
                <img src={HERO_IMAGE} alt="FitLife antrenman" className="h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-b from-[var(--c-bg0)]/60 via-transparent to-[var(--c-bg0)]" />
                <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-[var(--c-bg0)] to-transparent" />
                <div className="absolute left-5 top-5 flex items-center gap-2">
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-[#00e676]">
                    <Dumbbell size={18} strokeWidth={2.6} className="text-[#04110a]" />
                  </div>
                  <span className="font-display text-lg tracking-wide text-[var(--c-text)]">FIT<span className="text-[var(--c-acc)]">LIFE</span></span>
                </div>
              </div>
              <div className="flex flex-1 flex-col px-6 pb-8 -mt-6">
                <div className="mb-3 inline-flex w-fit items-center gap-1.5 rounded-full border border-[#00e676]/30 bg-[#00e676]/10 px-3 py-1.5">
                  <Sparkles size={13} className="text-[var(--c-acc)]" />
                  <span className="text-[11px] font-bold uppercase tracking-widest text-[var(--c-acc)]">Kişisel Fitness Koçun</span>
                </div>
                <h1 className="font-display text-[42px] leading-[1.02] text-[var(--c-text)]">
                  HEDEFİNİ SEÇ,
                  <br />
                  <span className="text-[var(--c-acc)]">FORMUNU İNŞA ET.</span>
                </h1>
                <p className="mt-3 text-[14px] leading-relaxed text-[var(--c-sub)]">
                  Kilo al, kilo ver, kas yap ya da formunu koru. Sana özel programın ve sürenle her gün bir adım ileri git.
                </p>
                <div className="mt-5 grid grid-cols-3 gap-2">
                  {[["4", "Hedef"], ["7-180", "Gün Planı"], ["%100", "Türkçe"]].map(([v, l]) => (
                    <div key={l} className="rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] px-3 py-3 text-center">
                      <p className="font-display text-xl text-[var(--c-acc)]">{v}</p>
                      <p className="text-[11px] font-semibold text-[var(--c-sub)]">{l}</p>
                    </div>
                  ))}
                </div>
                <NeonButton onClick={next} className="mt-6 flex w-full items-center justify-center gap-2 py-4 text-[15px]">
                  Hemen Başla <ChevronRight size={18} strokeWidth={2.6} />
                </NeonButton>
                <p className="mt-3 text-center text-[11px] text-[var(--c-mute2)]">Hesap gerekmez • Verilerin cihazında saklanır</p>
              </div>
            </motion.div>
          )}

          {/* STEP 1 — Goal */}
          {step === 1 && (
            <motion.div key="s1" initial={{ x: 40, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -40, opacity: 0 }} className="px-5 py-6">
              <h2 className="font-display text-3xl text-[var(--c-text)]">HEDEFİN <span className="text-[var(--c-acc)]">NE?</span></h2>
              <p className="mt-1.5 text-[13px] text-[var(--c-sub)]">Sana uygun programı oluşturalım. Bunu sonra değiştirebilirsin.</p>
              <div className="mt-5 space-y-3">
                {GOALS.map((g) => {
                  const Icon = GOAL_ICONS[g.icon];
                  const active = g.id === goalId;
                  return (
                    <button
                      key={g.id}
                      onClick={() => setGoalId(g.id)}
                      className={cn(
                        "relative flex w-full items-center gap-4 overflow-hidden rounded-2xl border p-4 text-left transition-all active:scale-[0.99]",
                        active ? "border-[#00e676] bg-[#00e676]/[0.07] shadow-[0_0_24px_rgba(0,230,118,0.15)]" : "border-[var(--c-line2)] bg-[var(--c-bg1)]"
                      )}
                    >
                      <span className={cn("grid h-13 w-13 shrink-0 place-items-center rounded-2xl p-3.5", active ? "bg-[#00e676] text-[#04110a]" : "bg-[var(--c-line)] text-[var(--c-acc)]")}>
                        <Icon size={22} strokeWidth={2.2} />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className="text-[15px] font-extrabold text-[var(--c-text)]">{g.title}</span>
                          <span className="rounded-full bg-[var(--c-text)]/5 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-[var(--c-sub)]">{g.tag}</span>
                        </span>
                        <span className="mt-1 block text-[12.5px] leading-snug text-[var(--c-sub)]">{g.desc}</span>
                      </span>
                      <span className={cn("grid h-6 w-6 shrink-0 place-items-center rounded-full border", active ? "border-[#00e676] bg-[#00e676]" : "border-[var(--c-line4)]")}>
                        {active && <Check size={14} strokeWidth={3} className="text-[#04110a]" />}
                      </span>
                    </button>
                  );
                })}
              </div>
              <NeonButton onClick={next} className="mt-6 flex w-full items-center justify-center gap-2 py-4">
                Devam Et <ChevronRight size={18} strokeWidth={2.6} />
              </NeonButton>
            </motion.div>
          )}

          {/* STEP 2 — Duration */}
          {step === 2 && (
            <motion.div key="s2" initial={{ x: 40, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -40, opacity: 0 }} className="px-5 py-6">
              <div className="flex items-center gap-2 text-[var(--c-acc)]">
                <CalendarRange size={18} />
                <span className="text-[12px] font-bold uppercase tracking-[0.2em]">Program Süresi</span>
              </div>
              <h2 className="font-display mt-2 text-3xl text-[var(--c-text)]">KAÇ GÜN <span className="text-[var(--c-acc)]">ADANACAKSIN?</span></h2>
              <p className="mt-1.5 text-[13px] text-[var(--c-sub)]">Hazır planlardan birini seç ya da kendi süreni belirle (3 – 365 gün).</p>

              <div className="mt-5 grid grid-cols-3 gap-2.5">
                {DURATIONS.map((d) => {
                  const active = duration === d && !customOpen;
                  return (
                    <button
                      key={d}
                      onClick={() => { setDuration(d); setCustomOpen(false); }}
                      className={cn(
                        "rounded-2xl border p-4 text-center transition-all active:scale-95",
                        active ? "glow-green border-[#00e676] bg-[#00e676] text-[#04110a]" : "border-[var(--c-line2)] bg-[var(--c-bg1)] text-[var(--c-text)]"
                      )}
                    >
                      <p className="font-display text-2xl">{d}</p>
                      <p className={cn("text-[11px] font-bold uppercase tracking-wider", active ? "text-[#04110a]/70" : "text-[var(--c-mute)]")}>Gün</p>
                    </button>
                  );
                })}
                <button
                  onClick={() => setCustomOpen(true)}
                  className={cn(
                    "rounded-2xl border p-4 text-center transition-all active:scale-95",
                    customOpen ? "glow-green border-[#00e676] bg-[#00e676] text-[#04110a]" : "border-dashed border-[var(--c-line4)] bg-transparent text-[var(--c-text)]"
                  )}
                >
                  <p className="font-display text-2xl">+</p>
                  <p className={cn("text-[11px] font-bold uppercase tracking-wider", customOpen ? "text-[#04110a]/70" : "text-[var(--c-mute)]")}>Özel</p>
                </button>
              </div>

              <AnimatePresence>
                {customOpen && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                    <div className="mt-3 rounded-2xl border border-[#00e676]/40 bg-[#00e676]/[0.06] p-4">
                      <label className="text-[12px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Özel süre (gün)</label>
                      <div className="mt-2 flex items-center gap-3">
                        <Clock size={20} className="text-[var(--c-acc)]" />
                        <input
                          type="number"
                          min={3}
                          max={365}
                          value={customDays}
                          onChange={(e) => { setCustomDays(e.target.value); setDuration(Math.min(365, Math.max(3, parseInt(e.target.value) || 3))); }}
                          className="w-full rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg0)] px-4 py-3 text-xl font-extrabold text-[var(--c-text)] outline-none focus:border-[#00e676]"
                        />
                        <span className="text-[13px] font-semibold text-[var(--c-sub)]">gün</span>
                      </div>
                      <div className="mt-3 flex gap-2">
                        {[14, 45, 90, 120].map((v) => (
                          <button key={v} onClick={() => { setCustomDays(String(v)); setDuration(v); }} className="flex-1 rounded-lg border border-[var(--c-line3)] bg-[var(--c-bg1)] py-2 text-[12px] font-bold text-[var(--c-text2)] active:scale-95">
                            {v}
                          </button>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="mt-4 rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[12px] font-semibold text-[var(--c-sub)]">Seçilen plan</p>
                    <p className="mt-0.5 text-[16px] font-extrabold text-[var(--c-text)]">{goal.title} • {customOpen ? customDays : duration} Gün</p>
                  </div>
                  <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#00e676]/10 text-[var(--c-acc)]">
                    <CalendarRange size={22} />
                  </div>
                </div>
                <p className="mt-2 text-[12px] leading-relaxed text-[var(--c-mute)]">
                  Bitiş tahmini: <span className="font-bold text-[var(--c-text2)]">{new Date(Date.now() + (customOpen ? (parseInt(customDays) || 30) : duration) * 86400000).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" })}</span>
                </p>
              </div>

              {errors.duration && <p className="mt-3 text-center text-[12px] font-semibold text-[var(--c-red)]">{errors.duration}</p>}
              <NeonButton onClick={next} className="mt-6 flex w-full items-center justify-center gap-2 py-4">
                Devam Et <ChevronRight size={18} strokeWidth={2.6} />
              </NeonButton>
            </motion.div>
          )}

          {/* STEP 3 — Profile basics */}
          {step === 3 && (
            <motion.div key="s3" initial={{ x: 40, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -40, opacity: 0 }} className="px-5 py-6">
              <div className="flex items-center gap-2 text-[var(--c-acc)]">
                <User size={18} />
                <span className="text-[12px] font-bold uppercase tracking-[0.2em]">Profil Bilgilerin</span>
              </div>
              <h2 className="font-display mt-2 text-3xl text-[var(--c-text)]">SENİ <span className="text-[var(--c-acc)]">TANIYALIM</span></h2>
              <p className="mt-1.5 text-[13px] text-[var(--c-sub)]">Programın bu bilgilere göre kişiselleştirilecek.</p>

              <div className="mt-5 space-y-4">
                <div>
                  <label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Adın</label>
                  <input value={name} onChange={(e) => setName(e.target.value)} placeholder="örn. Emre" className={cn("w-full rounded-2xl border bg-[var(--c-bg1)] px-4 py-3.5 text-[15px] font-semibold text-[var(--c-text)] placeholder:text-[var(--c-mute2)] outline-none focus:border-[#00e676]", errors.name ? "border-[#f87171]" : "border-[var(--c-line3)]")} />
                  {errors.name && <p className="mt-1 text-[11.5px] font-semibold text-[var(--c-red)]">{errors.name}</p>}
                </div>
                <div>
                  <label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Cinsiyet</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["erkek", "kadin"] as const).map((g) => (
                      <button key={g} onClick={() => setGender(g)} className={cn("rounded-2xl border py-3 text-[14px] font-bold active:scale-[0.98]", gender === g ? "border-[#00e676] bg-[#00e676]/10 text-[var(--c-acc)]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-sub)]")}>
                        {g === "erkek" ? "Erkek" : "Kadın"}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { l: "Yaş", v: age, s: setAge, k: "age" },
                    { l: "Boy (cm)", v: height, s: setHeight, k: "height" },
                    { l: "Kilo (kg)", v: weight, s: setWeight, k: "weight" },
                  ].map((f) => (
                    <div key={f.l}>
                      <label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wider text-[var(--c-sub)]">{f.l}</label>
                      <input type="number" inputMode="decimal" value={f.v} onChange={(e) => f.s(e.target.value)} className={cn("w-full rounded-2xl border bg-[var(--c-bg1)] px-3 py-3.5 text-center text-[16px] font-extrabold text-[var(--c-text)] outline-none focus:border-[#00e676]", errors[f.k] ? "border-[#f87171]" : "border-[var(--c-line3)]")} />
                    </div>
                  ))}
                </div>
                {(errors.age || errors.height || errors.weight) && (
                  <p className="text-[11.5px] font-semibold text-[var(--c-red)]">{errors.age ?? errors.height ?? errors.weight}</p>
                )}
                <div>
                  <label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Hedef Kilo (kg)</label>
                  <input type="number" inputMode="decimal" value={targetWeight} onChange={(e) => setTargetWeight(e.target.value)} className={cn("w-full rounded-2xl border bg-[var(--c-bg1)] px-4 py-3.5 text-[15px] font-bold text-[var(--c-text)] outline-none focus:border-[#00e676]", errors.targetWeight ? "border-[#f87171]" : "border-[var(--c-line3)]")} />
                  {errors.targetWeight && <p className="mt-1 text-[11.5px] font-semibold text-[var(--c-red)]">{errors.targetWeight}</p>}
                </div>
                <div>
                  <label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Antrenman Seviyen</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(["baslangic", "orta", "ileri"] as const).map((l) => (
                      <button key={l} onClick={() => setLevel(l)} className={cn("rounded-2xl border py-3 text-[13px] font-bold active:scale-[0.98]", level === l ? "border-[#00e676] bg-[#00e676]/10 text-[var(--c-acc)]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-sub)]")}>
                        {l === "baslangic" ? "Başlangıç" : l === "orta" ? "Orta" : "İleri"}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <NeonButton onClick={next} className="mt-6 flex w-full items-center justify-center gap-2 py-4">
                Devam Et <ChevronRight size={18} strokeWidth={2.6} />
              </NeonButton>
              {Object.keys(errors).length > 0 && (
                <p className="mt-2 text-center text-[12px] font-semibold text-[var(--c-red)]">Devam etmek için işaretli alanları düzelt.</p>
              )}
            </motion.div>
          )}

          {/* STEP 4 — Summary */}
          {step === 4 && (
            <motion.div key="s4" initial={{ x: 40, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -40, opacity: 0 }} className="px-5 py-6">
              <div className="overflow-hidden rounded-3xl border border-[#00e676]/30">
                <div className="relative h-44">
                  <img src={goal.image} alt={goal.title} className="h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--c-bg0)] via-[var(--c-bg0)]/40 to-transparent" />
                  <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
                    <div>
                      <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[var(--c-acc)]">{goal.tag}</p>
                      <h2 className="font-display text-3xl text-[var(--c-text)]">{goal.title.toLocaleUpperCase("tr-TR")}</h2>
                    </div>
                    <div className="rounded-2xl bg-[#00e676] px-3 py-2 text-center">
                      <p className="font-display text-xl leading-none text-[#04110a]">{finalDuration}</p>
                      <p className="text-[10px] font-extrabold uppercase text-[#04110a]/70">Gün</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-3 bg-[var(--c-bg1)] p-4">
                  <div className="flex items-center justify-between rounded-2xl bg-[var(--c-bg1)] px-4 py-3">
                    <span className="text-[13px] text-[var(--c-sub)]">Sporcu</span>
                    <span className="text-[14px] font-extrabold text-[var(--c-text)]">{name || "Sporcu"} • {age} yaş</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    {[[`${height} cm`, "Boy"], [`${weight} kg`, "Kilo"], [`${targetWeight} kg`, "Hedef"]].map(([v, l]) => (
                      <div key={l as string} className="rounded-2xl bg-[var(--c-bg1)] px-2 py-3">
                        <p className="text-[14px] font-extrabold text-[var(--c-text)]">{v}</p>
                        <p className="text-[11px] text-[var(--c-mute)]">{l}</p>
                      </div>
                    ))}
                  </div>
                  <div className="rounded-2xl bg-[var(--c-bg1)] px-4 py-3">
                    <p className="text-[12px] font-bold uppercase tracking-wider text-[var(--c-mute)]">Haftalık Odak</p>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {goal.weeklyFocus.map((w) => (
                        <span key={w} className="rounded-full border border-[#00e676]/30 bg-[#00e676]/10 px-2.5 py-1 text-[11px] font-bold text-[var(--c-acc)]">{w}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <NeonButton onClick={finish} className="mt-5 flex w-full items-center justify-center gap-2 py-4 text-[15px]">
                <Check size={19} strokeWidth={3} /> Programı Başlat
              </NeonButton>
              <p className="mt-3 text-center text-[12px] text-[var(--c-mute)]">1. günün bugün başlıyor. Başarılar, {name || "şampiyon"}!</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
