import "./exercise-anim.css";
import type { Motion } from "../data/exercises";
import { getExercise } from "../data/exercises";
import "../data/discover"; // ekstra egzersizleri kütüphaneye kaydeder
import { Sheet, Chip } from "./ui";
import { cn } from "../utils/cn";

/* İnsan figürlü egzersiz animasyonu.
   Gövde, kol ve bacak parçaları CSS keyframe'leriyle hareket tipine göre döner. */

export default function ExerciseAnimation({
  motion,
  label,
  size = 180,
  gif,
  className,
}: {
  motion: Motion;
  label: string;
  size?: number;
  gif?: string;
  className?: string;
}) {
  if (gif) {
    return (
      <img src={gif} alt={`${label} hareketi`} loading="lazy" style={{ width: size, height: size }} className={cn("rounded-2xl bg-white object-contain", className)} />
    );
  }

  const horizontal = motion === "plank" || motion === "pushup";
  const skin = "var(--c-figure-skin)";
  const suit = "var(--c-figure)";
  const suit2 = "var(--c-figure-dark)";

  return (
    <div
      data-m={motion}
      role="img"
      aria-label={`${label} hareket animasyonu`}
      style={{ width: size, height: size }}
      className={cn("ex-anim relative grid place-items-center overflow-hidden rounded-2xl bg-gradient-to-b from-[var(--c-figure-bg1)] to-[var(--c-figure-bg2)]", className)}
    >
      {/* zemin */}
      <svg viewBox="0 0 220 220" width="100%" height="100%" className="overflow-visible">
        <ellipse cx="110" cy="200" rx="64" ry="7" fill="var(--c-figure-shadow)" />
        <g transform={horizontal ? "translate(0,-18) rotate(-90 110 128)" : undefined}>
          {/* ekipman: barbell / dumbbell */}
          {(motion === "press" || motion === "pull" || motion === "curl" || motion === "hinge") && (
            <g className="gear" />
          )}
          <g className="root">
            {/* arka bacak */}
            <g className="lg-r" style={{ transformOrigin: "116px 128px" }}>
              <path d="M116 128 L122 162 L122 192" stroke={suit2} strokeWidth="15" strokeLinecap="round" fill="none" />
              <path d="M122 162 L122 192" stroke={skin} strokeWidth="11" strokeLinecap="round" fill="none" />
              <path d="M114 192 L134 192" stroke="var(--c-figure-shoe)" strokeWidth="9" strokeLinecap="round" />
            </g>
            {/* ön bacak */}
            <g className="lg-l" style={{ transformOrigin: "104px 128px" }}>
              <path d="M104 128 L98 162 L98 192" stroke={suit} strokeWidth="15" strokeLinecap="round" fill="none" />
              <path d="M98 162 L98 192" stroke={skin} strokeWidth="11" strokeLinecap="round" fill="none" />
              <path d="M86 192 L106 192" stroke="var(--c-figure-shoe)" strokeWidth="9" strokeLinecap="round" />
            </g>
            {/* gövde */}
            <g className="tor" style={{ transformOrigin: "110px 128px" }}>
              <path d="M110 70 L110 128" stroke={suit} strokeWidth="26" strokeLinecap="round" />
              <path d="M110 68 L110 96" stroke={suit2} strokeWidth="26" strokeLinecap="round" opacity="0.45" />
              {/* boyun + baş */}
              <path d="M110 52 L110 62" stroke={skin} strokeWidth="9" strokeLinecap="round" />
              <circle cx="110" cy="38" r="15" fill={skin} />
              <path d="M96 34 Q110 20 124 34" stroke="var(--c-figure-hair)" strokeWidth="8" strokeLinecap="round" fill="none" />
              {/* arka kol */}
              <g className="up-r" style={{ transformOrigin: "122px 76px" }}>
                <path d="M122 76 L134 104" stroke={skin} strokeWidth="11" strokeLinecap="round" />
                <g className="fo-r" style={{ transformOrigin: "134px 104px" }}>
                  <path d="M134 104 L138 130" stroke={skin} strokeWidth="11" strokeLinecap="round" />
                  <circle cx="139" cy="134" r="6" fill={skin} />
                  {(motion === "press" || motion === "curl" || motion === "raise") && (
                    <g className="dumb">
                      <rect x="129" y="127" width="20" height="8" rx="3" fill="var(--c-figure-iron)" />
                      <rect x="126" y="123" width="7" height="16" rx="2" fill="var(--c-figure-iron)" />
                      <rect x="145" y="123" width="7" height="16" rx="2" fill="var(--c-figure-iron)" />
                    </g>
                  )}
                </g>
              </g>
              {/* ön kol */}
              <g className="up-l" style={{ transformOrigin: "98px 76px" }}>
                <path d="M98 76 L86 104" stroke={skin} strokeWidth="11" strokeLinecap="round" />
                <g className="fo-l" style={{ transformOrigin: "86px 104px" }}>
                  <path d="M86 104 L82 130" stroke={skin} strokeWidth="11" strokeLinecap="round" />
                  <circle cx="81" cy="134" r="6" fill={skin} />
                  {(motion === "press" || motion === "curl" || motion === "raise") && (
                    <g className="dumb">
                      <rect x="71" y="127" width="20" height="8" rx="3" fill="var(--c-figure-iron)" />
                      <rect x="68" y="123" width="7" height="16" rx="2" fill="var(--c-figure-iron)" />
                      <rect x="87" y="123" width="7" height="16" rx="2" fill="var(--c-figure-iron)" />
                    </g>
                  )}
                </g>
              </g>
            </g>
          </g>
        </g>
      </svg>
    </div>
  );
}

/** Egzersiz seçilince açılan detay paneli: animasyon, açıklama, adımlar, ipucu */
export function ExerciseSheet({ name, onClose }: { name: string | null; onClose: () => void }) {
  const ex = name ? getExercise(name) : null;
  return (
    <Sheet open={!!ex} onClose={onClose} title={ex?.name ?? ""} subtitle={ex ? `${ex.group} • ${ex.equipment}` : undefined}>
      {ex && (
        <div className="space-y-4">
          <div className="flex justify-center">
            <ExerciseAnimation motion={ex.motion} label={ex.name} size={230} gif={ex.gif} />
          </div>
          <div className="flex flex-wrap gap-1.5">
            <Chip active>{ex.group}</Chip>
            <Chip>{ex.equipment}</Chip>
            {ex.level && <Chip>{ex.level === "baslangic" ? "Başlangıç" : ex.level === "orta" ? "Orta" : "İleri"}</Chip>}
            {ex.minutes && <Chip>≈ {ex.minutes} dk</Chip>}
            {ex.kcal && <Chip>≈ {ex.kcal} kcal</Chip>}
          </div>
          <div>
            <p className="mb-2 text-[11.5px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Nasıl yapılır</p>
            <ol className="space-y-2">
              {ex.how.map((step, i) => (
                <li key={i} className="flex gap-3 rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] p-3">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[var(--c-acc)] text-[12px] font-extrabold text-white dark:text-[#04110a]">{i + 1}</span>
                  <span className="text-[13.5px] leading-relaxed text-[var(--c-text2)]">{step}</span>
                </li>
              ))}
            </ol>
          </div>
          <div className="rounded-2xl border border-[var(--c-accline)] bg-[var(--c-tint)] p-3.5">
            <p className="text-[12px] font-extrabold text-[var(--c-acc)]">💡 İpucu</p>
            <p className="mt-1 text-[13px] leading-relaxed text-[var(--c-text2)]">{ex.tip}</p>
          </div>
        </div>
      )}
    </Sheet>
  );
}
