import { useEffect, useMemo, useState } from "react";
import { AlarmClock, BellRing, BellOff, Check, Droplets, Dumbbell, Plus, Ruler, Trash2, Utensils, Volume2, VolumeX, Pencil, Play, ShieldAlert, Info } from "lucide-react";
import type { Reminder, ReminderKind } from "../types";
import { useStore } from "../store/store";
import { useFeedback } from "./Feedback";
import { DAY_SHORT, uid } from "../lib/date";
import { REMINDER_BODIES, nextOccurrence } from "../hooks/useReminders";
import { beep, canVibrate, notificationSupport, requestPermission, systemNotify, unlockAudio, vibrate, type PermState } from "../lib/notify";
import { Card, EmptyState, Field, NeonButton, Sheet } from "./ui";
import { cn } from "../utils/cn";

const KIND_META: Record<ReminderKind, { label: string; icon: typeof Dumbbell; color: string }> = {
  antrenman: { label: "Antrenman", icon: Dumbbell, color: "#00e676" },
  su: { label: "Su", icon: Droplets, color: "#38bdf8" },
  olcum: { label: "Ölçüm", icon: Ruler, color: "#a78bfa" },
  ogun: { label: "Öğün", icon: Utensils, color: "#ffb020" },
  ozel: { label: "Özel", icon: AlarmClock, color: "#f472b6" },
};

function relativeTime(d: Date): string {
  const ms = d.getTime() - Date.now();
  const mins = Math.round(ms / 60000);
  if (mins < 60) return `${mins} dk sonra`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} sa ${mins % 60} dk sonra`;
  const days = Math.floor(hours / 24);
  return `${days} gün sonra`;
}

export default function RemindersPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { state, dispatch, snapshot, undo } = useStore();
  const { toast, muted, setMuted, raiseAlarm } = useFeedback();
  const profile = state.profile!;
  const [perm, setPerm] = useState<PermState>(() => notificationSupport());
  const [editing, setEditing] = useState<Reminder | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [tickNow, setTickNow] = useState(Date.now());

  useEffect(() => {
    if (!open) return;
    setPerm(notificationSupport());
    const id = window.setInterval(() => setTickNow(Date.now()), 30000);
    return () => window.clearInterval(id);
  }, [open]);

  const upcoming = useMemo(() => {
    const items = state.reminders
      .map((r) => ({ r, at: nextOccurrence(r, new Date(tickNow)) }))
      .filter((x): x is { r: Reminder; at: Date } => !!x.at)
      .sort((a, b) => a.at.getTime() - b.at.getTime());
    return items[0] ?? null;
  }, [state.reminders, tickNow]);

  const askPermission = async () => {
    unlockAudio();
    const res = await requestPermission();
    setPerm(res);
    if (res === "granted") {
      toast("Bildirim izni verildi");
      void systemNotify("FitLife bildirimleri açık", "Hatırlatıcılar artık cihazına bildirim gönderebilir.", "fitlife-test");
    } else if (res === "denied") {
      toast("Bildirim izni reddedildi. Uygulama içi alarm kullanılacak.", { tone: "info" });
    } else if (res === "unsupported") {
      toast("Bu cihaz sistem bildirimini desteklemiyor. Uygulama içi alarm çalışır.", { tone: "info" });
    }
  };

  const testReminder = async (r: Reminder) => {
    unlockAudio();
    const delivered = profile.notifications ? await systemNotify(r.title, REMINDER_BODIES[r.kind], `test-${r.id}`) : false;
    if (!delivered) raiseAlarm(r.title, REMINDER_BODIES[r.kind]);
    if (!muted && r.sound) {
      beep(3);
      if (canVibrate()) vibrate();
    }
    toast(delivered ? "Test bildirimi gönderildi" : "Uygulama içi alarm çalındı", { tone: "info" });
  };

  const saveReminder = () => {
    if (!editing) return;
    const next: Record<string, string> = {};
    if (!editing.title.trim()) next.title = "Başlık gerekli.";
    if (!/^\d{2}:\d{2}$/.test(editing.time)) next.time = "Geçerli bir saat seç.";
    if (editing.days.length === 0) next.days = "En az bir gün seç.";
    setErrors(next);
    if (Object.keys(next).length) return;
    const exists = state.reminders.some((r) => r.id === editing.id);
    const clean: Reminder = { ...editing, title: editing.title.trim(), lastFired: undefined };
    dispatch({ type: exists ? "UPDATE_REMINDER" : "ADD_REMINDER", reminder: clean });
    setFormOpen(false);
    setEditing(null);
    toast(exists ? "Hatırlatıcı güncellendi" : "Hatırlatıcı eklendi");
  };

  const removeReminder = (r: Reminder) => {
    snapshot();
    dispatch({ type: "DELETE_REMINDER", id: r.id });
    toast(`"${r.title}" silindi`, { tone: "danger", actionLabel: "Geri Al", onAction: () => undo() });
  };

  const newReminder = () => {
    setEditing({ id: uid(), kind: "antrenman", title: "Antrenman zamanı", time: "18:30", days: [0, 1, 2, 3, 4], enabled: true, sound: true });
    setErrors({});
    setFormOpen(true);
  };

  return (
    <>
      <Sheet open={open} onClose={onClose} title="Hatırlatıcılar & Alarm" subtitle="Uygulama açıkken zamanı gelen hatırlatıcı çalar.">
        {/* izin durumu */}
        <div
          className={cn(
            "rounded-2xl border p-3.5",
            perm === "granted" ? "border-[#00e676]/40 bg-[#00e676]/[0.07]" : perm === "denied" ? "border-[#f87171]/40 bg-[#f87171]/[0.07]" : "border-[#ffb020]/40 bg-[#ffb020]/[0.07]"
          )}
        >
          <div className="flex items-start gap-3">
            <span className={cn("grid h-10 w-10 shrink-0 place-items-center rounded-xl", perm === "granted" ? "bg-[#00e676]/15 text-[var(--c-acc)]" : perm === "denied" ? "bg-[#f87171]/15 text-[var(--c-red)]" : "bg-[#ffb020]/15 text-[var(--c-amber)]")}>
              {perm === "granted" ? <BellRing size={18} /> : perm === "denied" ? <BellOff size={18} /> : <ShieldAlert size={18} />}
            </span>
            <div className="flex-1">
              <p className="text-[13.5px] font-extrabold text-[var(--c-text)]">
                {perm === "granted" ? "Cihaz bildirimleri açık" : perm === "denied" ? "Bildirim izni reddedildi" : perm === "unsupported" ? "Cihaz bildirimi desteklenmiyor" : "Bildirim izni gerekli"}
              </p>
              <p className="mt-0.5 text-[12px] leading-relaxed text-[var(--c-sub)]">
                {perm === "granted"
                  ? "Hatırlatıcılar sistem bildirimi olarak gönderilir; sekme arka plandayken de görünür."
                  : perm === "denied"
                    ? "Tarayıcı ayarlarından izin verebilirsin. Bu sırada uygulama içi alarm ve ses çalışır."
                    : perm === "unsupported"
                      ? "Bu tarayıcıda sistem bildirimi yok. Uygulama açıkken ekran alarmı ve ses devreye girer."
                      : "İzin verirsen hatırlatıcılar telefonunun bildirim paneline düşer."}
              </p>
              {perm !== "granted" && perm !== "unsupported" && (
                <button onClick={askPermission} className="mt-2 rounded-lg bg-[#00e676] px-3 py-2 text-[12px] font-extrabold text-[#04110a] active:scale-95">
                  Bildirim İzni Ver
                </button>
              )}
            </div>
          </div>
        </div>

        {/* genel anahtarlar */}
        <div className="mt-3 grid grid-cols-2 gap-2">
          <button
            onClick={() => dispatch({ type: "PATCH_PROFILE", patch: { reminders: !profile.reminders } })}
            className={cn("flex items-center gap-2 rounded-2xl border p-3 text-left active:scale-[0.98]", profile.reminders ? "border-[#00e676]/40 bg-[#00e676]/[0.07]" : "border-[var(--c-line3)] bg-[var(--c-bg1)]")}
          >
            <AlarmClock size={17} className={profile.reminders ? "text-[var(--c-acc)]" : "text-[var(--c-mute)]"} />
            <span>
              <span className="block text-[12.5px] font-extrabold text-[var(--c-text)]">Hatırlatıcılar</span>
              <span className="block text-[11px] text-[var(--c-mute)]">{profile.reminders ? "Açık" : "Kapalı"}</span>
            </span>
          </button>
          <button
            onClick={() => { setMuted(!muted); if (muted) unlockAudio(); }}
            className={cn("flex items-center gap-2 rounded-2xl border p-3 text-left active:scale-[0.98]", !muted ? "border-[#00e676]/40 bg-[#00e676]/[0.07]" : "border-[var(--c-line3)] bg-[var(--c-bg1)]")}
          >
            {muted ? <VolumeX size={17} className="text-[var(--c-mute)]" /> : <Volume2 size={17} className="text-[var(--c-acc)]" />}
            <span>
              <span className="block text-[12.5px] font-extrabold text-[var(--c-text)]">Alarm sesi</span>
              <span className="block text-[11px] text-[var(--c-mute)]">{muted ? "Sessiz" : "Açık"}</span>
            </span>
          </button>
        </div>

        {upcoming && profile.reminders && (
          <p className="mt-3 flex items-center gap-2 rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg1)] px-3 py-2.5 text-[12px] font-semibold text-[var(--c-sub)]">
            <AlarmClock size={13} className="text-[var(--c-acc)]" />
            Sıradaki: <b className="text-[var(--c-text)]">{upcoming.r.title}</b> • {upcoming.at.toLocaleString("tr-TR", { weekday: "short", hour: "2-digit", minute: "2-digit" })} ({relativeTime(upcoming.at)})
          </p>
        )}

        {/* liste */}
        <div className="mt-4 space-y-2">
          {state.reminders.length === 0 ? (
            <EmptyState icon={<AlarmClock size={20} />} title="Hatırlatıcı yok" desc="Antrenman, su veya ölçüm için hatırlatıcı oluştur." action={<NeonButton onClick={newReminder}>Hatırlatıcı Ekle</NeonButton>} />
          ) : (
            state.reminders.map((r) => {
              const meta = KIND_META[r.kind];
              const Icon = meta.icon;
              const at = nextOccurrence(r, new Date(tickNow));
              return (
                <Card key={r.id} className={cn("p-3.5", !r.enabled && "opacity-60")}>
                  <div className="flex items-center gap-3">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl" style={{ background: `${meta.color}1f`, color: meta.color }}>
                      <Icon size={19} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14px] font-extrabold text-[var(--c-text)]">{r.title}</p>
                      <p className="text-[12px] text-[var(--c-sub)]">
                        <b className="text-[var(--c-text)]">{r.time}</b> • {r.days.length === 7 ? "Her gün" : r.days.map((d) => DAY_SHORT[d]).join(", ")}
                      </p>
                      {r.enabled && at && <p className="text-[11px] font-semibold text-[var(--c-mute)]">{relativeTime(at)}</p>}
                    </div>
                    <button
                      onClick={() => dispatch({ type: "UPDATE_REMINDER", reminder: { ...r, enabled: !r.enabled } })}
                      className={cn("relative h-7 w-12 shrink-0 rounded-full transition-colors", r.enabled ? "bg-[#00e676]" : "bg-[var(--c-line3)]")}
                      aria-label="Hatırlatıcıyı aç/kapat"
                    >
                      <span className={cn("absolute top-1 h-5 w-5 rounded-full bg-white transition-all", r.enabled ? "right-1" : "left-1")} />
                    </button>
                  </div>
                  <div className="mt-2.5 flex gap-2">
                    <button onClick={() => testReminder(r)} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-[var(--c-line3)] bg-[var(--c-bg2)] py-2 text-[12px] font-bold text-[var(--c-text)] active:scale-95">
                      <Play size={12} fill="currentColor" /> Şimdi Dene
                    </button>
                    <button onClick={() => { setEditing(r); setErrors({}); setFormOpen(true); }} className="grid h-9 w-9 place-items-center rounded-lg border border-[var(--c-line3)] bg-[var(--c-bg2)] text-[var(--c-text2)] active:scale-90" aria-label="Düzenle">
                      <Pencil size={14} />
                    </button>
                    <button onClick={() => removeReminder(r)} className="grid h-9 w-9 place-items-center rounded-lg border border-[#f87171]/30 bg-[#f87171]/10 text-[var(--c-red)] active:scale-90" aria-label="Sil">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </Card>
              );
            })
          )}
        </div>

        {state.reminders.length > 0 && (
          <NeonButton onClick={newReminder} className="mt-3 flex w-full items-center justify-center gap-2">
            <Plus size={16} strokeWidth={3} /> Yeni Hatırlatıcı
          </NeonButton>
        )}

        <p className="mt-3 flex gap-2 rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg1)] p-3 text-[11.5px] leading-relaxed text-[var(--c-mute)]">
          <Info size={26} className="shrink-0 text-[var(--c-blue)]" />
          Hatırlatıcılar uygulama açıkken (arka plan sekmesi dahil) çalışır. Uygulama tamamen kapalıyken tarayıcı alarm üretemez; APK sürümünde yerel bildirim servisiyle genişletilebilir.
        </p>
      </Sheet>

      {/* hatırlatıcı formu */}
      <Sheet open={formOpen} onClose={() => setFormOpen(false)} title={state.reminders.some((r) => r.id === editing?.id) ? "Hatırlatıcıyı Düzenle" : "Yeni Hatırlatıcı"} subtitle="Saat ve günleri seç, alarm otomatik kurulsun.">
        {editing && (
          <div className="space-y-3">
            <div>
              <p className="mb-1.5 text-[11.5px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Tür</p>
              <div className="grid grid-cols-5 gap-1.5">
                {(Object.keys(KIND_META) as ReminderKind[]).map((k) => {
                  const meta = KIND_META[k];
                  const Icon = meta.icon;
                  const active = editing.kind === k;
                  return (
                    <button
                      key={k}
                      onClick={() => setEditing({ ...editing, kind: k, title: editing.title || meta.label })}
                      className={cn("flex flex-col items-center gap-1 rounded-xl border py-2.5 active:scale-95", active ? "border-transparent" : "border-[var(--c-line3)] bg-[var(--c-bg1)]")}
                      style={active ? { background: `${meta.color}22`, borderColor: meta.color } : undefined}
                    >
                      <Icon size={16} style={{ color: active ? meta.color : "var(--c-mute)" }} />
                      <span className="text-[10px] font-bold" style={{ color: active ? meta.color : "var(--c-mute)" }}>{meta.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <Field label="Başlık" type="text" value={editing.title} onChange={(v) => setEditing({ ...editing, title: v })} error={errors.title} placeholder="örn. Akşam antrenmanı" />
            <Field label="Saat" type="time" value={editing.time} onChange={(v) => setEditing({ ...editing, time: v })} error={errors.time} />

            <div>
              <p className="mb-1.5 text-[11.5px] font-bold uppercase tracking-wider text-[var(--c-sub)]">Günler</p>
              <div className="grid grid-cols-7 gap-1.5">
                {DAY_SHORT.map((d, i) => {
                  const active = editing.days.includes(i);
                  return (
                    <button
                      key={d}
                      onClick={() => setEditing({ ...editing, days: active ? editing.days.filter((x) => x !== i) : [...editing.days, i].sort() })}
                      className={cn("rounded-xl border py-2.5 text-[11px] font-extrabold active:scale-95", active ? "border-[#00e676] bg-[#00e676] text-[#04110a]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-sub)]")}
                    >
                      {d}
                    </button>
                  );
                })}
              </div>
              <div className="mt-2 flex gap-2">
                <button onClick={() => setEditing({ ...editing, days: [0, 1, 2, 3, 4, 5, 6] })} className="flex-1 rounded-lg border border-[var(--c-line3)] bg-[var(--c-bg1)] py-2 text-[11.5px] font-bold text-[var(--c-text2)] active:scale-95">Her gün</button>
                <button onClick={() => setEditing({ ...editing, days: [0, 1, 2, 3, 4] })} className="flex-1 rounded-lg border border-[var(--c-line3)] bg-[var(--c-bg1)] py-2 text-[11.5px] font-bold text-[var(--c-text2)] active:scale-95">Hafta içi</button>
                <button onClick={() => setEditing({ ...editing, days: [5, 6] })} className="flex-1 rounded-lg border border-[var(--c-line3)] bg-[var(--c-bg1)] py-2 text-[11.5px] font-bold text-[var(--c-text2)] active:scale-95">Hafta sonu</button>
              </div>
              {errors.days && <p className="mt-1.5 text-[11.5px] font-semibold text-[var(--c-red)]">{errors.days}</p>}
            </div>

            <button
              onClick={() => setEditing({ ...editing, sound: !editing.sound })}
              className="flex w-full items-center gap-3 rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg1)] p-3.5 text-left active:scale-[0.99]"
            >
              <span className={cn("grid h-10 w-10 place-items-center rounded-xl", editing.sound ? "bg-[#00e676]/15 text-[var(--c-acc)]" : "bg-[var(--c-text)]/5 text-[var(--c-mute)]")}>
                {editing.sound ? <Volume2 size={18} /> : <VolumeX size={18} />}
              </span>
              <span className="flex-1">
                <span className="block text-[13.5px] font-bold text-[var(--c-text)]">Sesli alarm</span>
                <span className="block text-[12px] text-[var(--c-mute)]">{canVibrate() ? "Bip sesi + titreşim" : "Bip sesi"}</span>
              </span>
              <span className={cn("grid h-6 w-6 place-items-center rounded-full border", editing.sound ? "border-[#00e676] bg-[#00e676] text-[#04110a]" : "border-[var(--c-line4)] text-transparent")}>
                <Check size={14} strokeWidth={3} />
              </span>
            </button>

            <NeonButton onClick={saveReminder} className="w-full">Kaydet</NeonButton>
          </div>
        )}
      </Sheet>
    </>
  );
}
