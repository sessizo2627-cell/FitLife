import { useEffect } from "react";
import { createPortal } from "react-dom";
import type { ReactNode } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { cn } from "../utils/cn";
import { useFeedback } from "./Feedback";

/** açık panellerin sırası — Escape yalnızca en üsttekini kapatır */
const sheetStack: symbol[] = [];

export function Ring({
  size = 92,
  stroke = 9,
  progress, // 0..1
  children,
  track = "var(--c-line2)",
  color = "#00e676",
}: {
  size?: number;
  stroke?: number;
  progress: number;
  children?: ReactNode;
  track?: string;
  color?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const p = Math.min(1, Math.max(0, progress));
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke={track} strokeWidth={stroke} fill="none" />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c * (1 - p) }}
          transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
          style={{ filter: "drop-shadow(0 0 6px rgba(0,230,118,.6))" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

export function SectionTitle({ title, action, subtitle }: { title: string; action?: ReactNode; subtitle?: string }) {
  return (
    <div className="mb-3 flex items-end justify-between px-1">
      <div>
        <h3 className="font-condensed text-[15px] font-semibold uppercase tracking-[0.14em] text-[var(--c-text)]">
          {title}
        </h3>
        {subtitle && <p className="mt-0.5 text-[12px] text-[var(--c-sub)]">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div className={cn("rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)]/90 backdrop-blur", className)}>
      {children}
    </div>
  );
}

export function ProgressBar({ value, className }: { value: number; className?: string }) {
  const v = Math.min(100, Math.max(0, value));
  return (
    <div className={cn("h-2 w-full overflow-hidden rounded-full bg-[var(--c-line2)]", className)}>
      <motion.div
        className="h-full rounded-full bg-gradient-to-r from-[#00b248] to-[#00e676]"
        initial={{ width: 0 }}
        animate={{ width: `${v}%` }}
        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
        style={{ boxShadow: "0 0 12px rgba(0,230,118,.5)" }}
      />
    </div>
  );
}

export function Sheet({
  open,
  onClose,
  title,
  subtitle,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  const { registerOverlay, host } = useFeedback();
  useEffect(() => {
    if (!open) return;
    return registerOverlay();
  }, [open, registerOverlay]);

  useEffect(() => {
    if (!open) return;
    const id = Symbol("sheet");
    sheetStack.push(id);
    const onKey = (e: KeyboardEvent) => {
      // yalnızca en üstteki panel kapanır
      if (e.key === "Escape" && sheetStack[sheetStack.length - 1] === id) onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      const i = sheetStack.indexOf(id);
      if (i >= 0) sheetStack.splice(i, 1);
    };
  }, [open, onClose]);

  if (!host) return null;

  return createPortal(
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="pointer-events-auto absolute inset-0 z-40 bg-black/70 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            className="pointer-events-auto absolute inset-x-0 bottom-0 z-50 app-scroll max-h-[86%] overflow-y-auto rounded-t-[28px] border-t border-[var(--c-line3)] bg-[var(--c-bg1)] p-5 pb-8"
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 260 }}
          >
            <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-[var(--c-line3)]" />
            <div className="mb-4 flex items-start justify-between">
              <div>
                <h3 className="font-condensed text-lg font-semibold uppercase tracking-wider text-[var(--c-text)]">{title}</h3>
                {subtitle && <p className="mt-1 text-[13px] text-[var(--c-sub)]">{subtitle}</p>}
              </div>
              <button
                onClick={onClose}
                className="grid h-9 w-9 place-items-center rounded-full border border-[var(--c-line3)] bg-[var(--c-bg2)] text-[var(--c-sub)] active:scale-95"
                aria-label="Kapat"
              >
                <X size={18} />
              </button>
            </div>
            {children}
          </motion.div>
        </>
      )}
    </AnimatePresence>,
    host
  );
}

export function Chip({ children, active }: { children: ReactNode; active?: boolean }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-semibold",
        active
          ? "border-[#00e676]/50 bg-[#00e676]/10 text-[var(--c-acc)]"
          : "border-[var(--c-line3)] bg-[var(--c-bg2)] text-[var(--c-sub)]"
      )}
    >
      {children}
    </span>
  );
}

export function Field({
  label,
  value,
  onChange,
  suffix,
  type = "number",
  placeholder,
  error,
  min,
  max,
  step,
  inputMode,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  suffix?: string;
  type?: "text" | "number" | "time" | "date";
  placeholder?: string;
  error?: string;
  min?: number;
  max?: number;
  step?: number;
  inputMode?: "decimal" | "numeric" | "text";
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[11.5px] font-bold uppercase tracking-wider text-[var(--c-sub)]">{label}</span>
      <span
        className={cn(
          "flex items-center gap-2 rounded-2xl border bg-[var(--c-bg0)] px-3.5 transition-colors focus-within:border-[#00e676]",
          error ? "border-[#f87171]" : "border-[var(--c-line3)]"
        )}
      >
        <input
          type={type}
          value={value}
          min={min}
          max={max}
          step={step}
          inputMode={inputMode ?? (type === "number" ? "decimal" : undefined)}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-transparent py-3 text-[15px] font-bold text-[var(--c-text)] outline-none placeholder:font-medium placeholder:text-[var(--c-mute2)] [color-scheme:dark]"
        />
        {suffix && <span className="shrink-0 text-[12px] font-semibold text-[var(--c-mute)]">{suffix}</span>}
      </span>
      {error && <span className="mt-1 block text-[11.5px] font-semibold text-[var(--c-red)]">{error}</span>}
    </label>
  );
}

export function Stepper({
  value,
  onChange,
  step = 1,
  min = 0,
  max = 999,
  suffix,
}: {
  value: number;
  onChange: (v: number) => void;
  step?: number;
  min?: number;
  max?: number;
  suffix?: string;
}) {
  const clamp = (v: number) => Math.min(max, Math.max(min, v));
  return (
    <div className="flex items-center gap-2">
      <button
        onClick={() => onChange(clamp(value - step))}
        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg2)] text-xl font-bold text-[var(--c-text)] active:scale-90"
        aria-label="Azalt"
      >
        −
      </button>
      <div className="flex min-w-[74px] flex-1 items-baseline justify-center gap-1 rounded-xl bg-[var(--c-bg0)] py-2">
        <span className="font-display text-2xl text-[var(--c-text)]">{value.toLocaleString("tr-TR")}</span>
        {suffix && <span className="text-[11px] font-semibold text-[var(--c-mute)]">{suffix}</span>}
      </div>
      <button
        onClick={() => onChange(clamp(value + step))}
        className="glow-green grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#00e676] text-xl font-bold text-[#04110a] active:scale-90"
        aria-label="Arttır"
      >
        +
      </button>
    </div>
  );
}

export function EmptyState({ icon, title, desc, action }: { icon: ReactNode; title: string; desc: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-dashed border-[var(--c-line4)] bg-[var(--c-bg1)] px-5 py-8 text-center">
      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#00e676]/10 text-[var(--c-acc)]">{icon}</span>
      <p className="mt-3 text-[14px] font-extrabold text-[var(--c-text)]">{title}</p>
      <p className="mt-1 max-w-[260px] text-[12.5px] leading-relaxed text-[var(--c-mute)]">{desc}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function NeonButton({
  children,
  onClick,
  variant = "primary",
  className,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "dark";
  className?: string;
}) {
  if (variant === "ghost") {
    return (
      <button
        onClick={onClick}
        className={cn(
          "rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg2)] px-4 py-3 text-[14px] font-semibold text-[var(--c-text)] active:scale-[0.98]",
          className
        )}
      >
        {children}
      </button>
    );
  }
  if (variant === "dark") {
    return (
      <button
        onClick={onClick}
        className={cn(
          "rounded-xl bg-[var(--c-text)]/5 px-4 py-3 text-[14px] font-semibold text-[var(--c-sub)] active:scale-[0.98]",
          className
        )}
      >
        {children}
      </button>
    );
  }
  return (
    <motion.button
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className={cn(
        "glow-green rounded-xl bg-gradient-to-b from-[#00e676] to-[#00b248] px-4 py-3 text-[14px] font-extrabold uppercase tracking-wide text-[#04110a]",
        className
      )}
    >
      {children}
    </motion.button>
  );
}
