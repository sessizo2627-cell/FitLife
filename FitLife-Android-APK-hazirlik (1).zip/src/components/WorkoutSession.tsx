import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronLeft, ChevronRight, Pause, Play, RotateCcw, Timer, Volume2, VolumeX, X, Flag } from "lucide-react";
import { useStore } from "../store/store";
import { useFeedback } from "./Feedback";
import { WEEKLY_PLAN } from "../data/fitness";
import { exKey, getDay } from "../lib/calc";
import { dateKey, fmtDuration } from "../lib/date";
import { beep, tick, unlockAudio, vibrate } from "../lib/notify";
import { ProgressBar } from "./ui";
import ExerciseAnimation from "./ExerciseAnimation";
import { getExercise } from "../data/exercises";
import { cn } from "../utils/cn";

export function parseSets(sets: string): number {
  const m = sets.match(/^(\d+)\s*x/i);
  return m ? Math.max(1, parseInt(m[1])) : 1;
}

export function parseRest(rest: string): number {
  const m = rest.match(/(\d+)/);
  return m ? Math.max(10, parseInt(m[1])) : 60;
}

interface Summary {
  title: string;
  minutes: number;
  done: number;
  total: number;
  sets: number;
}

export default function WorkoutSession({ onClose }: { onClose: () => void }) {
  const { state, dispatch, snapshot, undo } = useStore();
  const { toast, muted, setMuted, registerOverlay } = useFeedback();
  const session = state.session;
  const [now, setNow] = useState(Date.now());
  const [confirmExit, setConfirmExit] = useState(false);
  const [markAll, setMarkAll] = useState(true);
  const [summary, setSummary] = useState<Summary | null>(null);
  const restFired = useRef<number | null>(null);

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => registerOverlay(), [registerOverlay]);

  const plan = useMemo(() => {
    if (!session) return null;
    if (session.custom) return { title: session.custom.title, exercises: session.custom.exercises, restDay: false } as (typeof WEEKLY_PLAN)[string][number];
    return WEEKLY_PLAN[session.goalId][session.dayIndex];
  }, [session]);

  const elapsed = session ? session.accumulated + (session.running ? now - session.startedAt : 0) : 0;
  const restLeft = session?.restUntil ? Math.max(0, Math.ceil((session.restUntil - now) / 1000)) : 0;

  useEffect(() => {
    if (!session?.restUntil) return;
    if (restLeft === 0 && restFired.current !== session.restUntil) {
      restFired.current = session.restUntil;
      if (!muted) {
        beep(3, 940);
        vibrate([220, 100, 220]);
      }
      dispatch({ type: "PATCH_SESSION", patch: { restUntil: null } });
      toast("Dinlenme bitti — sıradaki sete hazırsın", { tone: "info" });
    }
  }, [restLeft, session?.restUntil, muted, dispatch, toast]);

  /* --- özet ekranı (oturum kapandıktan sonra da görünür) --- */
  if (summary) {
    return (
      <div className="app-scroll absolute inset-0 z-[75] flex flex-col items-center justify-center overflow-y-auto bg-[var(--c-bg0)] px-6 py-10 text-center">
        <div className="grid-bg pointer-events-none absolute inset-0" />
        <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="glow-green grid h-24 w-24 shrink-0 place-items-center rounded-full bg-[#00e676]">
          <Check size={48} strokeWidth={3} className="text-[#04110a]" />
        </motion.div>
        <h2 className="font-display mt-6 text-4xl leading-tight text-[var(--c-text)]">
          ANTRENMAN<br /><span className="text-[var(--c-acc)]">TAMAMLANDI</span>
        </h2>
        <p className="mt-3 text-[14px] text-[var(--c-sub)]">{summary.title} • {summary.minutes} dakika</p>
        <div className="mt-6 grid w-full max-w-xs grid-cols-3 gap-2">
          {[
            [`${summary.minutes}`, "Dakika"],
            [`${summary.done}/${summary.total}`, "Hareket"],
            [`${summary.sets}`, "Set"],
          ].map(([v, l]) => (
            <div key={l} className="rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] py-3">
              <p className="font-display text-xl text-[var(--c-acc)]">{v}</p>
              <p className="text-[11px] font-semibold text-[var(--c-mute)]">{l}</p>
            </div>
          ))}
        </div>
        <p className="mt-4 text-[12.5px] text-[var(--c-mute)]">Süre ve hareketler günlüğüne kaydedildi.</p>
        <button onClick={onClose} className="glow-green mt-6 w-full max-w-xs rounded-xl bg-[#00e676] py-4 text-[15px] font-extrabold uppercase text-[#04110a] active:scale-95">
          Harika, Devam
        </button>
      </div>
    );
  }

  if (!session || !plan || !state.profile) return null;

  const log = getDay(state, session.date);
  const idx = Math.min(session.currentIndex, plan.exercises.length - 1);
  const current = plan.exercises[idx];
  const targetSets = parseSets(current.sets);
  const doneSets = session.sets[idx] ?? 0;
  const key = exKey(session.goalId, session.dayIndex, idx);
  const isDone = !!log.exercises[key];
  const completedCount = plan.exercises.reduce((s, _e, i) => s + (log.exercises[exKey(session.goalId, session.dayIndex, i)] ? 1 : 0), 0);
  const pct = Math.round((completedCount / plan.exercises.length) * 100);

  const completeSet = () => {
    unlockAudio();
    const next = Math.min(targetSets, doneSets + 1);
    const sets = { ...session.sets, [idx]: next };
    const allSets = next >= targetSets;
    const restSec = parseRest(current.rest);
    dispatch({
      type: "PATCH_SESSION",
      patch: { sets, restUntil: Date.now() + restSec * 1000, restTotal: restSec, currentIndex: allSets && idx < plan.exercises.length - 1 ? idx + 1 : idx },
    });
    if (allSets) {
      dispatch({ type: "TOGGLE_EXERCISE", date: session.date, key, value: true });
      if (!muted) beep(2, 1040);
      toast(`${current.name} tamamlandı`);
    } else if (!muted) {
      tick();
    }
  };

  const toggleExercise = (i: number) => {
    dispatch({ type: "TOGGLE_EXERCISE", date: session.date, key: exKey(session.goalId, session.dayIndex, i) });
  };

  const pauseResume = () => {
    if (session.running) dispatch({ type: "PATCH_SESSION", patch: { running: false, accumulated: elapsed } });
    else {
      unlockAudio();
      dispatch({ type: "PATCH_SESSION", patch: { running: true, startedAt: Date.now() } });
    }
  };

  const finish = () => {
    const seconds = Math.round(elapsed / 1000);
    const doneCount = markAll
      ? plan.exercises.length
      : plan.exercises.reduce((s, _e, i) => s + (log.exercises[exKey(session.goalId, session.dayIndex, i)] ? 1 : 0), 0);
    if (markAll) {
      plan.exercises.forEach((_e, i) => {
        dispatch({ type: "TOGGLE_EXERCISE", date: session.date, key: exKey(session.goalId, session.dayIndex, i), value: true });
      });
    }
    dispatch({ type: "PATCH_DAY", date: session.date, patch: { workoutDone: markAll || doneCount >= plan.exercises.length } });
    setSummary({
      title: plan.title,
      minutes: Math.max(1, Math.round(seconds / 60)),
      done: doneCount,
      total: plan.exercises.length,
      sets: Object.values(session.sets).reduce((a, b) => a + b, 0),
    });
    dispatch({ type: "END_SESSION", seconds, date: session.date });
    if (!muted) beep(4, 760);
    vibrate([300, 120, 300]);
  };

  const discard = () => {
    snapshot();
    dispatch({ type: "END_SESSION", seconds: Math.round(elapsed / 1000), date: session.date });
    onClose();
    toast("Antrenman iptal edildi", { tone: "danger", actionLabel: "Geri Al", onAction: () => undo() });
  };

  return (
    <div className="absolute inset-0 z-[75] flex flex-col bg-[var(--c-bg0)]">
      <div className="flex items-center justify-between border-b border-[var(--c-line)] px-4 py-3">
        <button onClick={() => setConfirmExit(true)} className="grid h-10 w-10 place-items-center rounded-full border border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-text)] active:scale-95" aria-label="Oturumu kapat">
          <X size={18} />
        </button>
        <div className="text-center">
          <p className="text-[10.5px] font-bold uppercase tracking-[0.2em] text-[var(--c-acc)]">Canlı Antrenman</p>
          <p className="text-[13px] font-extrabold text-[var(--c-text)]">{plan.title}</p>
        </div>
        <button
          onClick={() => { setMuted(!muted); if (muted) unlockAudio(); }}
          className={cn("grid h-10 w-10 place-items-center rounded-full border active:scale-95", muted ? "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-mute)]" : "border-[#00e676]/40 bg-[#00e676]/10 text-[var(--c-acc)]")}
          aria-label="Oturum sesini aç/kapat"
        >
          {muted ? <VolumeX size={17} /> : <Volume2 size={17} />}
        </button>
      </div>

      <div className="app-scroll flex-1 overflow-y-auto px-4 pb-4 pt-4">
        <div className="relative overflow-hidden rounded-3xl border border-[#00e676]/25 bg-gradient-to-br from-[var(--c-tint)] to-[var(--c-bg1)] p-5 text-center">
          <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-[var(--c-mute)]">Geçen Süre</p>
          <p className="font-display mt-1 text-[52px] leading-none tabular-nums text-[var(--c-text)]">{fmtDuration(elapsed)}</p>
          <div className="mt-4 flex items-center justify-center">
            <button onClick={pauseResume} className={cn("flex items-center gap-2 rounded-xl px-6 py-3 text-[14px] font-extrabold uppercase active:scale-95", session.running ? "border border-[var(--c-line3)] bg-[var(--c-bg2)] text-[var(--c-text)]" : "glow-green bg-[#00e676] text-[#04110a]")}>
              {session.running ? <><Pause size={17} /> Duraklat</> : <><Play size={17} fill="currentColor" /> Devam Et</>}
            </button>
          </div>
          <div className="mt-4">
            <div className="mb-1.5 flex justify-between text-[11.5px] font-semibold">
              <span className="text-[var(--c-sub)]">{completedCount}/{plan.exercises.length} hareket</span>
              <span className="text-[var(--c-acc)]">%{pct}</span>
            </div>
            <ProgressBar value={pct} />
          </div>
        </div>

        <AnimatePresence>
          {restLeft > 0 && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
              <div className="mt-3 flex items-center gap-4 rounded-2xl border border-[#38bdf8]/30 bg-[#38bdf8]/[0.07] p-4">
                <div className="relative grid h-14 w-14 shrink-0 place-items-center">
                  <svg width="56" height="56" className="-rotate-90">
                    <circle cx="28" cy="28" r="24" stroke="var(--c-line2)" strokeWidth="5" fill="none" />
                    <circle cx="28" cy="28" r="24" stroke="#38bdf8" strokeWidth="5" fill="none" strokeLinecap="round" strokeDasharray={2 * Math.PI * 24} strokeDashoffset={2 * Math.PI * 24 * (1 - restLeft / Math.max(1, session.restTotal))} />
                  </svg>
                  <span className="absolute text-[15px] font-extrabold tabular-nums text-[var(--c-text)]">{restLeft}</span>
                </div>
                <div className="flex-1">
                  <p className="flex items-center gap-1.5 text-[13px] font-extrabold text-[var(--c-text)]"><Timer size={14} className="text-[var(--c-blue)]" /> Dinlenme</p>
                  <p className="text-[12px] text-[var(--c-sub)]">Nefesini düzenle, sıradaki sete hazırlan.</p>
                </div>
                <button onClick={() => dispatch({ type: "PATCH_SESSION", patch: { restUntil: null } })} className="rounded-lg border border-[var(--c-line3)] bg-[var(--c-bg1)] px-3 py-2 text-[12px] font-bold text-[var(--c-text)] active:scale-95">
                  Atla
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mt-3 rounded-3xl border border-[var(--c-line2)] bg-[var(--c-bg1)] p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[var(--c-acc)]">Hareket {idx + 1}/{plan.exercises.length}</p>
              <h3 className="font-condensed mt-1 text-2xl font-semibold uppercase text-[var(--c-text)]">{current.name}</h3>
              <p className="mt-1 text-[12.5px] text-[var(--c-sub)]">Hedef: {current.sets} • Dinlenme {current.rest}</p>
            </div>
            <button
              onClick={() => toggleExercise(idx)}
              className={cn("grid h-11 w-11 shrink-0 place-items-center rounded-2xl border active:scale-90", isDone ? "border-[#00e676] bg-[#00e676] text-[#04110a]" : "border-[var(--c-line4)] text-[var(--c-mute)]")}
              aria-label="Hareketi tamamlandı işaretle"
            >
              <Check size={20} strokeWidth={3} />
            </button>
          </div>

          <div className="mt-4 flex items-center gap-3 rounded-2xl border border-[var(--c-line2)] bg-white p-3">
            <ExerciseAnimation motion={getExercise(current.name).motion} label={current.name} size={96} />
            <div className="min-w-0 flex-1">
              <p className="text-[12px] font-bold text-[var(--c-acc)]">{getExercise(current.name).group}</p>
              <p className="mt-1 text-[12.5px] leading-relaxed text-[var(--c-text2)]">{getExercise(current.name).how[0]}</p>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-center gap-2">
            {Array.from({ length: targetSets }).map((_, i) => (
              <span key={i} className={cn("h-3 flex-1 rounded-full transition-colors", i < doneSets ? "bg-[#00e676] shadow-[0_0_10px_rgba(0,230,118,0.5)]" : "bg-[var(--c-line2)]")} />
            ))}
          </div>
          <p className="mt-2 text-center text-[12px] font-semibold text-[var(--c-sub)]">{doneSets}/{targetSets} set tamamlandı</p>

          <button onClick={completeSet} className="glow-green mt-4 w-full rounded-2xl bg-gradient-to-b from-[#00e676] to-[#00b248] py-4 text-[15px] font-extrabold uppercase tracking-wide text-[#04110a] active:scale-[0.98]">
            Seti Tamamla
          </button>

          <div className="mt-2 grid grid-cols-3 gap-2">
            <button
              onClick={() => dispatch({ type: "PATCH_SESSION", patch: { currentIndex: Math.max(0, idx - 1) } })}
              disabled={idx === 0}
              className="flex items-center justify-center gap-1 rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg2)] py-2.5 text-[12.5px] font-bold text-[var(--c-text)] active:scale-95 disabled:opacity-40"
            >
              <ChevronLeft size={15} /> Önceki
            </button>
            <button
              onClick={() => dispatch({ type: "PATCH_SESSION", patch: { sets: { ...session.sets, [idx]: 0 } } })}
              className="flex items-center justify-center gap-1 rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg2)] py-2.5 text-[12.5px] font-bold text-[var(--c-sub)] active:scale-95"
            >
              <RotateCcw size={14} /> Sıfırla
            </button>
            <button
              onClick={() => dispatch({ type: "PATCH_SESSION", patch: { currentIndex: Math.min(plan.exercises.length - 1, idx + 1) } })}
              disabled={idx === plan.exercises.length - 1}
              className="flex items-center justify-center gap-1 rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg2)] py-2.5 text-[12.5px] font-bold text-[var(--c-text)] active:scale-95 disabled:opacity-40"
            >
              Sonraki <ChevronRight size={15} />
            </button>
          </div>
        </div>

        <div className="mt-3 space-y-1.5">
          {plan.exercises.map((e, i) => {
            const done = !!log.exercises[exKey(session.goalId, session.dayIndex, i)];
            return (
              <div
                key={i}
                className={cn("flex items-center gap-3 rounded-2xl border px-3.5 py-3", i === idx ? "border-[#00e676]/50 bg-[#00e676]/[0.06]" : "border-[var(--c-line)] bg-[var(--c-bg1)]")}
              >
                <button onClick={() => dispatch({ type: "PATCH_SESSION", patch: { currentIndex: i } })} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                  <span className={cn("font-display text-[15px]", done ? "text-[var(--c-acc)]" : "text-[var(--c-mute2)]")}>{String(i + 1).padStart(2, "0")}</span>
                  <span className="min-w-0">
                    <span className={cn("block truncate text-[13.5px] font-bold", done ? "text-[var(--c-sub)] line-through" : "text-[var(--c-text)]")}>{e.name}</span>
                    <span className="text-[11.5px] text-[var(--c-mute)]">{e.sets} • {session.sets[i] ?? 0} set yapıldı</span>
                  </span>
                </button>
                <button
                  onClick={() => toggleExercise(i)}
                  className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-full border active:scale-90", done ? "border-[#00e676] bg-[#00e676] text-[#04110a]" : "border-[var(--c-line4)] text-transparent")}
                  aria-label={`${e.name} tamamlandı`}
                >
                  <Check size={15} strokeWidth={3} />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      <div className="border-t border-[var(--c-line)] bg-[var(--c-bg1)] p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <label className="mb-2 flex items-center gap-2 px-1">
          <input type="checkbox" checked={markAll} onChange={(e) => setMarkAll(e.target.checked)} className="h-4 w-4 accent-[#00e676]" />
          <span className="text-[12px] font-semibold text-[var(--c-sub)]">Tüm hareketleri tamamlandı olarak kaydet</span>
        </label>
        <button onClick={finish} className="glow-green flex w-full items-center justify-center gap-2 rounded-xl bg-[#00e676] py-3.5 text-[14.5px] font-extrabold uppercase tracking-wide text-[#04110a] active:scale-[0.98]">
          <Flag size={17} /> Antrenmanı Bitir
        </button>
      </div>

      <AnimatePresence>
        {confirmExit && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[78] grid place-items-center bg-black/80 p-6 backdrop-blur-sm">
            <div className="w-full max-w-sm rounded-3xl border border-[var(--c-line3)] bg-[var(--c-bg1)] p-5">
              <h3 className="font-condensed text-lg font-semibold uppercase tracking-wide text-[var(--c-text)]">Antrenmandan çıkılsın mı?</h3>
              <p className="mt-2 text-[13px] leading-relaxed text-[var(--c-sub)]">
                Kaydedip çıkarsan süre korunur ve oturuma kaldığın yerden devam edebilirsin.
              </p>
              <div className="mt-4 space-y-2">
                <button
                  onClick={() => {
                    if (session.running) dispatch({ type: "PATCH_SESSION", patch: { running: false, accumulated: elapsed } });
                    onClose();
                    toast("Oturum kaydedildi. Programım'dan devam edebilirsin.", { tone: "info" });
                  }}
                  className="w-full rounded-xl bg-[#00e676] py-3 text-[14px] font-extrabold text-[#04110a] active:scale-95"
                >
                  Kaydet ve Çık
                </button>
                <button onClick={discard} className="w-full rounded-xl border border-[#f87171]/40 bg-[#f87171]/10 py-3 text-[14px] font-bold text-[var(--c-red)] active:scale-95">
                  Oturumu İptal Et
                </button>
                <button onClick={() => setConfirmExit(false)} className="w-full rounded-xl border border-[var(--c-line3)] bg-[var(--c-bg2)] py-3 text-[14px] font-bold text-[var(--c-text)] active:scale-95">
                  Antrenmana Dön
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function useStartSession() {
  const { state, dispatch } = useStore();
  return (dayIndex: number, date = dateKey(), custom?: { title: string; exercises: { name: string; sets: string; rest: string }[] }) => {
    if (!state.profile) return;
    unlockAudio();
    dispatch({
      type: "START_SESSION",
      session: {
        custom,
        date,
        dayIndex,
        goalId: state.profile.goalId,
        startedAt: Date.now(),
        accumulated: 0,
        running: true,
        currentIndex: 0,
        sets: {},
        restUntil: null,
        restTotal: 60,
      },
    });
  };
}
