import { useMemo, useState } from "react";
import { Utensils, CalendarDays, CalendarRange, Flame, Beef, Wheat, Droplet, Plus, Check } from "lucide-react";
import { useStore } from "../store/store";
import { useFeedback } from "./Feedback";
import { nutritionFor, scalePlan } from "../data/nutrition";
import { latestValue, mealKcal, getDay } from "../lib/calc";
import { dateKey, uid } from "../lib/date";
import { getGoal } from "../data/fitness";
import { Sheet, Card, ProgressBar } from "./ui";
import { cn } from "../utils/cn";

type Tab = "gunluk" | "haftalik" | "aylik";

export default function NutritionPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { state, dispatch } = useStore();
  const { toast } = useFeedback();
  const profile = state.profile!;
  const weight = latestValue(state.measurements, "weight") ?? profile.weight;
  const n = useMemo(() => nutritionFor(profile, weight), [profile, weight]);
  const goal = getGoal(profile.goalId);
  const [tab, setTab] = useState<Tab>("gunluk");
  const [dayIdx, setDayIdx] = useState(0);
  const today = dateKey();
  const todayLog = getDay(state, today);
  const eaten = mealKcal(todayLog);

  const plan = useMemo(() => scalePlan(n.days[dayIdx % n.days.length], n.kcal), [n, dayIdx]);
  const planTotal = plan.meals.reduce((s, m) => s + m.kcal, 0);
  const planProtein = plan.meals.reduce((s, m) => s + m.protein, 0);

  const addToLog = (title: string, kcal: number, protein: number) => {
    dispatch({ type: "ADD_MEAL", date: today, meal: { id: uid(), name: title, kcal, protein, time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) } });
    toast(`${title} günlüğe eklendi • ${kcal} kcal`);
  };
  const isLogged = (title: string) => todayLog.meals.some((m) => m.name === title);

  return (
    <Sheet open={open} onClose={onClose} title="Beslenme Önerileri" subtitle={`${goal.title} • ${n.summary}`}>
      {/* makro özeti */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { icon: Flame, v: n.kcal.toLocaleString("tr-TR"), l: "kcal", c: "var(--c-amber)" },
          { icon: Beef, v: `${n.protein} g`, l: "Protein", c: "var(--c-acc)" },
          { icon: Wheat, v: `${n.carbs} g`, l: "Karb.", c: "var(--c-blue)" },
          { icon: Droplet, v: `${n.fat} g`, l: "Yağ", c: "var(--c-violet)" },
        ].map((m) => (
          <div key={m.l} className="rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] p-2.5 text-center">
            <m.icon size={15} className="mx-auto" style={{ color: m.c }} />
            <p className="mt-1 text-[13.5px] font-extrabold text-[var(--c-text)]">{m.v}</p>
            <p className="text-[10px] font-semibold text-[var(--c-mute)]">{m.l}</p>
          </div>
        ))}
      </div>
      <div className="mt-2 rounded-xl bg-[var(--c-bg2)] px-3 py-2">
        <div className="mb-1 flex justify-between text-[11.5px]">
          <span className="text-[var(--c-sub)]">Bugün alınan</span>
          <span className="font-bold text-[var(--c-text)]">{eaten.toLocaleString("tr-TR")} / {n.kcal.toLocaleString("tr-TR")} kcal</span>
        </div>
        <ProgressBar value={(eaten / n.kcal) * 100} className="h-1.5" />
      </div>

      {/* sekmeler */}
      <div className="mt-4 grid grid-cols-3 gap-1 rounded-2xl bg-[var(--c-bg2)] p-1">
        {([["gunluk", "Günlük", Utensils], ["haftalik", "Haftalık", CalendarDays], ["aylik", "Aylık", CalendarRange]] as const).map(([id, label, Icon]) => (
          <button key={id} onClick={() => setTab(id)} className={cn("flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[12.5px] font-bold transition-colors", tab === id ? "bg-[var(--c-bg1)] text-[var(--c-acc)] shadow-sm" : "text-[var(--c-sub)]")}>
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>

      {tab === "gunluk" && (
        <div className="mt-3 space-y-2">
          <div className="flex gap-1.5">
            {n.days.map((d, i) => (
              <button key={d.label} onClick={() => setDayIdx(i)} className={cn("flex-1 rounded-xl border py-2 text-[12px] font-bold", dayIdx === i ? "border-[var(--c-acc)] bg-[var(--c-tint)] text-[var(--c-acc)]" : "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-text2)]")}>
                {d.label}
              </button>
            ))}
          </div>
          <p className="px-1 text-[11.5px] text-[var(--c-sub)]">Toplam ≈ <b className="text-[var(--c-text)]">{planTotal.toLocaleString("tr-TR")} kcal</b> • <b className="text-[var(--c-text)]">{planProtein} g</b> protein — hedefine göre ölçeklendi.</p>
          {plan.meals.map((m) => {
            const logged = isLogged(m.title);
            return (
              <Card key={m.title + m.time} className="p-3.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-[11px] font-bold uppercase tracking-wider text-[var(--c-acc)]">{m.time} • {m.title}</p>
                    <ul className="mt-1.5 space-y-0.5">
                      {m.items.map((it) => (
                        <li key={it} className="text-[13px] leading-snug text-[var(--c-text2)]">• {it}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-[14px] font-extrabold text-[var(--c-text)]">{m.kcal}</p>
                    <p className="text-[10.5px] text-[var(--c-mute)]">kcal • {m.protein} g P</p>
                  </div>
                </div>
                <button
                  onClick={() => !logged && addToLog(m.title, m.kcal, m.protein)}
                  disabled={logged}
                  className={cn("mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-xl py-2 text-[12px] font-bold active:scale-95", logged ? "bg-[var(--c-tint)] text-[var(--c-acc)]" : "border border-[var(--c-line3)] bg-[var(--c-bg2)] text-[var(--c-text)]")}
                >
                  {logged ? <><Check size={13} strokeWidth={3} /> Günlüğe eklendi</> : <><Plus size={13} strokeWidth={3} /> Yedim, günlüğe ekle</>}
                </button>
              </Card>
            );
          })}
        </div>
      )}

      {tab === "haftalik" && (
        <div className="mt-3 space-y-2">
          <p className="px-1 text-[12px] text-[var(--c-sub)]">Haftalık ilkeler — her hafta aynı; takip kolaylığı için kısa tutuldu.</p>
          {n.weekly.map((w, i) => (
            <div key={i} className="flex items-start gap-3 rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] p-3.5">
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[var(--c-acc)] text-[11px] font-extrabold text-white dark:text-[#04110a]">{i + 1}</span>
              <p className="text-[13.5px] leading-relaxed text-[var(--c-text2)]">{w}</p>
            </div>
          ))}
          <div className="rounded-2xl border border-[var(--c-accline)] bg-[var(--c-tint)] p-3.5 text-[12.5px] leading-relaxed text-[var(--c-text2)]">
            Makro dağılımı: <b>%{n.macros.carbPct}</b> karbonhidrat • <b>%{n.macros.proteinPct}</b> protein • <b>%{n.macros.fatPct}</b> yağ
          </div>
        </div>
      )}

      {tab === "aylik" && (
        <div className="mt-3 space-y-2">
          <p className="px-1 text-[12px] text-[var(--c-sub)]">4 haftalık ilerleme planı. Her hafta sonunda ölçüm al ve bir sonraki haftaya geç.</p>
          {n.monthly.map((w, i) => (
            <div key={i} className="relative rounded-2xl border border-[var(--c-line2)] bg-[var(--c-bg1)] p-3.5 pl-12">
              <span className="font-display absolute left-3 top-3 text-2xl text-[var(--c-acc)]">{i + 1}</span>
              <p className="text-[13.5px] leading-relaxed text-[var(--c-text2)]">{w}</p>
            </div>
          ))}
        </div>
      )}

      <p className="mt-4 text-center text-[11px] leading-relaxed text-[var(--c-mute)]">
        Öneriler geneldir; kronik hastalık, gebelik veya özel diyet durumunda bir diyetisyene danış.
      </p>
    </Sheet>
  );
}
