import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Plus, TrendingDown, TrendingUp, Minus, Award, Ruler, Scale, Trash2, Pencil, Search, ArrowUpDown, CalendarDays } from "lucide-react";
import type { Measurement } from "../types";
import { useStore } from "../store/store";
import { useFeedback } from "./Feedback";
import {
  MEASURE_FIELDS,
  type MeasureKey,
  badges,
  firstValue,
  latestValue,
  sortedMeasurements,
  totalActiveMinutes,
  totalWorkouts,
} from "../lib/calc";
import { dateKey, longDate, uid } from "../lib/date";
import { Card, SectionTitle, Sheet, NeonButton, ProgressBar, EmptyState, Field } from "./ui";
import { cn } from "../utils/cn";

type Draft = Record<MeasureKey, string> & { date: string };

const emptyDraft = (weight?: number): Draft => ({
  date: dateKey(),
  weight: weight ? String(weight) : "",
  chest: "",
  waist: "",
  hips: "",
  arm: "",
  thigh: "",
  neck: "",
  bodyFat: "",
});

export default function ProgressScreen() {
  const { state, dispatch, snapshot, undo } = useStore();
  const { toast } = useFeedback();
  const profile = state.profile!;
  const list = state.measurements;

  const [metric, setMetric] = useState<MeasureKey>("weight");
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft>(emptyDraft(profile.weight));
  const [errors, setErrors] = useState<Partial<Record<string, string>>>({});
  const [query, setQuery] = useState("");
  const [newestFirst, setNewestFirst] = useState(true);

  const series = useMemo(() => sortedMeasurements(list, metric).slice(-16), [list, metric]);
  const field = MEASURE_FIELDS.find((f) => f.key === metric)!;
  const last = latestValue(list, "weight") ?? profile.weight;
  const first = firstValue(list, "weight") ?? profile.weight;
  const diff = +(last - first).toFixed(1);
  const toTarget = +(profile.targetWeight - last).toFixed(1);
  const span = Math.abs(profile.targetWeight - first);
  const goalPct = span > 0.05 ? Math.min(100, Math.max(0, Math.round((Math.abs(last - first) / span) * 100))) : 0;

  const W = 320, H = 132, P = 14;
  const values = series.map((m) => m[metric] as number);
  const targetLine = metric === "weight" ? profile.targetWeight : undefined;
  const min = Math.min(...values, targetLine ?? Infinity) - 1;
  const max = Math.max(...values, targetLine ?? -Infinity) + 1;
  const pts = series.map((m, i) => ({
    x: P + (i / Math.max(1, series.length - 1)) * (W - P * 2),
    y: H - P - (((m[metric] as number) - min) / Math.max(0.1, max - min)) * (H - P * 2),
    m,
  }));
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const targetY = targetLine !== undefined ? H - P - ((targetLine - min) / Math.max(0.1, max - min)) * (H - P * 2) : 0;
  const metricDelta = series.length > 1 ? +((series[series.length - 1][metric] as number) - (series[0][metric] as number)).toFixed(1) : 0;

  const history = useMemo(() => {
    const q = query.trim().toLocaleLowerCase("tr-TR");
    const filtered = list.filter((m) => !q || longDate(m.date).toLocaleLowerCase("tr-TR").includes(q) || m.date.includes(q));
    return filtered.sort((a, b) => (newestFirst ? b.date.localeCompare(a.date) : a.date.localeCompare(b.date)));
  }, [list, query, newestFirst]);

  const openNew = () => {
    setEditingId(null);
    setDraft(emptyDraft(last));
    setErrors({});
    setOpen(true);
  };

  const openEdit = (m: Measurement) => {
    setEditingId(m.id);
    const d = emptyDraft();
    d.date = m.date;
    MEASURE_FIELDS.forEach((f) => {
      const v = m[f.key];
      d[f.key] = typeof v === "number" ? String(v) : "";
    });
    setDraft(d);
    setErrors({});
    setOpen(true);
  };

  const save = () => {
    const next: Partial<Record<string, string>> = {};
    if (!draft.date) next.date = "Tarih seç.";
    else if (draft.date > dateKey()) next.date = "Gelecek tarihli ölçüm girilemez.";
    const parsed: Partial<Measurement> = {};
    let count = 0;
    MEASURE_FIELDS.forEach((f) => {
      const raw = draft[f.key].trim().replace(",", ".");
      if (!raw) return;
      const v = Number(raw);
      const limit = f.key === "weight" ? [20, 400] : f.key === "bodyFat" ? [2, 70] : [10, 250];
      if (Number.isNaN(v) || v < limit[0] || v > limit[1]) {
        next[f.key] = `${limit[0]}–${limit[1]} arası olmalı`;
        return;
      }
      parsed[f.key] = +v.toFixed(1);
      count++;
    });
    if (count === 0 && Object.keys(next).length === 0) next.weight = "En az bir ölçü gir.";
    setErrors(next);
    if (Object.keys(next).length) return;

    if (editingId) {
      dispatch({ type: "UPDATE_MEASUREMENT", measurement: { id: editingId, date: draft.date, ...parsed } });
      toast("Ölçüm güncellendi");
    } else {
      dispatch({ type: "ADD_MEASUREMENT", measurement: { id: uid(), date: draft.date, ...parsed } });
      toast(`${count} ölçü kaydedildi • ${longDate(draft.date)}`);
    }
    if (parsed.weight && draft.date === dateKey()) {
      dispatch({ type: "PATCH_PROFILE", patch: { weight: parsed.weight } });
    }
    setOpen(false);
  };

  const remove = (m: Measurement) => {
    snapshot();
    dispatch({ type: "DELETE_MEASUREMENT", id: m.id });
    toast(`${longDate(m.date)} kaydı silindi`, { tone: "danger", actionLabel: "Geri Al", onAction: () => undo() });
  };

  const badgeList = badges(state);

  return (
    <div className="space-y-5 px-4 pb-6 pt-4">
      <div className="flex items-end justify-between px-1">
        <div>
          <h2 className="font-display text-[26px] text-[var(--c-text)]">İLERLEME <span className="text-[var(--c-acc)]">TAKİBİ</span></h2>
          <p className="mt-1 text-[12.5px] text-[var(--c-sub)]">{list.length} ölçüm • {totalWorkouts(state)} antrenman • {totalActiveMinutes(state)} dk</p>
        </div>
        <button onClick={openNew} className="glow-green flex shrink-0 items-center gap-1 rounded-full bg-[#00e676] px-3.5 py-2 text-[12.5px] font-extrabold text-[#04110a] active:scale-95">
          <Plus size={15} strokeWidth={3} /> Ölçüm
        </button>
      </div>

      {/* özet */}
      <div className="grid grid-cols-3 gap-2">
        <Card className="p-3 text-center">
          <Scale size={18} className="mx-auto text-[var(--c-acc)]" />
          <p className="mt-1.5 text-[17px] font-extrabold text-[var(--c-text)]">{last} <span className="text-[11px] font-semibold text-[var(--c-mute)]">kg</span></p>
          <p className="text-[11px] text-[var(--c-sub)]">Güncel</p>
        </Card>
        <Card className="p-3 text-center">
          <span className="mx-auto grid h-[18px] place-items-center">
            {diff === 0 ? <Minus size={18} className="text-[var(--c-sub)]" /> : diff < 0 ? <TrendingDown size={18} className="text-[var(--c-blue)]" /> : <TrendingUp size={18} className="text-[var(--c-amber)]" />}
          </span>
          <p className="mt-1.5 text-[17px] font-extrabold text-[var(--c-text)]">{diff > 0 ? "+" : ""}{diff} <span className="text-[11px] font-semibold text-[var(--c-mute)]">kg</span></p>
          <p className="text-[11px] text-[var(--c-sub)]">Toplam değişim</p>
        </Card>
        <Card className="p-3 text-center">
          <Award size={18} className="mx-auto text-[var(--c-amber)]" />
          <p className="mt-1.5 text-[17px] font-extrabold text-[var(--c-text)]">{Math.abs(toTarget)} <span className="text-[11px] font-semibold text-[var(--c-mute)]">kg</span></p>
          <p className="text-[11px] text-[var(--c-sub)]">Hedefe kaldı</p>
        </Card>
      </div>

      {/* grafik */}
      <div>
        <SectionTitle title="Ölçüm Grafiği" subtitle={`${field.label} • son ${series.length} kayıt`} />
        <div className="no-scrollbar -mx-4 mb-3 flex gap-1.5 overflow-x-auto px-4 pb-1">
          {MEASURE_FIELDS.map((f) => {
            const has = sortedMeasurements(list, f.key).length > 0;
            return (
              <button
                key={f.key}
                onClick={() => setMetric(f.key)}
                disabled={!has}
                className={cn(
                  "shrink-0 rounded-full border px-3 py-1.5 text-[12px] font-bold transition-colors active:scale-95",
                  metric === f.key ? "text-[#04110a]" : has ? "border-[var(--c-line3)] bg-[var(--c-bg1)] text-[var(--c-text2)]" : "border-[var(--c-line)] bg-transparent text-[var(--c-mute2)]"
                )}
                style={metric === f.key ? { background: f.color, borderColor: f.color } : undefined}
              >
                {f.label}
              </button>
            );
          })}
        </div>
        <Card className="p-4">
          {series.length === 0 ? (
            <EmptyState
              icon={<Ruler size={20} />}
              title="Bu ölçü için kayıt yok"
              desc="Ölçüm ekleyerek grafiği oluşturmaya başla."
              action={<NeonButton onClick={openNew}>Ölçüm Ekle</NeonButton>}
            />
          ) : (
            <>
              <svg viewBox={`0 0 ${W} ${H}`} className="w-full overflow-visible">
                <defs>
                  <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={field.color} stopOpacity="0.35" />
                    <stop offset="100%" stopColor={field.color} stopOpacity="0" />
                  </linearGradient>
                </defs>
                {[0.25, 0.5, 0.75].map((f) => (
                  <line key={f} x1={P} x2={W - P} y1={H * f} y2={H * f} stroke="var(--c-line)" strokeWidth="1" />
                ))}
                {targetLine !== undefined && (
                  <>
                    <line x1={P} x2={W - P} y1={targetY} y2={targetY} stroke="#ffb020" strokeWidth="1.5" strokeDasharray="5 4" />
                    <text x={W - P} y={targetY - 5} textAnchor="end" fontSize="9" fill="#ffb020" fontWeight="700">Hedef {targetLine} kg</text>
                  </>
                )}
                {pts.length > 1 && <path d={`${path} L${pts[pts.length - 1].x},${H - P} L${pts[0].x},${H - P} Z`} fill="url(#areaGrad)" />}
                {pts.length > 1 && (
                  <motion.path
                    key={metric}
                    d={path}
                    fill="none"
                    stroke={field.color}
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 1 }}
                    style={{ filter: `drop-shadow(0 0 6px ${field.color}88)` }}
                  />
                )}
                {pts.map((p, i) => (
                  <g key={p.m.id}>
                    <circle cx={p.x} cy={p.y} r={i === pts.length - 1 ? 5 : 3.5} fill={i === pts.length - 1 ? field.color : "var(--c-bg1)"} stroke={field.color} strokeWidth="2" />
                    {i === pts.length - 1 && (
                      <text x={Math.min(W - 24, p.x)} y={p.y - 10} textAnchor="middle" fontSize="10" fill="#fff" fontWeight="800">
                        {p.m[metric]} {field.unit}
                      </text>
                    )}
                  </g>
                ))}
              </svg>
              <div className="mt-2 flex justify-between text-[10.5px] font-semibold text-[var(--c-mute)]">
                <span>{longDate(series[0].date)}</span>
                <span>{longDate(series[series.length - 1].date)}</span>
              </div>
              <div className="mt-3 flex items-center justify-between border-t border-[var(--c-line)] pt-3 text-[12px]">
                <span className="text-[var(--c-sub)]">
                  {field.label} değişimi:{" "}
                  <b style={{ color: metricDelta === 0 ? "var(--c-sub)" : field.color }}>
                    {metricDelta > 0 ? "+" : ""}{metricDelta} {field.unit}
                  </b>
                </span>
                {metric === "weight" && <span className="font-bold text-[var(--c-text)]">Hedefe %{goalPct}</span>}
              </div>
              {metric === "weight" && <ProgressBar value={goalPct} className="mt-2" />}
            </>
          )}
        </Card>
      </div>

      {/* güncel ölçüler */}
      <div>
        <SectionTitle title="Vücut Ölçüleri" subtitle="Son kaydedilen değerler" />
        <div className="grid grid-cols-2 gap-2">
          {MEASURE_FIELDS.filter((f) => f.key !== "weight").map((f) => {
            const v = latestValue(list, f.key);
            const fv = firstValue(list, f.key);
            const delta = v !== undefined && fv !== undefined ? +(v - fv).toFixed(1) : undefined;
            return (
              <button key={f.key} onClick={openNew} className="text-left active:scale-[0.99]">
                <Card className="flex h-full items-center gap-3 p-3.5">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl" style={{ background: `${f.color}1f`, color: f.color }}>
                    <Ruler size={17} />
                  </span>
                  <div className="min-w-0">
                    <p className="text-[11px] font-semibold text-[var(--c-mute)]">{f.label}</p>
                    <p className="text-[14px] font-extrabold text-[var(--c-text)]">{v !== undefined ? `${v} ${f.unit}` : "—"}</p>
                    {delta !== undefined && delta !== 0 && (
                      <p className="text-[10.5px] font-bold" style={{ color: f.color }}>{delta > 0 ? "+" : ""}{delta} {f.unit}</p>
                    )}
                  </div>
                </Card>
              </button>
            );
          })}
        </div>
      </div>

      {/* geçmiş */}
      <div>
        <SectionTitle
          title="Ölçüm Geçmişi"
          subtitle={`${history.length} kayıt`}
          action={
            <button onClick={() => setNewestFirst((v) => !v)} className="flex items-center gap-1 text-[12px] font-bold text-[var(--c-acc)]">
              <ArrowUpDown size={13} /> {newestFirst ? "Yeni → Eski" : "Eski → Yeni"}
            </button>
          }
        />
        <div className="mb-2 flex items-center gap-2 rounded-2xl border border-[var(--c-line3)] bg-[var(--c-bg1)] px-3.5">
          <Search size={16} className="text-[var(--c-mute)]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Tarih ara (örn. Mart veya 2026-03)"
            className="w-full bg-transparent py-3 text-[13.5px] font-semibold text-[var(--c-text)] outline-none placeholder:font-medium placeholder:text-[var(--c-mute2)]"
          />
          {query && <button onClick={() => setQuery("")} className="text-[12px] font-bold text-[var(--c-mute)]">Temizle</button>}
        </div>

        {history.length === 0 ? (
          <EmptyState
            icon={<CalendarDays size={20} />}
            title={query ? "Sonuç bulunamadı" : "Henüz ölçüm yok"}
            desc={query ? "Farklı bir tarih aramayı dene." : "Kilonu ve vücut ölçülerini ekleyerek değişimini takip et."}
            action={!query ? <NeonButton onClick={openNew}>İlk Ölçümü Ekle</NeonButton> : undefined}
          />
        ) : (
          <Card className="divide-y divide-[var(--c-line)]">
            {history.map((m) => {
              const extras = MEASURE_FIELDS.filter((f) => f.key !== "weight" && typeof m[f.key] === "number");
              return (
                <div key={m.id} className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[#00e676]/10 text-[var(--c-acc)]"><Scale size={16} /></span>
                    <div className="min-w-0 flex-1">
                      <p className="text-[14px] font-extrabold text-[var(--c-text)]">{m.weight ? `${m.weight} kg` : "Vücut ölçümü"}</p>
                      <p className="truncate text-[11.5px] text-[var(--c-mute)]">{longDate(m.date)}</p>
                    </div>
                    <button onClick={() => openEdit(m)} className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-[var(--c-line3)] bg-[var(--c-bg2)] text-[var(--c-text2)] active:scale-90" aria-label="Düzenle">
                      <Pencil size={14} />
                    </button>
                    <button onClick={() => remove(m)} className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-[#f87171]/30 bg-[#f87171]/10 text-[var(--c-red)] active:scale-90" aria-label="Sil">
                      <Trash2 size={14} />
                    </button>
                  </div>
                  {extras.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5 pl-12">
                      {extras.map((f) => (
                        <span key={f.key} className="rounded-full px-2 py-0.5 text-[10.5px] font-bold" style={{ background: `${f.color}1a`, color: f.color }}>
                          {f.label} {m[f.key]}{f.unit}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </Card>
        )}
      </div>

      {/* rozetler */}
      <div>
        <SectionTitle title="Rozetler" subtitle="Gerçek verilerinden hesaplanır" />
        <div className="grid grid-cols-2 gap-2">
          {badgeList.map((a, i) => (
            <Card key={i} className={cn("p-4", !a.done && "opacity-70")}>
              <p className="text-2xl">{a.icon}</p>
              <p className="mt-1.5 text-[13px] font-extrabold text-[var(--c-text)]">{a.title}</p>
              <p className="text-[11px] text-[var(--c-mute)]">{a.desc}</p>
              <ProgressBar value={a.progress * 100} className="mt-2 h-1.5" />
              <p className={cn("mt-1.5 text-[11px] font-bold", a.done ? "text-[var(--c-acc)]" : "text-[var(--c-mute)]")}>{a.done ? "✓ Kazanıldı" : "Devam ediyor"}</p>
            </Card>
          ))}
        </div>
      </div>

      {/* ölçüm formu */}
      <Sheet
        open={open}
        onClose={() => setOpen(false)}
        title={editingId ? "Ölçümü Düzenle" : "Yeni Ölçüm"}
        subtitle="Sadece bildiğin alanları doldur; en az bir değer yeterli."
      >
        <Field label="Tarih" type="date" value={draft.date} onChange={(v) => setDraft({ ...draft, date: v })} error={errors.date} max={undefined} />
        <div className="mt-3 grid grid-cols-2 gap-2.5">
          {MEASURE_FIELDS.map((f) => (
            <Field
              key={f.key}
              label={f.label}
              value={draft[f.key]}
              onChange={(v) => setDraft({ ...draft, [f.key]: v })}
              suffix={f.unit}
              error={errors[f.key]}
              placeholder="—"
            />
          ))}
        </div>
        <NeonButton onClick={save} className="mt-4 w-full">{editingId ? "Değişiklikleri Kaydet" : "Ölçümü Kaydet"}</NeonButton>
        <p className="mt-2 text-center text-[11px] text-[var(--c-mute)]">Sabah aç karnına ölçüm alman en tutarlı sonucu verir.</p>
      </Sheet>
    </div>
  );
}
