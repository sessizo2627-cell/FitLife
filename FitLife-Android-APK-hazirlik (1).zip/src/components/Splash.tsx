import { motion } from "framer-motion";
import { Dumbbell } from "lucide-react";

export default function Splash() {
  return (
    <div className="grid-bg relative flex h-full min-h-[100dvh] flex-col items-center justify-center overflow-hidden bg-[var(--c-bg0)]">
      <div className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-[#00e676]/15 blur-[100px]" />
      <motion.div
        initial={{ scale: 0.7, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="glow-green grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-b from-[#00e676] to-[#00b248]"
      >
        <Dumbbell size={38} strokeWidth={2.4} className="text-[#04110a]" />
      </motion.div>
      <motion.h1
        initial={{ y: 16, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="font-display mt-5 text-5xl tracking-wide text-[var(--c-text)]"
      >
        FIT<span className="text-[var(--c-acc)]">LIFE</span>
      </motion.h1>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mt-2 text-[12px] font-semibold uppercase tracking-[0.3em] text-[var(--c-mute)]"
      >
        Gücünü İnşa Et
      </motion.p>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-10 flex items-center gap-2"
      >
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="h-2 w-2 rounded-full bg-[#00e676]"
            animate={{ opacity: [0.2, 1, 0.2], scale: [0.8, 1.2, 0.8] }}
            transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
          />
        ))}
      </motion.div>
      <p className="absolute bottom-8 text-[11px] font-medium text-[var(--c-mute2)]">v1.0 • Türkçe • Android Uyumlu</p>
    </div>
  );
}
