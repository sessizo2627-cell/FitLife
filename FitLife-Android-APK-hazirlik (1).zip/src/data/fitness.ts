import type { Goal } from "../types";

export const HERO_IMAGE =
  "https://images.pexels.com/photos/38453225/pexels-photo-38453225.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800";
export const DUMBBELL_IMAGE =
  "https://images.pexels.com/photos/16080056/pexels-photo-16080056.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800";
export const LIFT_IMAGE =
  "https://images.pexels.com/photos/31267848/pexels-photo-31267848.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800";
export const PRESS_IMAGE =
  "https://images.pexels.com/photos/11433059/pexels-photo-11433059.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800";

export const GOALS: Goal[] = [
  {
    id: "kilo-verme",
    title: "Kilo Verme",
    short: "Yağ Yak",
    desc: "Kalori açığı + kardiyo ağırlıklı programla yağ oranını düşür.",
    detail:
      "Kilo verme programı; yüksek tempolu antrenmanlar, HIIT ve yürüyüş odaklı kardiyo ile desteklenir. Beslenmede sürdürülebilir kalori açığı hedeflenir.",
    icon: "flame",
    tag: "Definasyon",
    weeklyFocus: ["3x Kuvvet", "3x Kardiyo", "1x Aktif Dinlenme"],
    calories: "1.800 – 2.100 kcal",
    protein: "2 g/kg protein",
    cardioNote: "Haftada 150 dk orta tempo kardiyo",
    image: PRESS_IMAGE,
  },
  {
    id: "kilo-alma",
    title: "Kilo Alma",
    short: "Hacim Kazan",
    desc: "Kalori fazlası + temel bileşik hareketlerle sağlıklı kilo al.",
    detail:
      "Temiz hacim (lean bulk) yaklaşımıyla kas kütlesi artırılırken yağlanmayı minimumda tutan kademeli kalori fazlası uygulanır.",
    icon: "trending-up",
    tag: "Hacim",
    weeklyFocus: ["4x Kuvvet", "1x Kardiyo", "2x Dinlenme"],
    calories: "2.800 – 3.200 kcal",
    protein: "1,8 g/kg protein",
    cardioNote: "Haftada 60 dk düşük tempo yürüyüş",
    image: LIFT_IMAGE,
  },
  {
    id: "kas-gelistirme",
    title: "Kas Geliştirme",
    short: "Kas Yap",
    desc: "Progresif yüklenme ile güç ve kas kütlesini maksimuma çıkar.",
    detail:
      "Hipertrofi odaklı split program; set sayısı, tekrar aralığı ve dinlenme süreleri kas gelişimini optimize edecek şekilde planlanır.",
    icon: "dumbbell",
    tag: "Hipertrofi",
    weeklyFocus: ["5x Split Kuvvet", "1x Kardiyo", "1x Dinlenme"],
    calories: "2.600 – 3.000 kcal",
    protein: "2,2 g/kg protein",
    cardioNote: "Haftada 2x 20 dk eğimli yürüyüş",
    image: HERO_IMAGE,
  },
  {
    id: "form-koruma",
    title: "Form Koruma",
    short: "Formda Kal",
    desc: "Mevcut formunu koru; güç, kondisyon ve esnekliği dengede tut.",
    detail:
      "Dengeli full-body ve üst/alt split karışımı program. Amaç; kası korumak, kondisyonu yüksek tutmak ve sakatlıktan uzak kalmak.",
    icon: "shield",
    tag: "Bakım",
    weeklyFocus: ["3x Full-Body", "2x Kardiyo", "2x Esneklik"],
    calories: "2.300 – 2.600 kcal",
    protein: "1,6 g/kg protein",
    cardioNote: "Haftada 90 dk karma kardiyo",
    image: DUMBBELL_IMAGE,
  },
];

export const DURATIONS = [7, 30, 60, 100, 180];

export const QUOTES = [
  { text: "Disiplin, motivasyondan daha güçlüdür.", author: "FitLife Felsefesi" },
  { text: "Bugünkü ter, yarının gücüdür.", author: "Antrenman Günü" },
  { text: "Vücut hedefe değil, alışkanlığa sadık kalır.", author: "FitLife Felsefesi" },
  { text: "En zor tekrar, başlamadığın tekrardır.", author: "Salon Duvarı" },
  { text: "Yavaş ilerleme, hiç ilerlememekten iyidir.", author: "FitLife Felsefesi" },
];

export interface WorkoutDay {
  day: string;
  short: string;
  title: string;
  focus: string;
  duration: string;
  level: string;
  exercises: { name: string; sets: string; rest: string }[];
  restDay?: boolean;
}

export const WEEKLY_PLAN: Record<string, WorkoutDay[]> = {
  "kilo-verme": [
    { day: "Pazartesi", short: "Pzt", title: "Üst Vücut + HIIT", focus: "İtme / Çekme", duration: "50 dk", level: "Orta", exercises: [{ name: "Şınav", sets: "4 x 12", rest: "45 sn" }, { name: "Dumbbell Sırt Çekişi", sets: "4 x 12", rest: "45 sn" }, { name: "Omuz Presi", sets: "3 x 12", rest: "60 sn" }, { name: "HIIT Bisiklet", sets: "8 x 30 sn", rest: "30 sn" }] },
    { day: "Salı", short: "Sal", title: "Kardiyo & Karın", focus: "Yağ Yakımı", duration: "40 dk", level: "Orta", exercises: [{ name: "Eğimli Yürüyüş", sets: "25 dk", rest: "-" }, { name: "Plank (Tahta)", sets: "4 x 45 sn", rest: "30 sn" }, { name: "Rus Burgusu", sets: "3 x 20", rest: "30 sn" }, { name: "Dağ Tırmanışı", sets: "4 x 40 sn", rest: "30 sn" }] },
    { day: "Çarşamba", short: "Çar", title: "Alt Vücut Güç", focus: "Bacak / Kalça", duration: "55 dk", level: "Orta", exercises: [{ name: "Squat (Çömelme)", sets: "4 x 12", rest: "60 sn" }, { name: "Romanya Ölü Çekişi", sets: "4 x 10", rest: "60 sn" }, { name: "İleri Adım (Lunge)", sets: "3 x 12", rest: "45 sn" }, { name: "Baldır Kaldırma", sets: "3 x 15", rest: "30 sn" }] },
    { day: "Perşembe", short: "Per", title: "Aktif Dinlenme", focus: "Yürüyüş + Esneme", duration: "30 dk", level: "Hafif", exercises: [{ name: "Doğa Yürüyüşü", sets: "30 dk", rest: "-" }, { name: "Tüm Vücut Esnetme", sets: "10 dk", rest: "-" }], restDay: true },
    { day: "Cuma", short: "Cum", title: "Full-Body Devre", focus: "Tüm Vücut", duration: "45 dk", level: "Yüksek", exercises: [{ name: "Goblet Çömelme", sets: "4 x 15", rest: "30 sn" }, { name: "İtme Presi", sets: "4 x 10", rest: "45 sn" }, { name: "Lat Çekiş (Makine)", sets: "3 x 12", rest: "45 sn" }, { name: "Burpee", sets: "3 x 10", rest: "60 sn" }] },
    { day: "Cumartesi", short: "Cmt", title: "Uzun Kardiyo", focus: "Dayanıklılık", duration: "60 dk", level: "Orta", exercises: [{ name: "Koşu / Bisiklet", sets: "40 dk", rest: "-" }, { name: "Kettlebell Savurma", sets: "4 x 15", rest: "45 sn" }, { name: "Yan Plank", sets: "3 x 30 sn", rest: "30 sn" }] },
    { day: "Pazar", short: "Paz", title: "Tam Dinlenme", focus: "Toparlanma", duration: "-", level: "-", exercises: [{ name: "Uyku + Beslenme", sets: "-", rest: "-" }], restDay: true },
  ],
  "kilo-alma": [
    { day: "Pazartesi", short: "Pzt", title: "Göğüs + Triceps", focus: "İtme", duration: "60 dk", level: "Orta", exercises: [{ name: "Bench Press (Göğüs Presi)", sets: "4 x 8-10", rest: "90 sn" }, { name: "Eğimli Dumbbell Press", sets: "4 x 10", rest: "90 sn" }, { name: "Kablo Kelebek", sets: "3 x 12", rest: "60 sn" }, { name: "Triseps İtiş (Kablo)", sets: "3 x 12", rest: "60 sn" }] },
    { day: "Salı", short: "Sal", title: "Sırt + Biceps", focus: "Çekme", duration: "60 dk", level: "Orta", exercises: [{ name: "Barfiks / Lat Çekiş", sets: "4 x 8", rest: "90 sn" }, { name: "Barbell Sırt Çekişi", sets: "4 x 10", rest: "90 sn" }, { name: "Oturarak Kablo Çekiş", sets: "3 x 12", rest: "60 sn" }, { name: "Barbell Biceps Curl", sets: "3 x 12", rest: "60 sn" }] },
    { day: "Çarşamba", short: "Çar", title: "Dinlenme", focus: "Toparlanma", duration: "-", level: "-", exercises: [{ name: "Hafif Yürüyüş", sets: "20 dk", rest: "-" }], restDay: true },
    { day: "Perşembe", short: "Per", title: "Omuz + Karın", focus: "Omuz", duration: "55 dk", level: "Orta", exercises: [{ name: "Askeri Press (Ayakta)", sets: "4 x 10", rest: "90 sn" }, { name: "Yana Kaldırma", sets: "4 x 14", rest: "60 sn" }, { name: "Yüz Çekişi (Face Pull)", sets: "3 x 15", rest: "60 sn" }, { name: "Asılı Bacak Kaldırma", sets: "3 x 12", rest: "60 sn" }] },
    { day: "Cuma", short: "Cum", title: "Bacak Güç", focus: "Bacak", duration: "65 dk", level: "Yüksek", exercises: [{ name: "Arka Squat", sets: "5 x 6-8", rest: "120 sn" }, { name: "Bacak Presi", sets: "4 x 12", rest: "90 sn" }, { name: "Bacak Kıvırma", sets: "3 x 12", rest: "60 sn" }, { name: "Ayakta Baldır", sets: "4 x 15", rest: "45 sn" }] },
    { day: "Cumartesi", short: "Cmt", title: "Kollar + Kardiyo", focus: "Kol / Kondisyon", duration: "45 dk", level: "Orta", exercises: [{ name: "Eğimli Dumbbell Curl", sets: "3 x 12", rest: "60 sn" }, { name: "Başın Üstü Triseps", sets: "3 x 12", rest: "60 sn" }, { name: "Çekiç Curl", sets: "3 x 12", rest: "60 sn" }, { name: "Eğimli Yürüyüş", sets: "20 dk", rest: "-" }] },
    { day: "Pazar", short: "Paz", title: "Tam Dinlenme", focus: "Toparlanma", duration: "-", level: "-", exercises: [{ name: "Uyku + Beslenme", sets: "-", rest: "-" }], restDay: true },
  ],
  "kas-gelistirme": [
    { day: "Pazartesi", short: "Pzt", title: "Göğüs (Ağır)", focus: "Göğüs", duration: "65 dk", level: "Yüksek", exercises: [{ name: "Bench Press (Göğüs Presi)", sets: "5 x 5", rest: "150 sn" }, { name: "Eğimli Barbell Press", sets: "4 x 8", rest: "120 sn" }, { name: "Paralel Bar Dips", sets: "3 x 10", rest: "90 sn" }, { name: "Pec Deck (Kelebek)", sets: "3 x 14", rest: "60 sn" }] },
    { day: "Salı", short: "Sal", title: "Sırt (Genişlik)", focus: "Sırt", duration: "65 dk", level: "Yüksek", exercises: [{ name: "Deadlift (Ölü Çekiş)", sets: "5 x 5", rest: "150 sn" }, { name: "Barfiks", sets: "4 x Max", rest: "120 sn" }, { name: "T-Bar Sırt Çekişi", sets: "4 x 10", rest: "90 sn" }, { name: "Düz Kol Çekiş", sets: "3 x 14", rest: "60 sn" }] },
    { day: "Çarşamba", short: "Çar", title: "Omuz + Trapez", focus: "Omuz", duration: "55 dk", level: "Orta", exercises: [{ name: "Askeri Press", sets: "4 x 8", rest: "120 sn" }, { name: "Arnold Press", sets: "3 x 10", rest: "90 sn" }, { name: "Kablo Yana Kaldırma", sets: "4 x 15", rest: "60 sn" }, { name: "Shrug (Omuz Silkme)", sets: "4 x 15", rest: "60 sn" }] },
    { day: "Perşembe", short: "Per", title: "Bacak (Quad)", focus: "Bacak", duration: "70 dk", level: "Yüksek", exercises: [{ name: "Squat (Çömelme)", sets: "5 x 6", rest: "150 sn" }, { name: "Hack Squat", sets: "4 x 10", rest: "120 sn" }, { name: "Bacak Açma", sets: "4 x 14", rest: "60 sn" }, { name: "Adduktör Makinesi", sets: "3 x 15", rest: "60 sn" }] },
    { day: "Cuma", short: "Cum", title: "Kol Günü", focus: "Kol", duration: "50 dk", level: "Orta", exercises: [{ name: "EZ Bar Curl", sets: "4 x 10", rest: "90 sn" }, { name: "Skullcrusher (Alın Triseps)", sets: "4 x 10", rest: "90 sn" }, { name: "Scott Curl", sets: "3 x 12", rest: "60 sn" }, { name: "İp Triseps İtiş", sets: "3 x 14", rest: "60 sn" }] },
    { day: "Cumartesi", short: "Cmt", title: "Bacak (Arka) + Karın", focus: "Hamstring", duration: "60 dk", level: "Orta", exercises: [{ name: "Romanya Ölü Çekişi", sets: "4 x 10", rest: "120 sn" }, { name: "Yatarak Bacak Kıvırma", sets: "4 x 12", rest: "90 sn" }, { name: "Hip Thrust", sets: "3 x 12", rest: "90 sn" }, { name: "Kablo Karın Kıvırma", sets: "4 x 15", rest: "45 sn" }] },
    { day: "Pazar", short: "Paz", title: "Tam Dinlenme", focus: "Toparlanma", duration: "-", level: "-", exercises: [{ name: "Mobilite + Uyku", sets: "-", rest: "-" }], restDay: true },
  ],
  "form-koruma": [
    { day: "Pazartesi", short: "Pzt", title: "Full-Body A", focus: "Tüm Vücut", duration: "50 dk", level: "Orta", exercises: [{ name: "Squat (Çömelme)", sets: "3 x 10", rest: "90 sn" }, { name: "Bench Press (Göğüs Presi)", sets: "3 x 10", rest: "90 sn" }, { name: "Oturarak Sırt Çekişi", sets: "3 x 12", rest: "60 sn" }, { name: "Plank (Tahta)", sets: "3 x 45 sn", rest: "30 sn" }] },
    { day: "Salı", short: "Sal", title: "Kardiyo + Mobilite", focus: "Kondisyon", duration: "40 dk", level: "Hafif", exercises: [{ name: "Bisiklet", sets: "25 dk", rest: "-" }, { name: "Dinamik Esneme", sets: "10 dk", rest: "-" }, { name: "Yüzme / Yürüyüş", sets: "15 dk", rest: "-" }] },
    { day: "Çarşamba", short: "Çar", title: "Full-Body B", focus: "Tüm Vücut", duration: "50 dk", level: "Orta", exercises: [{ name: "Deadlift (Ölü Çekiş)", sets: "3 x 8", rest: "120 sn" }, { name: "Askeri Press (Ayakta)", sets: "3 x 10", rest: "90 sn" }, { name: "Lat Çekiş (Makine)", sets: "3 x 12", rest: "60 sn" }, { name: "Yan Plank", sets: "3 x 30 sn", rest: "30 sn" }] },
    { day: "Perşembe", short: "Per", title: "Dinlenme", focus: "Toparlanma", duration: "-", level: "-", exercises: [{ name: "Hafif Yürüyüş", sets: "20 dk", rest: "-" }], restDay: true },
    { day: "Cuma", short: "Cum", title: "Full-Body C", focus: "Tüm Vücut", duration: "50 dk", level: "Orta", exercises: [{ name: "Bacak Presi", sets: "3 x 12", rest: "90 sn" }, { name: "Eğimli Şınav", sets: "3 x 15", rest: "60 sn" }, { name: "Dumbbell Sırt Çekişi", sets: "3 x 12", rest: "60 sn" }, { name: "Dead Bug", sets: "3 x 12", rest: "30 sn" }] },
    { day: "Cumartesi", short: "Cmt", title: "Açık Hava Aktivitesi", focus: "Eğlence", duration: "60 dk", level: "Hafif", exercises: [{ name: "Koşu / Bisiklet / Yüzme", sets: "45 dk", rest: "-" }, { name: "Esneme", sets: "10 dk", rest: "-" }] },
    { day: "Pazar", short: "Paz", title: "Tam Dinlenme", focus: "Toparlanma", duration: "-", level: "-", exercises: [{ name: "Uyku + Beslenme", sets: "-", rest: "-" }], restDay: true },
  ],
};

export function getGoal(id: string): Goal {
  return GOALS.find((g) => g.id === id) ?? GOALS[2];
}

export function getTodayWorkout(goalId: string): WorkoutDay {
  const jsDay = new Date().getDay(); // 0 Pazar
  const idx = jsDay === 0 ? 6 : jsDay - 1;
  return (WEEKLY_PLAN[goalId] ?? WEEKLY_PLAN["kas-gelistirme"])[idx];
}

export function getDayIndexTR(): number {
  const jsDay = new Date().getDay();
  return jsDay === 0 ? 6 : jsDay - 1;
}

export function dayCount(startISO: string): number {
  const start = new Date(startISO).getTime();
  const now = Date.now();
  const diff = Math.floor((now - start) / 86400000) + 1;
  return diff < 1 ? 1 : diff;
}

export function formatDateTR(d: Date = new Date()): string {
  return d.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" });
}
