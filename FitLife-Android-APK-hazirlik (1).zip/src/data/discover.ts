import type { GoalId } from "../types";
import type { ExerciseInfo, Motion } from "./exercises";
import { EXERCISES, registerExercises } from "./exercises";

type Lvl = "baslangic" | "orta" | "ileri";
const G: GoalId[] = ["kilo-verme", "kilo-alma", "kas-gelistirme", "form-koruma"];

const X = (
  name: string, group: string, motion: Motion, equipment: string, how: string[], tip: string,
  level: Lvl, minutes: number, kcal: number, goals: GoalId[], tags: string[]
): ExerciseInfo => ({ name, group, motion, equipment, how, tip, level, minutes, kcal, goals, tags });

/** Programda olmayan, keşfet için ekstra egzersizler */
export const EXTRA_EXERCISES: ExerciseInfo[] = [
  X("İp Atlama", "Kardiyo", "cardio", "Atlama ipi", ["Dirsekleri vücuda yakın, bileklerle çevir.", "Ayak uçlarında hafifçe zıpla.", "30 sn çalış, 15 sn dinlen."], "Yüksek zıplama; yerden 2–3 cm yeter.", "baslangic", 10, 120, ["kilo-verme", "form-koruma"], ["evde", "ekipmansız-yakın", "hiit"]),
  X("Jumping Jack", "Kardiyo", "cardio", "Yok", ["Ayaklar bitişik, kollar yanda başla.", "Zıplayarak bacakları aç, kolları başın üstünde birleştir.", "Zıplayarak başlangıca dön."], "Dizleri yumuşak tut.", "baslangic", 5, 50, ["kilo-verme", "form-koruma"], ["evde", "ekipmansız", "ısınma"]),
  X("Yüksek Diz Koşusu", "Kardiyo", "cardio", "Yok", ["Olduğun yerde koşarken dizleri kalça hizasına çek.", "Kollarını aktif salla.", "Tempoyu yüksek tut."], "Gövdeni dik tut, öne eğilme.", "orta", 6, 70, ["kilo-verme"], ["evde", "ekipmansız", "hiit"]),
  X("Bulgar Split Squat", "Bacak", "squat", "Bank, dumbbell", ["Arka ayağını banka koy.", "Ön bacağınla çömel, diz ayak ucu hizasında.", "Ön topuktan iterek kalk."], "Dengede kalmak için bir noktaya odaklan.", "ileri", 12, 90, ["kas-gelistirme", "kilo-alma"], ["bacak", "tek-bacak"]),
  X("Glute Bridge (Kalça Köprüsü)", "Kalça", "hinge", "Yok", ["Sırtüstü yat, dizler bükülü, ayaklar yerde.", "Kalçanı yukarı it, üstte 1 sn sık.", "Yavaşça indir."], "Belinle değil kalçanla it.", "baslangic", 8, 50, G, ["evde", "ekipmansız", "kalça"]),
  X("Superman", "Alt sırt", "plank", "Yok", ["Yüzüstü yat, kollar ileri.", "Kolları ve bacakları aynı anda kaldır.", "2 sn tut, indir."], "Boynunu nötr tut, yukarı bakma.", "baslangic", 6, 35, ["form-koruma", "kas-gelistirme"], ["evde", "ekipmansız", "core"]),
  X("Bisiklet Mekiği", "Karın", "crunch", "Yok", ["Sırtüstü yat, eller kulak hizasında.", "Dirseğini çapraz dize götür.", "Diğer tarafla dönüşümlü devam et."], "Hızlı değil kontrollü yap.", "baslangic", 6, 45, ["kilo-verme", "form-koruma"], ["evde", "ekipmansız", "core"]),
  X("Kol Düşürme (Hollow Hold)", "Core", "plank", "Yok", ["Sırtüstü yat, bel yere yapışık.", "Kolları ve bacakları yerden kaldır.", "Pozisyonu koru."], "Bel yerden kalkıyorsa dizleri bük.", "orta", 5, 35, ["kas-gelistirme", "form-koruma"], ["evde", "ekipmansız", "core"]),
  X("Dumbbell Thruster", "Tüm vücut", "press", "Dumbbell", ["Dumbbell'lar omuzda, çömel.", "Kalkarken kolları başın üstüne it.", "Tek akıcı hareket olarak tekrarla."], "Kalkışın gücünü presse aktar.", "ileri", 10, 110, ["kilo-verme", "kas-gelistirme"], ["hiit", "tüm-vücut"]),
  X("Renegade Row", "Sırt / Core", "pull", "Dumbbell", ["Şınav pozisyonunda dumbbell'ları tut.", "Bir kolu kalçaya doğru çek, gövde sabit.", "Diğer kolla tekrarla."], "Kalçanı döndürme.", "ileri", 8, 80, ["kas-gelistirme", "kilo-verme"], ["core", "sırt"]),
  X("Bear Crawl", "Tüm vücut", "cardio", "Yok", ["Dört ayak üzerinde dizleri yerden 3 cm kaldır.", "Çapraz el-ayakla ilerle.", "Sırtı düz tut."], "Yavaş ve kontrollü başla.", "orta", 6, 60, ["kilo-verme", "form-koruma"], ["evde", "ekipmansız", "mobilite"]),
  X("Farmer's Walk (Çiftçi Yürüyüşü)", "Kavrama / Tüm vücut", "cardio", "Ağır dumbbell / kettlebell", ["İki elinde ağırlıkla dik dur.", "Kısa ve hızlı adımlarla yürü.", "Omuzlar geride, karın sıkı."], "Ağırlık taşıyabileceğinin biraz üstünde olsun.", "orta", 8, 70, ["kas-gelistirme", "kilo-alma", "form-koruma"], ["güç", "kavrama"]),
  X("Wall Sit (Duvar Oturuşu)", "Bacak", "plank", "Duvar", ["Sırtını duvara yasla, dizler 90°.", "Pozisyonu belirtilen süre koru.", "Nefesini düzenli tut."], "Dizleri ayak uçlarını geçirme.", "baslangic", 5, 35, ["form-koruma", "kilo-verme"], ["evde", "ekipmansız", "izometrik"]),
  X("Pike Şınav", "Omuz", "pushup", "Yok", ["Kalçayı yukarı kaldırıp V şekli al.", "Başını yere doğru indir.", "Omuzlarla iterek dön."], "Omuz presi için ekipmansız alternatif.", "orta", 8, 55, ["kas-gelistirme", "form-koruma"], ["evde", "ekipmansız", "omuz"]),
  X("Diamond Şınav", "Triseps", "pushup", "Yok", ["Eller göğüs altında, baş ve işaret parmakları birleşik.", "Dirsekler vücuda yakın, in.", "Kollarını iterek kalk."], "Zor geliyorsa dizlerden yap.", "ileri", 8, 55, ["kas-gelistirme"], ["evde", "ekipmansız", "triseps"]),
  X("Yavaş Tempolu Yürüyüş", "Kardiyo", "cardio", "Yok", ["30–45 dk rahat tempoda yürü.", "Konuşabilecek hızda kal.", "Doğal kol salınımı."], "Toparlanma günleri için ideal.", "baslangic", 40, 160, ["form-koruma", "kilo-verme", "kilo-alma"], ["açık-hava", "toparlanma"]),
  X("Kalça Açıcı Esneme (90/90)", "Mobilite", "hinge", "Yok", ["Oturarak bir bacağı öne 90°, diğerini yana 90° koy.", "Gövdeni öne eğ, 30 sn tut.", "Taraf değiştir."], "Zorlamadan, nefesle derinleş.", "baslangic", 6, 20, G, ["mobilite", "esneme", "evde"]),
  X("Kedi-İnek Esnemesi", "Omurga", "hinge", "Yok", ["Dört ayak üzerinde başla.", "Nefes alırken beli çukurlaştır, verirken sırtı yuvarla.", "Yavaşça 10 kez tekrarla."], "Antrenman öncesi omurga ısınması.", "baslangic", 4, 15, G, ["mobilite", "ısınma", "evde"]),
  X("Dumbbell Pullover", "Göğüs / Sırt", "pull", "Dumbbell, bank", ["Sırtüstü bankta, dumbbell'ı iki elle göğüs üstünde tut.", "Kollar hafif bükülü, ağırlığı başının arkasına indir.", "Göğüs ve sırtınla geri çek."], "Kaburgayı açma, karnı sıkı tut.", "orta", 8, 55, ["kas-gelistirme", "kilo-alma"], ["göğüs", "sırt"]),
  X("Box Jump (Kutu Zıplama)", "Patlayıcı güç", "squat", "Pliometrik kutu", ["Kutunun önünde hafif çömel.", "Kolları savurarak kutuya zıpla, yumuşak in.", "Adım atarak in, tekrarla."], "Güvenli yükseklikle başla.", "ileri", 8, 90, ["kilo-verme", "kas-gelistirme"], ["pliometrik", "hiit"]),
  X("Kürek Makinesi", "Tüm vücut kardiyo", "pull", "Kürek ergometresi", ["Bacaklarla it, sonra gövdeyi geriye yatır, en son kolları çek.", "Tersten geri dön.", "Dakikada 24–28 kürek."], "Kolları değil bacakları önce kullan.", "orta", 20, 200, ["kilo-verme", "form-koruma"], ["kardiyo", "makine"]),
  X("Tek Bacak Romanya Çekişi", "Arka bacak / Denge", "hinge", "Dumbbell", ["Tek bacak üzerinde dur.", "Kalçadan eğilirken diğer bacağı geriye uzat.", "Kalçanı sıkarak dik pozisyona dön."], "Kalçayı yere paralel tut, açma.", "ileri", 10, 60, ["kas-gelistirme", "form-koruma"], ["denge", "tek-bacak"]),
  X("Yan Adım (Lateral Lunge)", "İç bacak", "squat", "Yok", ["Yana geniş adım at.", "Adım attığın bacağınla çömel, diğeri düz.", "İterek başlangıca dön."], "Ayaklar yere düz basmalı.", "baslangic", 8, 50, ["form-koruma", "kilo-verme"], ["evde", "ekipmansız", "bacak"]),
  X("Boksör Gölge Çalışması", "Kardiyo", "cardio", "Yok", ["Boksör duruşu al, dirsekler aşağı.", "Düz, kroşe ve aparkat kombinasyonları at.", "3 dk çalış, 1 dk dinlen."], "Nefesini yumruklarla eşle.", "orta", 12, 120, ["kilo-verme", "form-koruma"], ["kardiyo", "evde", "ekipmansız"]),
];

registerExercises(EXTRA_EXERCISES);

export const ALL_EXERCISES: ExerciseInfo[] = [...EXERCISES, ...EXTRA_EXERCISES];

export interface DiscoverFilter {
  goal?: GoalId;
  level?: Lvl;
  tag?: string;
  query?: string;
  maxMinutes?: number;
}

export function discover(filter: DiscoverFilter, exclude: Set<string>): ExerciseInfo[] {
  const q = (filter.query ?? "").trim().toLocaleLowerCase("tr-TR");
  return EXTRA_EXERCISES.filter((e) => {
    if (exclude.has(e.name)) return false;
    if (filter.goal && !e.goals?.includes(filter.goal)) return false;
    if (filter.level && e.level !== filter.level) return false;
    if (filter.tag && !e.tags?.includes(filter.tag)) return false;
    if (filter.maxMinutes && (e.minutes ?? 0) > filter.maxMinutes) return false;
    if (q && !`${e.name} ${e.group} ${e.tags?.join(" ")}`.toLocaleLowerCase("tr-TR").includes(q)) return false;
    return true;
  });
}

export const DISCOVER_TAGS: { id: string; label: string }[] = [
  { id: "evde", label: "Evde" },
  { id: "ekipmansız", label: "Ekipmansız" },
  { id: "hiit", label: "HIIT" },
  { id: "core", label: "Core" },
  { id: "mobilite", label: "Mobilite" },
  { id: "kardiyo", label: "Kardiyo" },
  { id: "güç", label: "Güç" },
  { id: "toparlanma", label: "Toparlanma" },
];

export interface QuickRoutine {
  id: string;
  title: string;
  desc: string;
  minutes: number;
  level: Lvl;
  goals: GoalId[];
  exercises: { name: string; sets: string; rest: string }[];
}

export const QUICK_ROUTINES: QuickRoutine[] = [
  { id: "hiit-12", title: "12 Dakika Yağ Yakıcı HIIT", desc: "Ekipmansız, yüksek tempolu devre", minutes: 12, level: "orta", goals: ["kilo-verme", "form-koruma"],
    exercises: [{ name: "Jumping Jack", sets: "40 sn", rest: "20 sn" }, { name: "Yüksek Diz Koşusu", sets: "40 sn", rest: "20 sn" }, { name: "Burpee", sets: "30 sn", rest: "30 sn" }, { name: "Dağ Tırmanışı", sets: "40 sn", rest: "20 sn" }, { name: "Squat (Çömelme)", sets: "40 sn", rest: "20 sn" }] },
  { id: "core-10", title: "10 Dakika Core", desc: "Karın ve bel sağlığı", minutes: 10, level: "baslangic", goals: ["kilo-verme", "kas-gelistirme", "form-koruma", "kilo-alma"],
    exercises: [{ name: "Plank (Tahta)", sets: "3 x 40 sn", rest: "20 sn" }, { name: "Bisiklet Mekiği", sets: "3 x 20", rest: "20 sn" }, { name: "Dead Bug", sets: "3 x 12", rest: "20 sn" }, { name: "Superman", sets: "3 x 12", rest: "20 sn" }] },
  { id: "mob-8", title: "8 Dakika Mobilite", desc: "Antrenman öncesi veya dinlenme günü", minutes: 8, level: "baslangic", goals: ["kilo-verme", "kas-gelistirme", "form-koruma", "kilo-alma"],
    exercises: [{ name: "Kedi-İnek Esnemesi", sets: "10 tekrar", rest: "-" }, { name: "Kalça Açıcı Esneme (90/90)", sets: "2 x 30 sn", rest: "-" }, { name: "Yan Adım (Lateral Lunge)", sets: "2 x 8", rest: "-" }, { name: "Tüm Vücut Esnetme", sets: "2 dk", rest: "-" }] },
  { id: "ust-15", title: "15 Dakika Üst Vücut Pompası", desc: "Sadece dumbbell ile", minutes: 15, level: "orta", goals: ["kas-gelistirme", "kilo-alma"],
    exercises: [{ name: "Dumbbell Thruster", sets: "3 x 10", rest: "45 sn" }, { name: "Renegade Row", sets: "3 x 8", rest: "45 sn" }, { name: "Pike Şınav", sets: "3 x 10", rest: "45 sn" }, { name: "Çekiç Curl", sets: "3 x 12", rest: "30 sn" }] },
  { id: "bacak-15", title: "15 Dakika Bacak & Kalça", desc: "Ev ortamı için tek bacak odaklı", minutes: 15, level: "ileri", goals: ["kas-gelistirme", "kilo-verme"],
    exercises: [{ name: "Bulgar Split Squat", sets: "3 x 10", rest: "45 sn" }, { name: "Glute Bridge (Kalça Köprüsü)", sets: "3 x 15", rest: "30 sn" }, { name: "Tek Bacak Romanya Çekişi", sets: "3 x 8", rest: "45 sn" }, { name: "Wall Sit (Duvar Oturuşu)", sets: "2 x 45 sn", rest: "30 sn" }] },
];
