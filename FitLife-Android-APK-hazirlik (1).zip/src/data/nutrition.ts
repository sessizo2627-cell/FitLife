import type { GoalId, UserProfile } from "../types";
import { calorieGoal, proteinGoal } from "../lib/calc";

export interface MealSuggestion {
  time: string;
  title: string;
  items: string[];
  kcal: number;
  protein: number;
}

export interface DailyPlan {
  label: string;
  meals: MealSuggestion[];
}

interface GoalNutrition {
  summary: string;
  macros: { carbPct: number; proteinPct: number; fatPct: number };
  weekly: string[];
  monthly: string[];
  days: DailyPlan[];
}

const base = (title: string, time: string, items: string[], kcal: number, protein: number): MealSuggestion => ({ time, title, items, kcal, protein });

export const NUTRITION: Record<GoalId, GoalNutrition> = {
  "kilo-verme": {
    summary: "Günlük 400–500 kcal açık; yüksek protein ve lifle tokluk, düşük glisemik karbonhidrat.",
    macros: { carbPct: 35, proteinPct: 35, fatPct: 30 },
    weekly: [
      "Haftada 5 gün sebze ağırlıklı akşam yemeği",
      "En fazla 1 serbest öğün (kontrollü porsiyon)",
      "Haftada 2–3 kez yağlı balık (somon, sardalya)",
      "Şekerli içecek yerine su, maden suyu, bitki çayı",
      "Her gün 25–30 g lif hedefi",
    ],
    monthly: [
      "1. hafta: Porsiyon farkındalığı ve kalori takibi alışkanlığı",
      "2. hafta: Rafine şeker ve beyaz un tüketimini yarıya indir",
      "3. hafta: Protein alımını her öğünde 25–35 g'a sabitle",
      "4. hafta: Ölçüm al, kalori hedefini 100 kcal düşür ve yeni ay planını güncelle",
    ],
    days: [
      { label: "Gün A", meals: [
        base("Kahvaltı", "08:00", ["3 yumurta beyazı + 1 tam yumurta omlet", "Bol yeşillik, domates", "1 dilim tam tahıllı ekmek"], 340, 26),
        base("Ara öğün", "11:00", ["1 elma", "10 badem"], 160, 4),
        base("Öğle", "13:30", ["150 g ızgara tavuk göğsü", "Büyük salata (zeytinyağı 1 tatlı kaşığı)", "4 yemek kaşığı bulgur pilavı"], 520, 45),
        base("Ara öğün", "16:30", ["Yağsız yoğurt 200 g", "Tarçın"], 130, 12),
        base("Akşam", "19:30", ["160 g ızgara somon", "Fırın sebze", "Yeşil salata"], 480, 38),
      ]},
      { label: "Gün B", meals: [
        base("Kahvaltı", "08:00", ["Yulaf 40 g + süt", "Yaban mersini", "1 yemek kaşığı chia"], 330, 15),
        base("Ara öğün", "11:00", ["Protein shake (su ile)"], 150, 28),
        base("Öğle", "13:30", ["Ton balıklı salata (su konservesi)", "Haşlanmış yumurta", "Tam buğday ekmeği 1 dilim"], 450, 42),
        base("Ara öğün", "16:30", ["Havuç çubukları + 2 yemek kaşığı humus"], 140, 5),
        base("Akşam", "19:30", ["Hindi köfte 150 g", "Mercimek çorbası", "Mevsim salata"], 500, 44),
      ]},
    ],
  },
  "kilo-alma": {
    summary: "Günlük 300–500 kcal fazla; sık öğün, kalori yoğun ama temiz kaynaklar (yulaf, fıstık ezmesi, pirinç, et).",
    macros: { carbPct: 50, proteinPct: 25, fatPct: 25 },
    weekly: [
      "Günde 5–6 öğün, antrenman sonrası karbonhidrat + protein",
      "Haftada 4 gün kırmızı veya beyaz et, 3 gün bakliyat",
      "Her gün 2–3 porsiyon süt ürünü",
      "Kuruyemiş ve fıstık ezmesiyle kalori yoğunluğu artır",
      "Haftalık kilo artışı 0,25–0,5 kg hedefi",
    ],
    monthly: [
      "1. hafta: Öğün sayısını 5'e çıkar, kahvaltıyı asla atlama",
      "2. hafta: Kalori hedefini 150 kcal artır, antrenman sonrası shake ekle",
      "3. hafta: Kilo artışı yavaşsa karbonhidratı 50 g artır",
      "4. hafta: Ölçüm al; bel çevresi artıyorsa yağı, artmıyorsa karbonhidratı artır",
    ],
    days: [
      { label: "Gün A", meals: [
        base("Kahvaltı", "07:30", ["Yulaf 80 g + tam yağlı süt", "1 muz, 1 yemek kaşığı fıstık ezmesi", "2 haşlanmış yumurta"], 720, 32),
        base("Ara öğün", "10:30", ["Peynirli tam buğday sandviç", "1 avuç ceviz"], 450, 18),
        base("Öğle", "13:00", ["200 g tavuk but", "1,5 su bardağı pirinç pilavı", "Yoğurt"], 800, 55),
        base("Antrenman sonrası", "17:00", ["Protein shake + süt", "1 muz"], 380, 35),
        base("Akşam", "20:00", ["200 g kırmızı et / köfte", "Fırın patates", "Salata (zeytinyağlı)"], 780, 48),
      ]},
      { label: "Gün B", meals: [
        base("Kahvaltı", "07:30", ["3 yumurtalı menemen", "2 dilim ekmek, beyaz peynir, zeytin"], 650, 30),
        base("Ara öğün", "10:30", ["Kuru meyve + badem karışımı 60 g", "Süt 250 ml"], 420, 14),
        base("Öğle", "13:00", ["Somon 200 g", "Makarna 100 g (kuru)", "Yeşillik"], 850, 52),
        base("Antrenman sonrası", "17:00", ["Yoğurt 300 g + granola + bal"], 450, 22),
        base("Akşam", "20:00", ["Hindi sote 200 g", "Bulgur pilavı", "Cacık"], 720, 50),
      ]},
    ],
  },
  "kas-gelistirme": {
    summary: "Hafif kalori fazlası (+250–300 kcal); yüksek protein (2–2,2 g/kg), antrenman etrafında karbonhidrat zamanlaması.",
    macros: { carbPct: 45, proteinPct: 30, fatPct: 25 },
    weekly: [
      "Her öğünde 30–40 g protein (günde 4–5 öğün)",
      "Antrenman öncesi 1–2 saat: karbonhidrat + protein",
      "Antrenman sonrası 60 dk içinde: hızlı protein + karbonhidrat",
      "Haftada 3 gün yumurta, 3 gün balık, her gün süt ürünü",
      "Kreatin kullanıyorsan günde 3–5 g, sabit saatte",
    ],
    monthly: [
      "1. hafta: Protein hedefini tuttur, öğün saatlerini sabitle",
      "2. hafta: Antrenman günleri karbonhidratı 30 g artır (günlük döngü)",
      "3. hafta: Kuvvet artmıyorsa kaloriyi 100–150 kcal yükselt",
      "4. hafta: Ölçüm (kol, göğüs, bel); yağlanma varsa fazla kaloriyi azalt",
    ],
    days: [
      { label: "Antrenman günü", meals: [
        base("Kahvaltı", "07:30", ["Yulaf 60 g + süt + whey 1 ölçek", "1 muz"], 560, 42),
        base("Öğle", "12:30", ["180 g tavuk göğsü", "Pirinç 1 su bardağı", "Brokoli"], 640, 50),
        base("Antrenman öncesi", "16:00", ["Pirinç keki 3 adet + fıstık ezmesi", "1 elma"], 320, 10),
        base("Antrenman sonrası", "18:30", ["Whey 1 ölçek + su", "1 muz / 30 g dekstroz"], 260, 28),
        base("Akşam", "20:30", ["200 g dana biftek", "Tatlı patates 200 g", "Salata"], 720, 52),
        base("Gece", "22:30", ["Süzme yoğurt 200 g", "1 avuç ceviz"], 260, 22),
      ]},
      { label: "Dinlenme günü", meals: [
        base("Kahvaltı", "08:00", ["3 yumurta + 2 beyaz omlet", "Avokado, tam buğday ekmeği"], 520, 32),
        base("Öğle", "13:00", ["Ton balığı 160 g", "Kinoa salatası", "Zeytinyağı"], 560, 44),
        base("Ara öğün", "16:30", ["Lor peyniri 150 g", "Ceviz"], 280, 24),
        base("Akşam", "19:30", ["Somon 180 g", "Fırın sebze", "Bulgur yarım su bardağı"], 600, 46),
        base("Gece", "22:00", ["Kazein / süzme yoğurt 200 g"], 180, 22),
      ]},
    ],
  },
  "form-koruma": {
    summary: "Bakım kalorisi; dengeli makrolar, çeşitli sebze-meyve, haftalık esneklik payı.",
    macros: { carbPct: 45, proteinPct: 25, fatPct: 30 },
    weekly: [
      "Haftada 2 serbest öğün (80/20 kuralı)",
      "Her gün 5 porsiyon sebze-meyve",
      "Haftada 2 kez balık, 2 kez bakliyat, 3 kez beyaz/kırmızı et",
      "Günlük 1,6 g/kg protein ile kas korunumu",
      "Haftalık tartı: ±1 kg aralığında kal",
    ],
    monthly: [
      "1. hafta: Bakım kalorisini ve mevcut alışkanlıkları gözlemle",
      "2. hafta: İşlenmiş gıda tüketimini azalt, ev yemeğini artır",
      "3. hafta: Sebze çeşitliliğini artır (haftada 10 farklı sebze)",
      "4. hafta: Ölçüm ve kilo kontrolü; sapma varsa kaloriyi ±100 kcal ayarla",
    ],
    days: [
      { label: "Gün A", meals: [
        base("Kahvaltı", "08:00", ["Peynir, zeytin, domates, salatalık", "2 dilim tam tahıllı ekmek", "1 yumurta"], 450, 22),
        base("Ara öğün", "11:00", ["Meyve 1 porsiyon", "Fındık 1 avuç"], 200, 5),
        base("Öğle", "13:00", ["Zeytinyağlı sebze yemeği", "Tavuk 120 g", "Bulgur pilavı"], 580, 38),
        base("Ara öğün", "16:30", ["Yoğurt + meyve"], 180, 10),
        base("Akşam", "19:30", ["Mercimek köftesi / balık 150 g", "Salata", "Çorba"], 520, 32),
      ]},
      { label: "Gün B", meals: [
        base("Kahvaltı", "08:00", ["Yulaf 50 g + süt", "Ceviz, kuru üzüm"], 400, 16),
        base("Ara öğün", "11:00", ["Ayran 1 bardak", "Tam buğday kraker"], 190, 8),
        base("Öğle", "13:00", ["Nohut yemeği", "Pirinç pilavı", "Cacık"], 620, 24),
        base("Ara öğün", "16:30", ["Portakal", "Badem 10 adet"], 180, 4),
        base("Akşam", "19:30", ["Izgara köfte 150 g", "Közlenmiş sebze", "Salata"], 560, 40),
      ]},
    ],
  },
};

export function nutritionFor(profile: UserProfile, weight?: number) {
  const kcal = calorieGoal(profile, weight);
  const protein = proteinGoal(profile, weight);
  const n = NUTRITION[profile.goalId];
  const carbs = Math.round((kcal * n.macros.carbPct) / 100 / 4);
  const fat = Math.round((kcal * n.macros.fatPct) / 100 / 9);
  return { ...n, kcal, protein, carbs, fat };
}

/** Günün planını, örnek günün kalorisini kullanıcının hedefine orantılayarak ölçekler */
export function scalePlan(plan: DailyPlan, targetKcal: number): DailyPlan {
  const total = plan.meals.reduce((s, m) => s + m.kcal, 0) || 1;
  const f = targetKcal / total;
  return {
    ...plan,
    meals: plan.meals.map((m) => ({ ...m, kcal: Math.round((m.kcal * f) / 10) * 10, protein: Math.round(m.protein * Math.min(1.3, Math.max(0.8, f))) })),
  };
}
