/* Egzersiz kütüphanesi — Türkçe ad, kas grubu, nasıl yapılır ve hareket tipi.
   gif alanına gerçek bir hareket GIF'i yolu verilirse animasyon yerine o gösterilir. */

export type Motion =
  | "squat"
  | "press"
  | "raise"
  | "pull"
  | "curl"
  | "crunch"
  | "plank"
  | "pushup"
  | "cardio"
  | "hinge";

export type Level = "baslangic" | "orta" | "ileri";

export interface ExerciseInfo {
  name: string;
  group: string;
  motion: Motion;
  equipment: string;
  how: string[];
  tip: string;
  gif?: string;
  /** Keşfet için meta */
  level?: Level;
  minutes?: number;
  kcal?: number;
  goals?: ("kilo-verme" | "kilo-alma" | "kas-gelistirme" | "form-koruma")[];
  tags?: string[];
}

const E = (
  name: string,
  group: string,
  motion: Motion,
  equipment: string,
  how: string[],
  tip: string
): ExerciseInfo => ({ name, group, motion, equipment, how, tip });

export const EXERCISES: ExerciseInfo[] = [
  E("Şınav", "Göğüs", "pushup", "Vücut ağırlığı", ["Elleri omuz genişliğinde yere koy, vücut düz bir çizgi olsun.", "Dirsekleri yaklaşık 45° açıyla bükerek göğsü yere yaklaştır.", "Kollarını iterek başlangıç pozisyonuna dön."], "Kalçanı düşürme, karnını sıkı tut."),
  E("Dumbbell Sırt Çekişi", "Sırt", "pull", "Dumbbell, bank", ["Bir elini ve dizini banka koy, diğer elinle dumbbell'ı tut.", "Dirseği vücuda yakın tutarak dumbbell'ı kalçaya doğru çek.", "Kontrollü şekilde başlangıca indir."], "Gövdeni yere paralel ve sabit tut."),
  E("Omuz Presi", "Omuz", "press", "Dumbbell", ["Dumbbell'ları omuz hizasında, avuçlar ileri bakacak şekilde tut.", "Kollarını başının üstüne doğru it.", "Yavaşça omuz hizasına indir."], "Belini aşırı kavislendirme."),
  E("HIIT Bisiklet", "Kardiyo", "cardio", "Yok / bisiklet", ["Maksimum tempoda 30 saniye pedal çevir.", "30 saniye hafif tempoda dinlen.", "Bu döngüyü belirtilen set sayısı kadar tekrarla."], "Nefesini düzenli tut, tempoyu bozma."),
  E("Eğimli Yürüyüş", "Kardiyo", "cardio", "Koşu bandı", ["Eğimi orta seviyeye ayarla.", "Dik duruşla ritmik şekilde yürü.", "Kollarını doğal şekilde salla."], "Öne eğilerek tutunma."),
  E("Plank (Tahta)", "Core", "plank", "Yok", ["Dirseklerini omuzlarının altına koy.", "Vücudunu topuklardan başına kadar düz bir çizgi yap.", "Karnını ve kalçanı sıkarak nefes al-ver."], "Belinin çökmesine izin verme."),
  E("Rus Burgusu", "Core", "crunch", "Yok / ağırlık", ["Oturup gövdeni hafifçe geriye yatır, ayaklarını yerden kaldır.", "Ellerini birleştirip gövdeni sağa ve sola çevir.", "Hareketi gövdenle yap, sadece kollarınla değil."], "Omurganı dik ve kontrollü tut."),
  E("Dağ Tırmanışı", "Core", "cardio", "Yok", ["Plank pozisyonunda başla, kollar omuz altında.", "Dizlerini sırayla göğsüne doğru çek.", "Hızlı ama kontrollü devam et."], "Kalçanı yukarı kaldırma."),
  E("Squat (Çömelme)", "Bacak", "squat", "Vücut ağırlığı", ["Ayaklar omuz genişliğinde, göğsü dik tut.", "Kalçayı geriye ve aşağı indir; dizler ayak ucunu çok aşmasın.", "Topuklardan itilerek kalk."], "Topukların yerden kalkmasın."),
  E("Romanya Ölü Çekişi", "Arka bacak", "hinge", "Barbell / dumbbell", ["Dizlerini hafif bük, sırtını düz tut.", "Kalçandan menteşe gibi bükerek ağırlığı bacak boyunca indir.", "Kalçanı sıkarak dik pozisyona dön."], "Sırtı yuvarlatma, ağırlığı vücuda yakın tut."),
  E("İleri Adım (Lunge)", "Bacak", "squat", "Dumbbell (opsiyonel)", ["Bir adım öne at.", "Arka dizi yere yaklaştırarak alçal.", "Ön ayaktan itilerek başlangıca dön."], "Ön diz ayak ucunun hizasında kalsın."),
  E("Baldır Kaldırma", "Baldır", "squat", "Vücut ağırlığı", ["Ayak uçlarında mümkün olduğunca yüksel.", "Bir saniye yukarıda bekle.", "Yavaşça topuklarına in."], "Hareketi yavaş ve tam aralıkta yap."),
  E("Tüm Vücut Esnetme", "Esneme", "hinge", "Yok", ["Ayakta öne doğru yavaşça eğil.", "Dizlerini yumuşak tutarak 20 saniye bekle.", "Nefes alarak doğrul."], "Ağrıya değil gerilmeye odaklan."),
  E("Goblet Çömelme", "Bacak", "squat", "Kettlebell / dumbbell", ["Ağırlığı göğüs hizasında iki elle tut.", "Sırtı dik tutarak çömel, dirseklerin dizlerin içinde kalsın.", "Topuklardan iterek kalk."], "Göğsünü dik tut."),
  E("İtme Presi", "Omuz", "press", "Dumbbell", ["Dizlerini hafifçe bük, bacaklarından güç al.", "Ağırlığı omuzlardan yukarı it.", "Kontrollü şekilde omuzlara indir."], "Gücü bacaklardan başlat."),
  E("Lat Çekiş (Makine)", "Sırt", "pull", "Kablo makinesi", ["Barı geniş tutuşla tut, sandalyeye oturup dizlerini sabitle.", "Barı göğsün üst kısmına doğru çek.", "Yavaşça kolları düzelterek başlangıca dön."], "Gövdeni hafifçe geriye yatır, sallanma."),
  E("Burpee", "Kardiyo", "cardio", "Vücut ağırlığı", ["Çömel ve elleri yere koy.", "Ayaklarını geriye atarak şınav pozisyonuna geç.", "Ayaklarını geri getir ve yukarı zıplayarak kalk."], "Her tekrarı aynı kalitede yap."),
  E("Koşu / Bisiklet", "Kardiyo", "cardio", "Koşu bandı / bisiklet", ["Hedef süre boyunca sabit tempoda çalış.", "Nefesini konuşabileceğin seviyede tut."], "Isınma ve soğuma için 5'er dakika ekle."),
  E("Kettlebell Savurma", "Kalça", "hinge", "Kettlebell", ["Kettlebell'i iki elle tut, kalçanı geriye iterek eğil.", "Kalçanı güçlü şekilde açarak ağırlığı göğüs hizasına savur.", "Kontrollü şekilde sarkıtıp tekrarla."], "Gücü kollarla değil kalçadan üret."),
  E("Yan Plank", "Core", "plank", "Yok", ["Yan yatıp dirseğini omzunun altına koy.", "Kalçanı kaldırıp vücudunu düz çizgi yap.", "Pozisyonu belirtilen süre koru."], "Kalçanın düşmesine izin verme."),
  E("Bench Press (Göğüs Presi)", "Göğüs", "press", "Barbell, bank", ["Sırtını bankta sabit tut, barı omuz genişliğinde tut.", "Barı kontrollü şekilde göğsünün alt kısmına indir.", "Patlayıcı şekilde yukarı it."], "Kürek kemiklerini birleştirip bankta sabit kal."),
  E("Eğimli Dumbbell Press", "Üst göğüs", "press", "Dumbbell, eğimli bank", ["Bankı 30–45° eğimle ayarla.", "Dumbbell'ları omuz hizasından yukarı it.", "Kontrollü şekilde indir."], "Dirsekleri çok dışa açma."),
  E("Kablo Kelebek", "Göğüs", "raise", "Kablo makinesi", ["Kolların hafif bükülü, makinenin iki yanında dur.", "Kollarını göğüs önünde birleştir.", "Yavaşça açarak başlangıca dön."], "Göğüs kasında gerilimi hisset."),
  E("Triseps İtiş (Kablo)", "Triseps", "curl", "Kablo makinesi", ["Dirseklerini vücuda sabitle.", "Kabloyu aşağı doğru it, kolunu tamamen düzelt.", "Kontrollü şekilde yukarı dön."], "Dirsekler hareket etmesin."),
  E("Barfiks / Lat Çekiş", "Sırt", "pull", "Barfiks bar / lat makinesi", ["Bara avuç içleri dışa bakacak şekilde tut.", "Göğsünü bara doğru çek.", "Kontrollü şekilde başlangıca in."], "Sallanmadan, tam aralıkta yap."),
  E("Barbell Sırt Çekişi", "Sırt", "pull", "Barbell", ["Dizlerini hafif bük, gövdeni öne eğ, sırt düz.", "Barı karnına doğru çek.", "Kontrollü şekilde indir."], "Sırtını düz tut."),
  E("Oturarak Kablo Çekiş", "Sırt", "pull", "Kablo makinesi", ["Ayaklarını platforma koy, gövdeni dik tut.", "Tutacağı karnına doğru çek.", "Kolunu uzatarak başlangıca dön."], "Gövdeni sabit tut."),
  E("Barbell Biceps Curl", "Biceps", "curl", "Barbell", ["Barı avuç için yukarı bakacak şekilde tut.", "Dirseklerini sabit tutarak barı omuz hizasına kaldır.", "Yavaşça indir."], "Sallanarak değil, bilekle kontrol ederek kaldır."),
  E("Askeri Press (Ayakta)", "Omuz", "press", "Barbell", ["Barı göğüs üstünde omuz genişliğinde tut.", "Başını hafifçe geriye al ve barı yukarı it.", "Kontrollü şekilde omuzlara indir."], "Kalçanı ve karnını sık."),
  E("Yana Kaldırma", "Omuz", "raise", "Dumbbell", ["Dumbbell'ları yanlara, omuz hizasına kaldır.", "Dirsekleri hafif bükülü tut.", "Yavaşça indir."], "Ağırlığı omuz yüksekliğinin üstüne çıkarma."),
  E("Yüz Çekişi (Face Pull)", "Arka omuz", "pull", "Kablo, halat", ["Kabloyu göz hizasına ayarla.", "Halatı yüzüne doğru çek, dirsekler yukarıda.", "Kontrollü şekilde bırak."], "Arka omuz ve üst sırtı hisset."),
  E("Asılı Bacak Kaldırma", "Karın", "crunch", "Barfiks bar", ["Bara asıl, omuzlarını aşağı bastır.", "Bacaklarını düz tutarak kalça hizasına kaldır.", "Yavaşça indir."], "Sallanmadan, karnınla kaldır."),
  E("Arka Squat", "Bacak", "squat", "Barbell", ["Barı trapez üstünde taşı, ayaklar omuz genişliğinde.", "Kalçanı geriye iterek çömel, sırt dik.", "Topuklardan iterek kalk."], "Dizlerini içe kapatma."),
  E("Bacak Presi", "Bacak", "squat", "Leg press makinesi", ["Sırtını yastığa yasla, ayaklarını platforma koy.", "Dizlerini bükerek ağırlığı it.", "Dizleri tam kilitlemeden kontrollü dön."], "Belin yerden kalkmasın."),
  E("Bacak Kıvırma", "Arka bacak", "squat", "Leg curl makinesi", ["Makineye uzanıp pedi topuklarına yerleştir.", "Topukları kalçaya doğru kıvır.", "Yavaşça başlangıca dön."], "Kalçanı yerden kaldırma."),
  E("Ayakta Baldır", "Baldır", "squat", "Makine / dumbbell", ["Omuzlarında yük ile dik dur.", "Ayak uçlarında yüksel.", "Yavaşça in."], "Tam esneme ve tam kasılma."),
  E("Eğimli Dumbbell Curl", "Biceps", "curl", "Dumbbell, eğimli bank", ["Eğimli bankta sırtını yasla, kollar aşağı sarkık.", "Dirseği sabit tutarak dumbbell'ı yukarı kaldır.", "Yavaşça indir."], "Kollarını öne düşürme."),
  E("Başın Üstü Triseps", "Triseps", "press", "Dumbbell", ["Dumbbell'ı iki elle başın üstüne kaldır.", "Dirsekleri başın yanında sabit tutarak ağırlığı arkaya indir.", "Kolunu yukarı iterek dön."], "Dirsekleri sabit tut."),
  E("Çekiç Curl", "Biceps", "curl", "Dumbbell", ["Avuçlar birbirine bakacak şekilde tut.", "Dirseği sabit tutarak yukarı kaldır.", "Yavaşça indir."], "Bilekleri düz tut."),
  E("Eğimli Barbell Press", "Üst göğüs", "press", "Barbell, eğimli bank", ["Bankı 30–45° eğimle ayarla.", "Barı üst göğüs hizasından kontrollü indir.", "Yukarı it."], "Barı köprücük kemiğine yakın tut."),
  E("Paralel Bar Dips", "Triseps / göğüs", "press", "Paralel bar", ["Barlara tutunup vücudunu yukarı kaldır.", "Dirsekleri bükerek kontrollü şekilde in.", "Kolların gücüyle yukarı it."], "Omuzları kulaklardan uzak tut."),
  E("Pec Deck (Kelebek)", "Göğüs", "raise", "Pec deck makinesi", ["Kolları pedlere yerleştir, dirsekler hafif bükülü.", "Kolları göğüs önünde birleştir.", "Yavaşça geri aç."], "Göğüs kasında sıkışmayı hisset."),
  E("Deadlift (Ölü Çekiş)", "Bütün vücut", "hinge", "Barbell", ["Barı ayak üstünde tut, sırtı düz ve dik.", "Kalçanı geriye iterek barı dizlerin üzerinden kaydır.", "Kalçanı ve sırtını sıkarak dik kalk."], "Sırtı yuvarlatma, barı vücuda yakın tut."),
  E("T-Bar Sırt Çekişi", "Sırt", "pull", "T-bar", ["Gövdeni öne eğ, sırt düz.", "Ağırlığı göğsüne doğru çek.", "Kontrollü şekilde indir."], "Dirsekleri vücuda yakın tut."),
  E("Düz Kol Çekiş", "Sırt", "pull", "Kablo makinesi", ["Kolları düz, kabloya biraz öne eğil.", "Kolları yan taraftan kalçaya doğru indir.", "Yavaşça başlangıca dön."], "Dirsekleri düz tut."),
  E("Arnold Press", "Omuz", "press", "Dumbbell", ["Dumbbell'ları çene hizasında, avuçlar sana bakacak şekilde tut.", "Dönerek kollarını yukarı it.", "Aynı hareketi tersten indir."], "Hareketi yavaş ve akıcı yap."),
  E("Kablo Yana Kaldırma", "Omuz", "raise", "Kablo makinesi", ["Kabloyu karşı taraftan tut, kol yanda.", "Kolu omuz hizasına kaldır.", "Kontrollü şekilde indir."], "Gövdeni sabit tut."),
  E("Shrug (Omuz Silkme)", "Trapez", "raise", "Dumbbell / barbell", ["Dik dur, ağırlığı iki elinde tut.", "Omuzlarını kulaklarına doğru kaldır.", "Yavaşça indir."], "Kollarını bükme, sadece omuzları hareket ettir."),
  E("Hack Squat", "Bacak", "squat", "Hack squat makinesi", ["Sırtını yastığa yasla, ayaklar platformda.", "Dizleri bükerek kalçayı aşağı indir.", "Topuklardan iterek dön."], "Dizleri ayak uçlarıyla aynı yönde tut."),
  E("Bacak Açma", "Ön bacak", "squat", "Leg extension makinesi", ["Makineye otur, pedi ayak bileklerine yerleştir.", "Bacaklarını tamamen düzelt.", "Yavaşça indir."], "Ani hareket etme, kontrollü ilerle."),
  E("Adduktör Makinesi", "İç bacak", "squat", "Adduktör makinesi", ["Makineye otur, pedleri dizlerinin dışına yerleştir.", "Bacaklarını birbirine doğru it.", "Yavaşça aç."], "Gövdeni sabit tut."),
  E("EZ Bar Curl", "Biceps", "curl", "EZ bar", ["EZ barı tam tut, dirsekler vücuda yakın.", "Barı omuz hizasına kaldır.", "Kontrollü şekilde indir."], "Sallanmadan yap."),
  E("Skullcrusher (Alın Triseps)", "Triseps", "curl", "EZ bar / dumbbell", ["Sırtüstü bankta, kolları dik tut.", "Dirsekleri sabit tutarak barı alnına doğru indir.", "Kolunu düzelterek yukarı it."], "Dirsekleri dışa açma."),
  E("Scott Curl", "Biceps", "curl", "EZ bar, scott bankı", ["Kollarını scott bankına yerleştir.", "Barı yukarı kaldır.", "Tam aralıkta yavaşça indir."], "Alt noktada tam uzat, sallanma."),
  E("İp Triseps İtiş", "Triseps", "curl", "Kablo, ip tutacak", ["Dirseklerini vücuda sabitle.", "İpi aşağı çekerek kolunu düzelt.", "Yavaşça yukarı dön."], "İpi açarak son noktada sık."),
  E("Yatarak Bacak Kıvırma", "Arka bacak", "squat", "Leg curl makinesi", ["Yüzüstü yat, pedi topuklarına yerleştir.", "Topukları kalçaya doğru kıvır.", "Yavaşça indir."], "Kalçanı pedden kaldırma."),
  E("Hip Thrust", "Kalça", "hinge", "Barbell, bank", ["Sırtını bankın kenarına yasla, barı kalçanın üstüne koy.", "Kalçanı yukarı it, üst noktada sık.", "Kontrollü şekilde indir."], "Boynunu uzun tut."),
  E("Kablo Karın Kıvırma", "Karın", "crunch", "Kablo, halat", ["Dizlerinin üzerine çök, halatı başının arkasına al.", "Karnını kıvırarak gövdeni aşağı çek.", "Yavaşça başlangıca dön."], "Kalçayı hareket ettirme, karnınla kıvır."),
  E("Oturarak Sırt Çekişi", "Sırt", "pull", "Kablo makinesi", ["Gövdeni dik tut, göğsünü dışa aç.", "Tutacağı göbeğine doğru çek.", "Kontrollü şekilde kolunu uzat."], "Omuzlarını öne yuvarlama."),
  E("Eğimli Şınav", "Göğüs", "pushup", "Vücut ağırlığı, yükseltilmiş yüzey", ["Ellerini bir bankta ya da yüksek bir yüzeyde tut.", "Vücut düz, dirsekleri bükerek göğsü yüzeye yaklaştır.", "Kollarını iterek dön."], "Kalçanı düşürme."),
  E("Dead Bug", "Core", "crunch", "Vücut ağırlığı", ["Sırtüstü yat, kollar tavan, dizler 90°.", "Bir kolu ve karşı bacağı yavaşça uzat.", "Başlangıca dönüp diğer tarafı tekrarla."], "Belin yere yapışık kalsın."),
];

const DEFAULT_HOW = ["Hareketi kontrollü ve doğru formda yap.", "Nefesini ritimle koru."];

/** Keşfet gibi ek kütüphaneler buraya kayıt olur; getExercise hepsinde arar */
const registry: ExerciseInfo[][] = [EXERCISES];
export function registerExercises(list: ExerciseInfo[]) {
  if (!registry.includes(list)) registry.push(list);
}

export function getExercise(name: string): ExerciseInfo {
  for (const list of registry) {
    const found = list.find((e) => e.name === name);
    if (found) return found;
  }
  return {
    name,
    group: "Genel",
    motion: "cardio",
    equipment: "—",
    how: DEFAULT_HOW,
    tip: "Hedef süre ya da tekrar sayısına odaklan; formunu bozma.",
  };
}
