import type { DayLog, FitLifeState, GoalId, Measurement, UserProfile } from "../types";
import { WEEKLY_PLAN } from "../data/fitness";
import { addDays, dateKey, mondayIndex, parseKey } from "./date";

export const emptyDay = (date: string): DayLog => ({
  date,
  exercises: {},
  workoutDone: false,
  water: 0,
  steps: 0,
  meals: [],
  activeSeconds: 0,
  note: "",
});

export const getDay = (state: FitLifeState, date: string): DayLog => state.days[date] ?? emptyDay(date);

export const exKey = (goalId: GoalId, dayIndex: number, exIndex: number) => `${goalId}:${dayIndex}:${exIndex}`;

/* ---------- Beslenme hedefleri (Mifflin-St Jeor) ---------- */
export function bmr(p: UserProfile, weight?: number): number {
  const w = weight ?? p.weight;
  const base = 10 * w + 6.25 * p.height - 5 * p.age;
  return Math.round(p.gender === "erkek" ? base + 5 : base - 161);
}

export function activityFactor(level: UserProfile["level"], weeklyTarget: number): number {
  const byDays = 1.2 + Math.min(7, weeklyTarget) * 0.05; // 1.25 – 1.55
  const byLevel = level === "ileri" ? 0.1 : level === "orta" ? 0.05 : 0;
  return Math.min(1.9, byDays + byLevel);
}

export function calorieGoal(p: UserProfile, weight?: number): number {
  const tdee = bmr(p, weight) * activityFactor(p.level, p.weeklyTarget);
  const adj =
    p.goalId === "kilo-verme" ? -450 : p.goalId === "kilo-alma" ? 400 : p.goalId === "kas-gelistirme" ? 300 : 0;
  return Math.max(1200, Math.round((tdee + adj) / 10) * 10);
}

export function proteinGoal(p: UserProfile, weight?: number): number {
  const perKg = p.goalId === "kas-gelistirme" ? 2.2 : p.goalId === "kilo-verme" ? 2 : p.goalId === "kilo-alma" ? 1.8 : 1.6;
  return Math.round((weight ?? p.weight) * perKg);
}

export const mealKcal = (d: DayLog) => d.meals.reduce((s, m) => s + m.kcal, 0);
export const mealProtein = (d: DayLog) => d.meals.reduce((s, m) => s + m.protein, 0);

/* ---------- Günlük ilerleme ---------- */
export interface DayProgress {
  exerciseRatio: number;
  exerciseDone: number;
  exerciseTotal: number;
  water: number;
  steps: number;
  nutrition: number;
  total: number; // 0..100
  isRestDay: boolean;
}

export function dayProgress(state: FitLifeState, date: string): DayProgress {
  const p = state.profile!;
  const log = getDay(state, date);
  const idx = mondayIndex(parseKey(date));
  const plan = WEEKLY_PLAN[p.goalId][idx];
  const total = plan.exercises.length;
  const done = plan.exercises.reduce((s, _e, i) => s + (log.exercises[exKey(p.goalId, idx, i)] ? 1 : 0), 0);
  const exerciseRatio = log.workoutDone ? 1 : total ? done / total : 0;
  const water = Math.min(1, log.water / Math.max(1, p.waterGoal));
  const steps = Math.min(1, log.steps / Math.max(1, p.stepGoal));
  const nutrition = Math.min(1, mealKcal(log) / Math.max(1, calorieGoal(p)));
  const totalPct = Math.round((exerciseRatio * 0.45 + water * 0.2 + steps * 0.15 + nutrition * 0.2) * 100);
  return {
    exerciseRatio,
    exerciseDone: log.workoutDone ? total : done,
    exerciseTotal: total,
    water,
    steps,
    nutrition,
    total: Math.min(100, totalPct),
    isRestDay: !!plan.restDay,
  };
}

/** Antrenman tamamlanmış sayılan gün mü? */
export function isDayComplete(state: FitLifeState, date: string): boolean {
  const log = state.days[date];
  if (!log) return false;
  return log.workoutDone || dayProgress(state, date).exerciseRatio >= 0.999;
}

/** Ardışık tamamlanan gün serisi (bugün boşsa dünden başlar) */
export function currentStreak(state: FitLifeState): number {
  if (!state.profile) return 0;
  let streak = 0;
  let cursor = new Date();
  if (!isDayComplete(state, dateKey(cursor))) cursor = addDays(cursor, -1);
  const startKey = dateKey(state.profile.startDate);
  for (let i = 0; i < 400; i++) {
    const key = dateKey(cursor);
    if (key < startKey) break;
    if (isDayComplete(state, key)) {
      streak++;
      cursor = addDays(cursor, -1);
    } else break;
  }
  return streak;
}

export function totalWorkouts(state: FitLifeState): number {
  return Object.keys(state.days).filter((d) => isDayComplete(state, d)).length;
}

export function totalActiveMinutes(state: FitLifeState): number {
  return Math.round(Object.values(state.days).reduce((s, d) => s + d.activeSeconds, 0) / 60);
}

export function weekStats(state: FitLifeState, weekKeys: string[]) {
  const done = weekKeys.filter((k) => isDayComplete(state, k)).length;
  const minutes = Math.round(weekKeys.reduce((s, k) => s + (state.days[k]?.activeSeconds ?? 0), 0) / 60);
  const kcal = weekKeys.reduce((s, k) => s + (state.days[k] ? mealKcal(state.days[k]) : 0), 0);
  return { done, minutes, kcal };
}

/* ---------- Ölçümler ---------- */
export const MEASURE_FIELDS = [
  { key: "weight", label: "Kilo", unit: "kg", color: "#00e676" },
  { key: "chest", label: "Göğüs", unit: "cm", color: "#38bdf8" },
  { key: "waist", label: "Bel", unit: "cm", color: "#ffb020" },
  { key: "hips", label: "Kalça", unit: "cm", color: "#f472b6" },
  { key: "arm", label: "Kol", unit: "cm", color: "#a78bfa" },
  { key: "thigh", label: "Bacak", unit: "cm", color: "#22d3ee" },
  { key: "neck", label: "Boyun", unit: "cm", color: "#fb923c" },
  { key: "bodyFat", label: "Yağ", unit: "%", color: "#f87171" },
] as const;

export type MeasureKey = (typeof MEASURE_FIELDS)[number]["key"];

export function sortedMeasurements(list: Measurement[], key: MeasureKey): Measurement[] {
  return list.filter((m) => typeof m[key] === "number").sort((a, b) => a.date.localeCompare(b.date));
}

export function latestValue(list: Measurement[], key: MeasureKey): number | undefined {
  const s = sortedMeasurements(list, key);
  return s.length ? (s[s.length - 1][key] as number) : undefined;
}

export function firstValue(list: Measurement[], key: MeasureKey): number | undefined {
  const s = sortedMeasurements(list, key);
  return s.length ? (s[0][key] as number) : undefined;
}

export function bmi(weight: number, height: number): number {
  return weight / Math.pow(height / 100, 2);
}

export function bmiInfo(value: number): { label: string; color: string } {
  if (value < 18.5) return { label: "Zayıf", color: "#38bdf8" };
  if (value < 25) return { label: "Normal", color: "#00e676" };
  if (value < 30) return { label: "Fazla Kilolu", color: "#ffb020" };
  return { label: "Obez", color: "#f87171" };
}

/* ---------- Rozetler (gerçek veriden) ---------- */
export interface Badge {
  icon: string;
  title: string;
  desc: string;
  done: boolean;
  progress: number;
}

export function badges(state: FitLifeState): Badge[] {
  const p = state.profile!;
  const workouts = totalWorkouts(state);
  const streak = currentStreak(state);
  const measures = state.measurements.length;
  const first = firstValue(state.measurements, "weight") ?? p.weight;
  const last = latestValue(state.measurements, "weight") ?? p.weight;
  const span = Math.abs(p.targetWeight - first);
  const gained = Math.abs(last - first);
  const goalRatio = span > 0.05 ? Math.min(1, gained / span) : 0;
  const reached =
    p.goalId === "kilo-verme" ? last <= p.targetWeight : p.goalId === "form-koruma" ? workouts >= 20 : last >= p.targetWeight;
  return [
    { icon: "🔥", title: "7 Gün Seri", desc: `${Math.min(streak, 7)}/7 gün`, done: streak >= 7, progress: Math.min(1, streak / 7) },
    { icon: "💪", title: "10 Antrenman", desc: `${Math.min(workouts, 10)}/10 seans`, done: workouts >= 10, progress: Math.min(1, workouts / 10) },
    { icon: "📏", title: "Ölçüm Alışkanlığı", desc: `${Math.min(measures, 5)}/5 kayıt`, done: measures >= 5, progress: Math.min(1, measures / 5) },
    { icon: "⚖️", title: "Yolun Yarısı", desc: `%${Math.round(goalRatio * 100)} tamam`, done: goalRatio >= 0.5, progress: goalRatio },
    { icon: "🏆", title: "Hedef Kilo", desc: `${p.targetWeight} kg`, done: reached && measures > 0, progress: goalRatio },
    { icon: "⏱️", title: "10 Saat Salon", desc: `${Math.min(600, totalActiveMinutes(state))}/600 dk`, done: totalActiveMinutes(state) >= 600, progress: Math.min(1, totalActiveMinutes(state) / 600) },
  ];
}
