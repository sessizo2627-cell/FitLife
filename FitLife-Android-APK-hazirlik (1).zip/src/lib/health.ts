/* Samsung Health entegrasyonu
 *
 * Gerçek durum: Samsung Health verileri tarayıcıdan okunamaz. Veriye iki yol var:
 *  1) Android köprüsü — uygulama APK (Capacitor/WebView) olarak paketlendiğinde yerel
 *     katman Health Connect'ten okur ve window.FitLifeHealth üzerinden JSON teslim eder.
 *  2) Dosya içe aktarma — Samsung Health > Ayarlar > Kişisel verileri indir ile alınan
 *     CSV dosyaları (adım, nabız, uyku vb.) kullanıcı tarafından seçilir ve burada ayrıştırılır.
 */
import type { HealthSample } from "../types";
import { dateKey } from "./date";

export interface NativeHealthBridge {
  isAvailable: () => Promise<boolean> | boolean;
  requestPermissions: () => Promise<boolean>;
  readDaily: (fromISO: string, toISO: string) => Promise<Partial<HealthSample>[]>;
}

declare global {
  interface Window {
    FitLifeHealth?: NativeHealthBridge;
  }
}

export function nativeBridge(): NativeHealthBridge | null {
  return typeof window !== "undefined" && window.FitLifeHealth ? window.FitLifeHealth : null;
}

export async function readFromBridge(days = 30): Promise<HealthSample[]> {
  const bridge = nativeBridge();
  if (!bridge) throw new Error("Yerel köprü yok");
  const ok = await bridge.isAvailable();
  if (!ok) throw new Error("Health Connect bu cihazda kullanılamıyor");
  const granted = await bridge.requestPermissions();
  if (!granted) throw new Error("İzin verilmedi");
  const to = new Date();
  const from = new Date(Date.now() - days * 86400000);
  const rows = await bridge.readDaily(from.toISOString(), to.toISOString());
  const now = new Date().toISOString();
  return rows
    .filter((r) => r.date)
    .map((r) => ({ ...r, date: dateKey(String(r.date)), source: "samsung" as const, importedAt: now }));
}

/* ---------- CSV ayrıştırma (Samsung Health dışa aktarımı) ---------- */

function splitCSVLine(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (q && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else q = !q;
    } else if (ch === "," && !q) {
      out.push(cur);
      cur = "";
    } else cur += ch;
  }
  out.push(cur);
  return out.map((v) => v.trim());
}

function parseCSV(text: string): { headers: string[]; rows: string[][] } {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length);
  if (!lines.length) return { headers: [], rows: [] };
  // Samsung dosyalarında ilk satır genellikle meta bilgidir ("com.samsung.health.step_count,...")
  let headerIdx = 0;
  if (lines.length > 1 && lines[0].toLowerCase().includes("com.samsung") && !lines[0].toLowerCase().includes("time")) headerIdx = 1;
  const headers = splitCSVLine(lines[headerIdx]).map((h) => h.toLowerCase());
  const rows = lines.slice(headerIdx + 1).map(splitCSVLine);
  return { headers, rows };
}

function col(headers: string[], ...names: string[]): number {
  for (const n of names) {
    const i = headers.findIndex((h) => h === n || h.endsWith("." + n) || h.includes(n));
    if (i >= 0) return i;
  }
  return -1;
}

function toDate(v: string): string | null {
  if (!v) return null;
  const n = Number(v);
  const d = Number.isFinite(n) && v.length >= 12 ? new Date(n) : new Date(v.replace(" ", "T"));
  return Number.isNaN(d.getTime()) ? null : dateKey(d);
}

export type CSVKind = "steps" | "heart" | "sleep" | "exercise" | "spo2" | "unknown";

export function detectKind(fileName: string, headers: string[]): CSVKind {
  const f = fileName.toLowerCase();
  const h = headers.join(" ");
  if (f.includes("step") || h.includes("step_count") || h.includes("count")) return "steps";
  if (f.includes("heart") || h.includes("heart_rate")) return "heart";
  if (f.includes("sleep") || h.includes("sleep")) return "sleep";
  if (f.includes("oxygen") || h.includes("spo2")) return "spo2";
  if (f.includes("exercise") || h.includes("calorie")) return "exercise";
  return "unknown";
}

/** Bir Samsung Health CSV dosyasını günlük örneklere çevirir */
export function parseSamsungCSV(fileName: string, text: string): { kind: CSVKind; samples: HealthSample[] } {
  const { headers, rows } = parseCSV(text);
  const kind = detectKind(fileName, headers);
  const byDay: Record<string, HealthSample> = {};
  const now = new Date().toISOString();
  const ensure = (d: string) => (byDay[d] ??= { date: d, source: "samsung", importedAt: now });
  const timeIdx = col(headers, "start_time", "day_time", "create_time", "time", "date");

  if (kind === "steps") {
    const c = col(headers, "count", "step_count", "steps");
    rows.forEach((r) => {
      const d = toDate(r[timeIdx]);
      const v = Number(r[c]);
      if (!d || !Number.isFinite(v)) return;
      const s = ensure(d);
      s.steps = (s.steps ?? 0) + Math.round(v);
    });
  } else if (kind === "heart") {
    const c = col(headers, "heart_rate", "bpm", "rate");
    const cMin = col(headers, "heart_rate_min", "min");
    const cMax = col(headers, "heart_rate_max", "max");
    const acc: Record<string, { sum: number; n: number; min: number; max: number }> = {};
    rows.forEach((r) => {
      const d = toDate(r[timeIdx]);
      const v = Number(r[c]);
      if (!d || !Number.isFinite(v) || v <= 0) return;
      const a = (acc[d] ??= { sum: 0, n: 0, min: Infinity, max: -Infinity });
      a.sum += v;
      a.n++;
      const mn = cMin >= 0 ? Number(r[cMin]) : v;
      const mx = cMax >= 0 ? Number(r[cMax]) : v;
      a.min = Math.min(a.min, Number.isFinite(mn) && mn > 0 ? mn : v);
      a.max = Math.max(a.max, Number.isFinite(mx) && mx > 0 ? mx : v);
    });
    Object.entries(acc).forEach(([d, a]) => {
      const s = ensure(d);
      s.heartRateAvg = Math.round(a.sum / a.n);
      s.heartRateMin = Math.round(a.min);
      s.heartRateMax = Math.round(a.max);
    });
  } else if (kind === "sleep") {
    const cStart = col(headers, "start_time");
    const cEnd = col(headers, "end_time");
    const cDur = col(headers, "sleep_duration", "duration");
    rows.forEach((r) => {
      const d = toDate(r[cStart >= 0 ? cStart : timeIdx]);
      if (!d) return;
      let mins = 0;
      if (cDur >= 0 && Number.isFinite(Number(r[cDur]))) mins = Number(r[cDur]);
      else if (cStart >= 0 && cEnd >= 0) {
        const a = new Date(r[cStart].replace(" ", "T")).getTime();
        const b = new Date(r[cEnd].replace(" ", "T")).getTime();
        if (Number.isFinite(a) && Number.isFinite(b) && b > a) mins = (b - a) / 60000;
      }
      if (mins > 0) {
        const s = ensure(d);
        s.sleepMinutes = Math.round((s.sleepMinutes ?? 0) + mins);
      }
    });
  } else if (kind === "spo2") {
    const c = col(headers, "spo2", "oxygen");
    const acc: Record<string, number[]> = {};
    rows.forEach((r) => {
      const d = toDate(r[timeIdx]);
      const v = Number(r[c]);
      if (d && Number.isFinite(v) && v > 0) (acc[d] ??= []).push(v);
    });
    Object.entries(acc).forEach(([d, arr]) => (ensure(d).spo2 = Math.round(arr.reduce((a, b) => a + b, 0) / arr.length)));
  } else if (kind === "exercise") {
    const cCal = col(headers, "calorie", "calories");
    const cDist = col(headers, "distance");
    rows.forEach((r) => {
      const d = toDate(r[timeIdx]);
      if (!d) return;
      const s = ensure(d);
      const cal = Number(r[cCal]);
      const dist = Number(r[cDist]);
      if (Number.isFinite(cal) && cal > 0) s.caloriesBurned = Math.round((s.caloriesBurned ?? 0) + cal);
      if (Number.isFinite(dist) && dist > 0) s.distanceKm = +(((s.distanceKm ?? 0) + dist / 1000)).toFixed(2);
    });
  }

  return { kind, samples: Object.values(byDay) };
}

/** Nabız bölgesi (yaşa göre maksimum nabız üzerinden) */
export function heartZone(bpm: number, age: number): { label: string; color: string } {
  const max = 220 - age;
  const r = bpm / max;
  if (r < 0.5) return { label: "Dinlenme", color: "var(--c-blue)" };
  if (r < 0.6) return { label: "Çok hafif", color: "var(--c-acc)" };
  if (r < 0.7) return { label: "Yağ yakımı", color: "var(--c-acc)" };
  if (r < 0.8) return { label: "Kardiyo", color: "var(--c-amber)" };
  if (r < 0.9) return { label: "Yoğun", color: "var(--c-red)" };
  return { label: "Maksimum", color: "var(--c-red)" };
}
