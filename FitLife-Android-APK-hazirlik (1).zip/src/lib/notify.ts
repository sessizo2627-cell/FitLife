/* Cihaz bildirimleri + sesli alarm. Destek yoksa uygulama içi alarma düşer. */

export type PermState = "unsupported" | "default" | "granted" | "denied";

let audioCtx: AudioContext | null = null;
let swRegistration: ServiceWorkerRegistration | null = null;
let swTried = false;

export function notificationSupport(): PermState {
  if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
  return Notification.permission as PermState;
}

export async function registerSW(): Promise<boolean> {
  if (swTried) return !!swRegistration;
  swTried = true;
  if (!("serviceWorker" in navigator)) return false;
  try {
    const url = new URL("sw.js", document.baseURI).href;
    swRegistration = await navigator.serviceWorker.register(url, { scope: "./" });
    return true;
  } catch {
    swRegistration = null;
    return false;
  }
}

export async function requestPermission(): Promise<PermState> {
  if (!("Notification" in window)) return "unsupported";
  try {
    const res = await Notification.requestPermission();
    if (res === "granted") await registerSW();
    return res as PermState;
  } catch {
    return notificationSupport();
  }
}

export function canVibrate(): boolean {
  return typeof navigator !== "undefined" && "vibrate" in navigator;
}

export function vibrate(pattern: number[] = [180, 90, 180]) {
  try {
    navigator.vibrate?.(pattern);
  } catch {
    /* desteklenmiyor */
  }
}

/** Kullanıcı etkileşiminde ses motorunu aç (tarayıcı otomatik oynatma kuralı) */
export function unlockAudio() {
  try {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    if (!audioCtx) audioCtx = new Ctor();
    if (audioCtx.state === "suspended") void audioCtx.resume();
  } catch {
    audioCtx = null;
  }
}

export function beep(times = 3, freq = 880, gainValue = 0.14) {
  try {
    unlockAudio();
    if (!audioCtx) return;
    const now = audioCtx.currentTime;
    for (let i = 0; i < times; i++) {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(freq + i * 110, now + i * 0.26);
      gain.gain.setValueAtTime(0.0001, now + i * 0.26);
      gain.gain.exponentialRampToValueAtTime(gainValue, now + i * 0.26 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.26 + 0.22);
      osc.connect(gain).connect(audioCtx.destination);
      osc.start(now + i * 0.26);
      osc.stop(now + i * 0.26 + 0.24);
    }
  } catch {
    /* ses yok */
  }
}

export function tick() {
  beep(1, 620, 0.07);
}

const ICON =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 192 192'%3E%3Crect width='192' height='192' rx='42' fill='%23060807'/%3E%3Cpath d='M54 120V72M78 120V60M114 120V60M138 120V72M36 96h24M132 96h24' stroke='%2300E676' stroke-width='12' stroke-linecap='round'/%3E%3C/svg%3E";

/** Sistem bildirimi göndermeyi dener. Başarılıysa true döner. */
export async function systemNotify(title: string, body: string, tag = "fitlife"): Promise<boolean> {
  if (notificationSupport() !== "granted") return false;
  try {
    if (!swRegistration) await registerSW();
    if (swRegistration?.active) {
      swRegistration.active.postMessage({ type: "FITLIFE_NOTIFY", title, body, tag, icon: ICON });
      return true;
    }
    if (swRegistration) {
      await swRegistration.showNotification(title, { body, tag, icon: ICON, badge: ICON });
      return true;
    }
    // masaüstü / SW olmayan ortam
    const n = new Notification(title, { body, tag, icon: ICON });
    setTimeout(() => n.close(), 12000);
    return true;
  } catch {
    try {
      const n = new Notification(title, { body, tag, icon: ICON });
      setTimeout(() => n.close(), 12000);
      return true;
    } catch {
      return false;
    }
  }
}
