export const DAY_SHORT = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];
export const DAY_LONG = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"];

export function dateKey(d: Date | string = new Date()): string {
  const dt = typeof d === "string" ? new Date(d) : d;
  const y = dt.getFullYear();
  const m = String(dt.getMonth() + 1).padStart(2, "0");
  const day = String(dt.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseKey(key: string): Date {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1);
}

export function addDays(d: Date, n: number): Date {
  const c = new Date(d);
  c.setDate(c.getDate() + n);
  return c;
}

/** Pazartesi = 0 */
export function mondayIndex(d: Date = new Date()): number {
  return (d.getDay() + 6) % 7;
}

/** İçinde bulunulan haftanın 7 tarihi (Pzt..Paz) */
export function currentWeekDates(ref: Date = new Date()): string[] {
  const idx = mondayIndex(ref);
  const monday = addDays(ref, -idx);
  return Array.from({ length: 7 }, (_, i) => dateKey(addDays(monday, i)));
}

export function diffDays(fromKey: string, toKey: string): number {
  return Math.round((parseKey(toKey).getTime() - parseKey(fromKey).getTime()) / 86400000);
}

export function programDay(startISO: string, ref: Date = new Date()): number {
  return diffDays(dateKey(startISO), dateKey(ref)) + 1;
}

export function formatDateTR(d: Date = new Date()): string {
  return d.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" });
}

export function shortDate(key: string): string {
  return parseKey(key).toLocaleDateString("tr-TR", { day: "numeric", month: "short" });
}

export function longDate(key: string): string {
  return parseKey(key).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" });
}

export function weekdayOf(key: string): string {
  return DAY_LONG[mondayIndex(parseKey(key))];
}

export function nowHHMM(d: Date = new Date()): string {
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

export function fmtDuration(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
    : `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}
