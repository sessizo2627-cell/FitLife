import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef } from "react";
import type { ReactNode } from "react";
import type { ActiveSession, DayLog, FitLifeState, HealthSample, Meal, Measurement, Reminder, UserProfile } from "../types";
import { emptyDay } from "../lib/calc";
import { dateKey, uid } from "../lib/date";

const STORAGE_KEY = "fitlife_state_v2";
const LEGACY_PROFILE = "fitlife_profile_v1";
const LEGACY_WEIGHTS = "fitlife_weights";
const LEGACY_WATER = "fitlife_water_v1";
const LEGACY_DONE = "fitlife_done_v1";

export const initialState: FitLifeState = {
  version: 2,
  profile: null,
  days: {},
  measurements: [],
  reminders: [],
  session: null,
  health: {},
};

export function defaultReminders(): Reminder[] {
  return [
    { id: uid(), kind: "antrenman", title: "Antrenman zamanı", time: "18:30", days: [0, 1, 2, 3, 4], enabled: true, sound: true },
    { id: uid(), kind: "su", title: "Su içmeyi unutma", time: "11:00", days: [0, 1, 2, 3, 4, 5, 6], enabled: true, sound: false },
    { id: uid(), kind: "olcum", title: "Haftalık ölçüm günü", time: "08:00", days: [5], enabled: false, sound: true },
  ];
}

function normalizeProfile(raw: Partial<UserProfile>): UserProfile {
  return {
    name: raw.name ?? "Sporcu",
    age: Number(raw.age) || 25,
    height: Number(raw.height) || 178,
    weight: Number(raw.weight) || 75,
    targetWeight: Number(raw.targetWeight) || 75,
    gender: raw.gender === "kadin" ? "kadin" : "erkek",
    level: raw.level === "baslangic" || raw.level === "ileri" ? raw.level : "orta",
    goalId: (["kilo-verme", "kilo-alma", "kas-gelistirme", "form-koruma"] as const).includes(raw.goalId as never)
      ? (raw.goalId as UserProfile["goalId"])
      : "kas-gelistirme",
    durationDays: Math.min(365, Math.max(3, Number(raw.durationDays) || 30)),
    customDuration: !!raw.customDuration,
    startDate: raw.startDate ?? new Date().toISOString(),
    notifications: raw.notifications ?? true,
    reminders: raw.reminders ?? true,
    soundEffects: raw.soundEffects ?? true,
    weeklyTarget: Math.min(7, Math.max(1, Number(raw.weeklyTarget) || 4)),
    stepGoal: Math.min(50000, Math.max(1000, Number(raw.stepGoal) || 8000)),
    waterGoal: Math.min(20, Math.max(4, Number(raw.waterGoal) || 12)),
    theme: raw.theme === "dark" || raw.theme === "system" ? raw.theme : "light",
    healthSource: raw.healthSource === "samsung" ? "samsung" : "manual",
  };
}

function sanitizeDay(raw: Partial<DayLog>, date: string): DayLog {
  return {
    ...emptyDay(date),
    ...raw,
    date,
    exercises: raw.exercises && typeof raw.exercises === "object" ? raw.exercises : {},
    meals: Array.isArray(raw.meals) ? raw.meals : [],
    water: Number(raw.water) || 0,
    steps: Number(raw.steps) || 0,
    activeSeconds: Number(raw.activeSeconds) || 0,
    workoutDone: !!raw.workoutDone,
    note: raw.note ?? "",
  };
}

/** Diskten yükle + eski sürüm verilerini taşı */
export function loadState(): FitLifeState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<FitLifeState>;
      const days: Record<string, DayLog> = {};
      Object.entries(parsed.days ?? {}).forEach(([k, v]) => (days[k] = sanitizeDay(v as DayLog, k)));
      return {
        version: 2,
        profile: parsed.profile ? normalizeProfile(parsed.profile) : null,
        days,
        measurements: Array.isArray(parsed.measurements) ? parsed.measurements : [],
        reminders: Array.isArray(parsed.reminders) ? parsed.reminders : defaultReminders(),
        session: parsed.session ?? null,
        health: parsed.health && typeof parsed.health === "object" ? parsed.health : {},
      };
    }
  } catch {
    /* bozuk kayıt -> sıfırdan */
  }

  // v1 -> v2 taşıma
  try {
    const legacy = localStorage.getItem(LEGACY_PROFILE);
    if (legacy) {
      const profile = normalizeProfile(JSON.parse(legacy));
      const measurements: Measurement[] = [];
      const legacyWeights = localStorage.getItem(LEGACY_WEIGHTS);
      if (legacyWeights) {
        const arr = JSON.parse(legacyWeights) as { date: string; weight: number }[];
        arr.forEach((w) => measurements.push({ id: uid(), date: dateKey(w.date), weight: Number(w.weight) }));
      }
      if (!measurements.length) measurements.push({ id: uid(), date: dateKey(profile.startDate), weight: profile.weight });
      const days: Record<string, DayLog> = {};
      const lw = localStorage.getItem(LEGACY_WATER);
      const ld = localStorage.getItem(LEGACY_DONE);
      const today = dateKey();
      if (lw) {
        const w = JSON.parse(lw) as { date: string; count: number };
        days[w.date] = { ...emptyDay(w.date), water: Number(w.count) || 0 };
      }
      if (ld) {
        const d = JSON.parse(ld) as { date: string; done: boolean };
        days[d.date] = { ...(days[d.date] ?? emptyDay(d.date)), workoutDone: !!d.done };
      }
      if (!days[today]) days[today] = emptyDay(today);
      return { version: 2, profile, days, measurements, reminders: defaultReminders(), session: null, health: {} };
    }
  } catch {
    /* yoksay */
  }
  return initialState;
}

type Action =
  | { type: "SET_PROFILE"; profile: UserProfile }
  | { type: "PATCH_PROFILE"; patch: Partial<UserProfile> }
  | { type: "PATCH_DAY"; date: string; patch: Partial<DayLog> }
  | { type: "TOGGLE_EXERCISE"; date: string; key: string; value?: boolean }
  | { type: "ADD_MEAL"; date: string; meal: Meal }
  | { type: "DELETE_MEAL"; date: string; id: string }
  | { type: "ADD_MEASUREMENT"; measurement: Measurement }
  | { type: "UPDATE_MEASUREMENT"; measurement: Measurement }
  | { type: "DELETE_MEASUREMENT"; id: string }
  | { type: "ADD_REMINDER"; reminder: Reminder }
  | { type: "UPDATE_REMINDER"; reminder: Reminder }
  | { type: "DELETE_REMINDER"; id: string }
  | { type: "START_SESSION"; session: ActiveSession }
  | { type: "PATCH_SESSION"; patch: Partial<ActiveSession> }
  | { type: "END_SESSION"; seconds: number; date: string }
  | { type: "UPSERT_HEALTH"; samples: HealthSample[] }
  | { type: "CLEAR_HEALTH" }
  | { type: "IMPORT"; state: FitLifeState }
  | { type: "RESTORE"; state: FitLifeState }
  | { type: "RESET" };

function withDay(state: FitLifeState, date: string, fn: (d: DayLog) => DayLog): FitLifeState {
  const current = state.days[date] ?? emptyDay(date);
  return { ...state, days: { ...state.days, [date]: fn(current) } };
}

function reducer(state: FitLifeState, action: Action): FitLifeState {
  switch (action.type) {
    case "SET_PROFILE": {
      const profile = normalizeProfile(action.profile);
      const startKey = dateKey(profile.startDate);
      const hasStart = state.measurements.some((m) => m.date === startKey);
      return {
        ...state,
        profile,
        reminders: state.reminders.length ? state.reminders : defaultReminders(),
        measurements: hasStart
          ? state.measurements
          : [{ id: uid(), date: startKey, weight: profile.weight }, ...state.measurements],
        days: state.days[startKey] ? state.days : { ...state.days, [startKey]: emptyDay(startKey) },
      };
    }
    case "PATCH_PROFILE": {
      if (!state.profile) return state;
      const profile = normalizeProfile({ ...state.profile, ...action.patch });
      // güncel kilo son ölçümle senkron kalsın
      return { ...state, profile };
    }
    case "PATCH_DAY":
      return withDay(state, action.date, (d) => ({ ...d, ...action.patch }));
    case "TOGGLE_EXERCISE":
      return withDay(state, action.date, (d) => ({
        ...d,
        exercises: { ...d.exercises, [action.key]: action.value ?? !d.exercises[action.key] },
      }));
    case "ADD_MEAL":
      return withDay(state, action.date, (d) => ({ ...d, meals: [...d.meals, action.meal] }));
    case "DELETE_MEAL":
      return withDay(state, action.date, (d) => ({ ...d, meals: d.meals.filter((m) => m.id !== action.id) }));
    case "ADD_MEASUREMENT": {
      const measurements = [...state.measurements, action.measurement];
      const profile =
        state.profile && action.measurement.weight && action.measurement.date >= dateKey()
          ? { ...state.profile, weight: action.measurement.weight }
          : state.profile;
      return { ...state, measurements, profile };
    }
    case "UPDATE_MEASUREMENT": {
      const measurements = state.measurements.map((m) => (m.id === action.measurement.id ? action.measurement : m));
      return { ...state, measurements };
    }
    case "DELETE_MEASUREMENT":
      return { ...state, measurements: state.measurements.filter((m) => m.id !== action.id) };
    case "ADD_REMINDER":
      return { ...state, reminders: [...state.reminders, action.reminder] };
    case "UPDATE_REMINDER":
      return { ...state, reminders: state.reminders.map((r) => (r.id === action.reminder.id ? action.reminder : r)) };
    case "DELETE_REMINDER":
      return { ...state, reminders: state.reminders.filter((r) => r.id !== action.id) };
    case "START_SESSION":
      return { ...state, session: action.session };
    case "PATCH_SESSION":
      return state.session ? { ...state, session: { ...state.session, ...action.patch } } : state;
    case "END_SESSION":
      return {
        ...withDay(state, action.date, (d) => ({ ...d, activeSeconds: d.activeSeconds + action.seconds })),
        session: null,
      };
    case "UPSERT_HEALTH": {
      const health = { ...state.health };
      let days = state.days;
      action.samples.forEach((smp) => {
        health[smp.date] = { ...(health[smp.date] ?? {}), ...smp };
        // adım verisi günlük kayda da yansısın (manuel girişten büyükse)
        if (typeof smp.steps === "number") {
          const cur = days[smp.date] ?? emptyDay(smp.date);
          if (smp.steps > cur.steps) days = { ...days, [smp.date]: { ...cur, steps: smp.steps } };
        }
      });
      return { ...state, health, days };
    }
    case "CLEAR_HEALTH":
      return { ...state, health: {} };
    case "IMPORT":
      return { ...action.state, health: action.state.health ?? {} };
    case "RESTORE":
      return action.state;
    case "RESET":
      return { ...initialState, days: {}, measurements: [], reminders: [], health: {} };
    default:
      return state;
  }
}

interface StoreValue {
  state: FitLifeState;
  dispatch: React.Dispatch<Action>;
  /** yıkıcı işlemden önce geri alma noktası oluşturur */
  snapshot: () => void;
  undo: () => boolean;
  canUndo: boolean;
}

const StoreContext = createContext<StoreValue | null>(null);

export function FitLifeProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, loadState);
  const undoRef = useRef<FitLifeState | null>(null);
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* kota dolu olabilir */
    }
  }, [state]);

  // sekmeler arası senkron
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY && e.newValue) {
        try {
          dispatch({ type: "RESTORE", state: JSON.parse(e.newValue) as FitLifeState });
        } catch {
          /* yoksay */
        }
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const snapshot = useCallback(() => {
    undoRef.current = stateRef.current;
  }, []);

  const undo = useCallback(() => {
    if (!undoRef.current) return false;
    dispatch({ type: "RESTORE", state: undoRef.current });
    undoRef.current = null;
    return true;
  }, []);

  const value = useMemo<StoreValue>(
    () => ({ state, dispatch, snapshot, undo, canUndo: !!undoRef.current }),
    [state, snapshot, undo]
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore, FitLifeProvider içinde kullanılmalı");
  return ctx;
}

export function useProfile(): UserProfile {
  const { state } = useStore();
  if (!state.profile) throw new Error("Profil yok");
  return state.profile;
}

export function clearLegacyKeys() {
  [LEGACY_PROFILE, LEGACY_WEIGHTS, LEGACY_WATER, LEGACY_DONE, STORAGE_KEY].forEach((k) => localStorage.removeItem(k));
}
