import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Dumbbell, Smartphone, Zap, ShieldCheck, Download } from "lucide-react";
import type { Reminder, TabId } from "./types";
import { FitLifeProvider, useStore } from "./store/store";
import { FeedbackProvider, FeedbackHost, useFeedback } from "./components/Feedback";
import { currentStreak, dayProgress, getDay, mealKcal } from "./lib/calc";
import { dateKey, programDay } from "./lib/date";
import { REMINDER_BODIES, nextReminder, useReminderEngine } from "./hooks/useReminders";
import { registerSW, unlockAudio } from "./lib/notify";
import Splash from "./components/Splash";
import Onboarding from "./components/Onboarding";
import Header from "./components/Header";
import BottomNav from "./components/BottomNav";
import HomeScreen from "./components/HomeScreen";
import ProgramScreen from "./components/ProgramScreen";
import ProgressScreen from "./components/ProgressScreen";
import ProfileScreen from "./components/ProfileScreen";
import DiscoverScreen from "./components/DiscoverScreen";
import { useTheme } from "./hooks/useTheme";
import { useStartSession } from "./components/WorkoutSession";
import WorkoutSession from "./components/WorkoutSession";

interface InstallPrompt extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
}

function Shell() {
  const { state, dispatch } = useStore();
  const { toast, muted, raiseAlarm } = useFeedback();
  const [booted, setBooted] = useState(false);
  const [tab, setTab] = useState<TabId>("home");
  const [sessionOpen, setSessionOpen] = useState(false);
  const [installEvent, setInstallEvent] = useState<InstallPrompt | null>(null);
  const [forceOnboarding, setForceOnboarding] = useState(false);
  useTheme(state.profile?.theme ?? "light");

  useEffect(() => {
    const t = setTimeout(() => setBooted(true), 1500);
    void registerSW();
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setInstallEvent(e as InstallPrompt);
    };
    const unlock = () => unlockAudio();
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("pointerdown", unlock, { once: true });
    return () => {
      clearTimeout(t);
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("pointerdown", unlock);
    };
  }, []);

  useReminderEngine({
    state,
    muted,
    onFire: (r: Reminder) => raiseAlarm(r.title, REMINDER_BODIES[r.kind]),
    onMarkFired: (r, stamp) => dispatch({ type: "UPDATE_REMINDER", reminder: { ...r, lastFired: stamp } }),
  });

  // açık oturum varsa uygulamaya dönüşte hatırlat
  useEffect(() => {
    if (state.session && booted && state.profile) {
      setSessionOpen(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booted]);

  const install = async () => {
    if (!installEvent) return;
    await installEvent.prompt();
    const choice = await installEvent.userChoice;
    toast(choice.outcome === "accepted" ? "FitLife ana ekrana eklendi" : "Kurulum iptal edildi", { tone: "info" });
    setInstallEvent(null);
  };

  if (!booted) {
    return (
      <div className="relative mx-auto h-[100dvh] max-w-[430px] overflow-hidden md:my-6 md:h-[880px] md:rounded-[2.5rem] md:ring-1 md:ring-[var(--c-line2)]">
        <Splash />
      </div>
    );
  }

  const profile = state.profile;

  if (!profile || forceOnboarding) {
    return (
      <div className="min-h-[100dvh] bg-[var(--c-bg0)]">
        <div className="pointer-events-none fixed inset-0 hidden md:block">
          <div className="grid-bg absolute inset-0" />
          <div className="absolute left-1/2 top-1/3 h-[500px] w-[700px] -translate-x-1/2 rounded-full bg-[#00e676]/[0.06] blur-[140px]" />
        </div>
        <div className="relative mx-auto flex min-h-[100dvh] max-w-[1100px] items-center justify-center gap-10 px-0 md:px-4 md:py-8">
          <div className="hidden max-w-sm flex-1 md:block">
            <div className="flex items-center gap-2.5">
              <div className="glow-green grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-b from-[#00e676] to-[#00b248]">
                <Dumbbell size={22} strokeWidth={2.6} className="text-[#04110a]" />
              </div>
              <span className="font-display text-2xl tracking-wide text-[var(--c-text)]">FIT<span className="text-[var(--c-acc)]">LIFE</span></span>
            </div>
            <h1 className="font-display mt-6 text-6xl leading-[1.02] text-[var(--c-text)]">
              TELEFONUNDAN
              <br />
              <span className="text-[var(--c-acc)]">SALONA HÜKMET.</span>
            </h1>
            <p className="mt-4 text-[15px] leading-relaxed text-[var(--c-sub)]">
              Hedefini seç, süreni belirle; antrenmanların, ölçülerin ve hatırlatıcıların cihazında saklansın.
            </p>
            <div className="mt-6 space-y-3">
              {[
                { icon: Zap, t: "4 hedef, sana özel program", d: "Kilo al, kilo ver, kas yap, formunu koru" },
                { icon: ShieldCheck, t: "7 – 365 gün planlama", d: "Hazır süreler veya tamamen özel takvim" },
                { icon: Smartphone, t: "Çevrimdışı çalışır", d: "Tüm kayıtlar telefonda kalır, APK'ya hazır" },
              ].map((f, i) => (
                <div key={i} className="flex items-center gap-3 rounded-2xl border border-[var(--c-line)] bg-[var(--c-bg1)] p-3.5">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#00e676]/10 text-[var(--c-acc)]"><f.icon size={19} /></span>
                  <div>
                    <p className="text-[14px] font-extrabold text-[var(--c-text)]">{f.t}</p>
                    <p className="text-[12px] text-[var(--c-sub)]">{f.d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative h-[100dvh] w-full max-w-[430px] overflow-hidden bg-[var(--c-bg0)] md:h-[880px] md:rounded-[2.5rem] md:shadow-[0_0_80px_rgba(0,230,118,0.12)] md:ring-1 md:ring-[var(--c-line3)]">
            <FeedbackHost />
            <div className="app-scroll h-full overflow-y-auto">
              <Onboarding
                initial={profile ?? undefined}
                onComplete={(p) => {
                  dispatch({ type: "SET_PROFILE", profile: p });
                  setForceOnboarding(false);
                  setTab("home");
                  toast(`Hoş geldin ${p.name.split(" ")[0]}! Programın hazır.`);
                }}
                onCancel={profile ? () => setForceOnboarding(false) : undefined}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  const streak = currentStreak(state);
  const today = dateKey();
  const todayLog = getDay(state, today);
  const todayProg = dayProgress(state, today);
  const upcoming = nextReminder(state);

  return (
    <FeedbackInner
      tab={tab}
      setTab={setTab}
      streak={streak}
      todayLog={todayLog}
      todayProgress={todayProg.total}
      todayKcal={mealKcal(todayLog)}
      upcoming={upcoming}
      sessionOpen={sessionOpen}
      setSessionOpen={setSessionOpen}
      installAvailable={!!installEvent}
      onInstall={install}
      onRestart={() => setForceOnboarding(true)}
      programDayNo={Math.min(Math.max(1, programDay(profile.startDate)), profile.durationDays)}
    />
  );
}

function FeedbackInner({
  tab,
  setTab,
  streak,
  todayLog,
  todayProgress,
  todayKcal,
  upcoming,
  sessionOpen,
  setSessionOpen,
  installAvailable,
  onInstall,
  onRestart,
  programDayNo,
}: {
  tab: TabId;
  setTab: (t: TabId) => void;
  streak: number;
  todayLog: ReturnType<typeof getDay>;
  todayProgress: number;
  todayKcal: number;
  upcoming: ReturnType<typeof nextReminder>;
  sessionOpen: boolean;
  setSessionOpen: (v: boolean) => void;
  installAvailable: boolean;
  onInstall: () => void;
  onRestart: () => void;
  programDayNo: number;
}) {
  const { state } = useStore();
  const profile = state.profile!;
  const startSession = useStartSession();

  return (
    <div className="min-h-[100dvh] bg-[var(--c-bg0)]">
      <div className="pointer-events-none fixed inset-0 hidden md:block">
        <div className="grid-bg absolute inset-0" />
        <div className="absolute left-1/4 top-0 h-[420px] w-[420px] rounded-full bg-[#00e676]/[0.07] blur-[140px]" />
        <div className="absolute bottom-0 right-1/4 h-[320px] w-[320px] rounded-full bg-[#38bdf8]/[0.05] blur-[120px]" />
      </div>

      <div className="relative mx-auto flex min-h-[100dvh] max-w-[1180px] items-stretch justify-center gap-8 px-0 md:items-center md:px-4 md:py-6">
        {/* sol panel */}
        <div className="hidden w-[280px] shrink-0 flex-col justify-center lg:flex">
          <div className="flex items-center gap-2.5">
            <div className="glow-green grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-b from-[#00e676] to-[#00b248]">
              <Dumbbell size={22} strokeWidth={2.6} className="text-[#04110a]" />
            </div>
            <span className="font-display text-2xl tracking-wide text-[var(--c-text)]">FIT<span className="text-[var(--c-acc)]">LIFE</span></span>
          </div>
          <h1 className="font-display mt-6 text-5xl leading-[1.04] text-[var(--c-text)]">
            <span className="text-stroke">GÜCÜNÜ</span>
            <br />
            İNŞA ET<span className="text-[var(--c-acc)]">.</span>
          </h1>
          <p className="mt-4 text-[14px] leading-relaxed text-[var(--c-sub)]">
            <b className="text-[var(--c-text)]">{profile.name}</b>, {profile.durationDays} günlük programının {programDayNo}. günündesin. Bugünkü tamamlanma puanın{" "}
            <b className="text-[var(--c-acc)]">%{todayProgress}</b>.
          </p>
          <div className="mt-6 overflow-hidden rounded-2xl border border-[var(--c-line)]">
            <div className="diagonal-stripes h-2 w-full opacity-60" />
            <div className="space-y-2 bg-[var(--c-bg1)] p-4">
              {[
                ["Seri", `${streak} gün`],
                ["Bugünkü su", `${todayLog.water}/${profile.waterGoal} bardak`],
                ["Bugünkü kalori", `${todayKcal} kcal`],
                ["Kayıtlı ölçüm", `${state.measurements.length}`],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between text-[12.5px]">
                  <span className="text-[var(--c-mute)]">{k}</span>
                  <span className="font-extrabold text-[var(--c-text)]">{v}</span>
                </div>
              ))}
            </div>
          </div>
          {installAvailable && (
            <button onClick={onInstall} className="glow-green mt-4 flex items-center justify-center gap-2 rounded-2xl bg-[#00e676] py-3 text-[13.5px] font-extrabold text-[#04110a]">
              <Download size={16} /> Ana Ekrana Ekle
            </button>
          )}
        </div>

        {/* telefon */}
        <div className="relative flex h-[100dvh] w-full max-w-[430px] flex-col overflow-hidden bg-[var(--c-bg0)] md:h-[880px] md:rounded-[2.5rem] md:shadow-[0_0_80px_rgba(0,230,118,0.10)] md:ring-1 md:ring-[var(--c-line3)]">
          <div className="absolute left-1/2 top-2.5 z-[60] hidden h-6 w-32 -translate-x-1/2 rounded-full bg-black md:block md:ring-1 md:ring-[var(--c-line)]" />
          <FeedbackHost />

          <Header
            name={profile.name}
            streak={streak}
            water={todayLog.water}
            waterGoal={profile.waterGoal}
            progress={todayProgress}
            workoutDone={todayLog.workoutDone}
            upcoming={upcoming}
            remindersEnabled={profile.reminders}
            onNavigate={(t) => { setTab(t); setSessionOpen(false); }}
          />

          <main className="app-scroll relative flex-1 overflow-y-auto">
            <AnimatePresence mode="wait">
              <motion.div key={tab} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
                {tab === "home" && <HomeScreen onNavigate={setTab} onOpenSession={() => setSessionOpen(true)} />}
                {tab === "program" && <ProgramScreen onOpenSession={() => setSessionOpen(true)} />}
                {tab === "discover" && (
                  <DiscoverScreen
                    onStartRoutine={(r) => {
                      startSession(99, undefined, { title: r.title, exercises: r.exercises });
                      setSessionOpen(true);
                    }}
                  />
                )}
                {tab === "progress" && <ProgressScreen />}
                {tab === "profile" && <ProfileScreen onRestart={onRestart} />}
              </motion.div>
            </AnimatePresence>
          </main>

          <BottomNav active={tab} onChange={setTab} />

          <AnimatePresence>
            {sessionOpen && (
              <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 30 }} className="absolute inset-0 z-[75]">
                <WorkoutSession onClose={() => setSessionOpen(false)} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* sağ panel */}
        <div className="hidden w-[250px] shrink-0 flex-col justify-center gap-3 md:flex">
          {[
            { id: "home", n: "01", t: "Ana Sayfa", d: "Günlük özet ve hızlı kayıt" },
            { id: "program", n: "02", t: "Programım", d: "Haftalık plan, canlı antrenman" },
            { id: "discover", n: "03", t: "Keşfet", d: "Ekstra egzersiz ve beslenme" },
            { id: "progress", n: "04", t: "İlerleme", d: "Kilo ve vücut ölçüleri" },
            { id: "profile", n: "05", t: "Profil", d: "Tema, Samsung Health, yedek" },
          ].map((s) => (
            <button
              key={s.n}
              onClick={() => setTab(s.id as TabId)}
              className={`rounded-2xl border p-4 text-left transition-all ${
                tab === s.id ? "border-[#00e676]/50 bg-[#00e676]/[0.06]" : "border-[var(--c-line)] bg-[var(--c-bg1)] hover:border-[var(--c-line3)]"
              }`}
            >
              <p className="font-display text-[13px] tracking-widest text-[var(--c-acc)]">{s.n}</p>
              <p className="mt-1 text-[15px] font-extrabold text-[var(--c-text)]">{s.t}</p>
              <p className="text-[12px] text-[var(--c-mute)]">{s.d}</p>
            </button>
          ))}
          <p className="mt-2 text-[11px] leading-relaxed text-[var(--c-mute2)]">
            FitLife v2.0 — Tüm kayıtlar cihazda saklanır. Uygulamayı kapatsan da veriler korunur.
          </p>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <FitLifeProvider>
      <FeedbackProvider>
        <Shell />
      </FeedbackProvider>
    </FitLifeProvider>
  );
}
