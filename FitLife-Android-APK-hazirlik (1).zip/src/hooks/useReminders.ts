import { useEffect, useRef } from "react";
import type { FitLifeState, Reminder } from "../types";
import { mondayIndex, nowHHMM, dateKey } from "../lib/date";
import { beep, canVibrate, systemNotify, vibrate } from "../lib/notify";

export const REMINDER_BODIES: Record<Reminder["kind"], string> = {
  antrenman: "Bugünkü programın hazır. Isınmayla başla, serisini bozma.",
  su: "Bir bardak su iç ve günlük hedefine bir adım daha yaklaş.",
  olcum: "Kilonu ve vücut ölçülerini gir, değişimi grafikte gör.",
  ogun: "Öğününü kaydet; kalori ve protein hedefin seni bekliyor.",
  ozel: "Kendine ayırdığın zaman başladı.",
};

export function nextOccurrence(r: Reminder, from: Date = new Date()): Date | null {
  if (!r.enabled || r.days.length === 0) return null;
  const [h, m] = r.time.split(":").map(Number);
  for (let i = 0; i < 8; i++) {
    const d = new Date(from);
    d.setDate(d.getDate() + i);
    d.setHours(h || 0, m || 0, 0, 0);
    if (d.getTime() <= from.getTime()) continue;
    if (r.days.includes(mondayIndex(d))) return d;
  }
  return null;
}

export function nextReminder(state: FitLifeState): { reminder: Reminder; at: Date } | null {
  let best: { reminder: Reminder; at: Date } | null = null;
  state.reminders.forEach((r) => {
    const at = nextOccurrence(r);
    if (at && (!best || at < best.at)) best = { reminder: r, at };
  });
  return best;
}

interface Options {
  state: FitLifeState;
  muted: boolean;
  onFire: (r: Reminder) => void;
  onMarkFired: (r: Reminder, stamp: string) => void;
}

/**
 * Uygulama açıkken (ön planda ya da arka plan sekmesinde) hatırlatıcıları izler.
 * Cihaz/system bildirimi varsa onu, yoksa uygulama içi alarmı kullanır.
 */
export function useReminderEngine({ state, muted, onFire, onMarkFired }: Options) {
  const ref = useRef({ state, muted, onFire, onMarkFired });
  ref.current = { state, muted, onFire, onMarkFired };

  useEffect(() => {
    let stopped = false;

    const check = async () => {
      const { state: s, muted: isMuted, onFire: fire, onMarkFired: mark } = ref.current;
      if (stopped || !s.profile || !s.profile.reminders) return;
      const now = new Date();
      const today = mondayIndex(now);
      const hhmm = nowHHMM(now);
      const stamp = `${dateKey(now)}T${hhmm}`;

      for (const r of s.reminders) {
        if (!r.enabled || !r.days.includes(today)) continue;
        if (r.time !== hhmm) continue;
        if (r.lastFired === stamp) continue;
        mark(r, stamp);
        const body = REMINDER_BODIES[r.kind];
        const delivered = s.profile.notifications ? await systemNotify(r.title, body, r.id) : false;
        if (!delivered) fire(r);
        if (!isMuted && r.sound) {
          beep(3);
          if (canVibrate()) vibrate();
        }
      }
    };

    const id = window.setInterval(check, 15000);
    const onVisible = () => {
      if (document.visibilityState === "visible") void check();
    };
    document.addEventListener("visibilitychange", onVisible);
    void check();

    return () => {
      stopped = true;
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, []);
}
