import { useEffect } from "react";

export type ThemePref = "light" | "dark" | "system";

export function resolveTheme(pref: ThemePref): "light" | "dark" {
  if (pref === "system") return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  return pref;
}

/** Tercihi <html> sınıfına ve tarayıcı tema rengine uygular */
export function useTheme(pref: ThemePref) {
  useEffect(() => {
    const apply = () => {
      const t = resolveTheme(pref);
      document.documentElement.classList.toggle("dark", t === "dark");
      document.querySelector('meta[name="theme-color"]')?.setAttribute("content", t === "dark" ? "#040605" : "#f3f8f5");
    };
    apply();
    if (pref !== "system") return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [pref]);
}
