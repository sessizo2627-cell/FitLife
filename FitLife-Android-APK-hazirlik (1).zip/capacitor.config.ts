import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.fitlife.app",
  appName: "FitLife",
  webDir: "dist",
  bundledWebRuntime: false,
};

export default config;
